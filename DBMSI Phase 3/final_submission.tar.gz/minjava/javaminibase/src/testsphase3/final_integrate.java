package testsphase3;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import HashIndex.UnclusteredHashIndex;
import btree.BT;
import btree.BTreeFile;
import btree.FloatKey;
import bufmgr.PageNotReadException;
import diskmgr.pcounter;
import global.AggType;
import global.AttrType;
import global.PageId;
import global.RID;
import global.SystemDefs;
import heap.FieldNumberOutOfBoundException;
import heap.HFBufMgrException;
import heap.HFDiskMgrException;
import heap.HFException;
import heap.Heapfile;
import heap.InvalidSlotNumberException;
import heap.InvalidTupleSizeException;
import heap.InvalidTypeException;
import heap.Scan;
import heap.Tuple;
import iterator.BTreeSortedSky;
import iterator.BlockNestedLoopSky;
import iterator.FileScan;
import iterator.FldSpec;
import iterator.GroupBywithHash;
import iterator.JoinsException;
import iterator.LowMemException;
import iterator.NRAJoin;
import iterator.NestedLoopsSky;
import iterator.PredEvalException;
import iterator.RelSpec;
import iterator.SortFirstSky;
import iterator.TopK_HashJoin;
import iterator.TupleUtils;
import iterator.UnknowAttrType;
import iterator.WrongPermat;
import iterator.GroupBywithSort;
import iterator.Iterator;
import iterator.BlockNestedLoopSky;
import iterator.NestedLoopsSky;
import iterator.SortFirstSky;
import iterator.BTreeSky;
import iterator.BTreeSortedSky;
import iterator.BTreeFileClustered;

class TaskIntegration
{
    int DEFAULT_NUM_BUCKETS = -10;
    int DEFAULT_SPLIT_POINTER = -10;
    static SystemDefs sysdefs;
    static String dbpath;
    AttrType[] attr3;
    AttrType[] attrType2;
    AttrType[] attrType_lasthf;

    

    void openDB(String db_name)
    {
        dbpath = "/Users/riya/Documents/DBMSI/Project/Phase 1/minjava/javaminibase/src/dbs/"+db_name+"_"+System.getProperty("user.name")+".minibase-db";
        File file = new File(dbpath);
        if (file.exists()){
            sysdefs = new SystemDefs( dbpath, 0,  100, "Clock" );
            System.out.println("Database exists");
        } 
        else 
        {
            sysdefs = new SystemDefs( dbpath, 50000,  10000, "Clock" );
            System.out.println("Database didnt exist");
        }
    }

    TaskIntegration(){}
    void closeDB() throws IOException
    {
        try
        {
            SystemDefs.JavabaseBM.flushAllPages();
        } 
        catch(Exception e)
        {
            System.out.println("Error flushing Buffer Pages");
        }
        SystemDefs.JavabaseDB.closeDB();
    }

    void createTable(String filename) throws FileNotFoundException
    {
        PageId pid = new PageId();
        // String input_filepath = "/Users/nithyavardhanveerati/Desktop/CSE 510 - DBMSI/Project/Phase III/src/input_files/"+tableName;
        String input_filepath = "Project/Phase 1/minjava/javaminibase/src/input_files/"+filename;
        String tableName = filename.split("\\.")[0];

        File f1 = new File(input_filepath);
        Scanner scan = new Scanner(f1);
        // int num_attributes = Integer.valueOf(scan.nextLine());
        int num_attributes = Integer.valueOf(scan.nextLine().split(",")[0]);
        
        short str_sizes[] = new short[num_attributes];
        String attr_name[] = new String[num_attributes];
        AttrType attr_type[] = new AttrType[num_attributes];
        String conc_attr_name = "";
        String conc_attr_type = "";
        for(int i=0;i<num_attributes;i++)
        {
            str_sizes[i] = (short)40;
        }
        for(int i=0;i<num_attributes;i++)
        {
            String in_line = scan.nextLine();
            String[] tokens = in_line.split(",");
            attr_name[i] = tokens[0];
            if(tokens[1].equals("INT"))
            {
                attr_type[i] = new AttrType(AttrType.attrInteger);
            }
            else if(tokens[1].equals("STR"))
            {
                attr_type[i] = new AttrType(AttrType.attrString);
            }
            else
            {
                System.out.println("Wrong attribute type");
            }
            if(i==0)
            {
                conc_attr_name += attr_name[i];
                conc_attr_type += tokens[1];
            }
            else{
                conc_attr_name += "+"+attr_name[i];
                conc_attr_type += "+"+tokens[1];
            }
        }
        System.out.println(conc_attr_type+"___"+conc_attr_name);

        AttrType[] meta_data_attrs = new AttrType[4];
        meta_data_attrs[0] = new AttrType(AttrType.attrString);
        meta_data_attrs[1] = new AttrType(AttrType.attrString);
        meta_data_attrs[2] = new AttrType(AttrType.attrString);
        meta_data_attrs[3] = new AttrType(AttrType.attrInteger);

        short[] meta_data_str_sizes = new short[4];
        meta_data_str_sizes[0] = 40;
        meta_data_str_sizes[1] = 40;
        meta_data_str_sizes[2] = 40;
        meta_data_str_sizes[3] = 40;

        Tuple meta_tuple = new Tuple();
        try {
            meta_tuple.setHdr((short) 4, meta_data_attrs, meta_data_str_sizes);
        }catch (Exception e) {
            e.printStackTrace();
        }
        int mt_size = meta_tuple.size();
        meta_tuple = new Tuple(mt_size);
        try {
            meta_tuple.setHdr((short) 4, meta_data_attrs, meta_data_str_sizes);
        }catch (Exception e) {
            e.printStackTrace();
        }

        Heapfile metadata_table = null;
        try {
            metadata_table = new Heapfile(tableName+"_metadata");
        }
        catch (Exception e) {
            e.printStackTrace();
        }

        try{
            meta_tuple.setStrFld(1,tableName);
            meta_tuple.setStrFld(2,conc_attr_name);
            meta_tuple.setStrFld(3,conc_attr_type);
            meta_tuple.setIntFld(4,num_attributes);
        }catch (Exception e) {
            e.printStackTrace();
        }
        try {
            metadata_table.insertRecord(meta_tuple.returnTupleByteArray());
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        // System.out.println("Worked till here");



        
        Tuple tup_temp = new Tuple();
        try {
            tup_temp.setHdr((short) num_attributes, attr_type, str_sizes);
        } catch (Exception e) {
            System.out.println(e);
        }
        int size = tup_temp.size();
        tup_temp = new Tuple(size);
        try {
            tup_temp.setHdr((short) num_attributes, attr_type, str_sizes);
        } catch (Exception e) {
            System.out.println(e);
        } 
        int count=0;
        while(scan.hasNextLine())
        {
            count++;
            String line = scan.nextLine();
            String[] tokens = line.split(",");
            if(tokens.length != num_attributes)
            {
                System.out.println("Number of attributes not matching");
                break;
            }
            else
            {
                RID rid;
                Heapfile table = null;
                try {
                    table = new Heapfile(tableName);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
                for (int i = 0; i < num_attributes; i++) 
                {
                    try{
                        if (attr_type[i].attrType == AttrType.attrInteger) {
                            tup_temp.setIntFld(i + 1, Integer.parseInt(tokens[i]));
                        }
                        else if (attr_type[i].attrType == AttrType.attrReal) {
                            tup_temp.setFloFld(i + 1, Float.parseFloat(tokens[i]));
                        }
                        else if (attr_type[i].attrType == AttrType.attrString) {
                            tup_temp.setStrFld(i + 1, tokens[i]);
                        }
                    }
                    catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                try {
                    rid = table.insertRecord(tup_temp.returnTupleByteArray());
                }
                catch (Exception e) {
                    e.printStackTrace();
                }

                tup_temp = new Tuple();
                try {
                    tup_temp.setHdr((short) num_attributes, attr_type, str_sizes);
                } catch (Exception e) {
                    System.out.println(e);
                }
                size = tup_temp.size();
                tup_temp = new Tuple(size);
                try {
                    tup_temp.setHdr((short) num_attributes, attr_type, str_sizes);
                } catch (Exception e) {
                    System.out.println(e);
                } 
            }
        }
        scan.close();
        try {
            SystemDefs.JavabaseBM.flushAllPages();
        } catch (Exception e){
            System.out.println("Error flushing the pages in the buffer");
        }
        System.out.println("The table is created");
        System.out.println(count);
    }

    void outputTable(String filename)
    {
        Heapfile hf = null;
        int n =0;
        try
        {
            hf = new Heapfile(filename);
            n = hf.getRecCnt();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println(n);


        FldSpec[] meta_projlist = new FldSpec[4];
        RelSpec meta_rel = new RelSpec(RelSpec.outer); 
        meta_projlist[0] = new FldSpec(meta_rel,1);
        meta_projlist[1] = new FldSpec(meta_rel,2);
        meta_projlist[2] = new FldSpec(meta_rel,3);
        meta_projlist[3] = new FldSpec(meta_rel,4);
        
        FileScan meta_fscan = null;

        AttrType meta_attr_type[] = new AttrType[4];
        meta_attr_type[0] = new AttrType(AttrType.attrString);
        meta_attr_type[1] = new AttrType(AttrType.attrString);
        meta_attr_type[2] = new AttrType(AttrType.attrString);
        meta_attr_type[3] = new AttrType(AttrType.attrInteger);

        short[] meta_str_sizes = new short[4];
        for(int i=0;i<4;i++)
        {
            meta_str_sizes[i] = (short)40;
        }
        
        try {
            meta_fscan = new FileScan(filename+"_metadata", meta_attr_type, meta_str_sizes, (short) 4, 4, meta_projlist, null);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        Tuple metadata_t = new Tuple();
        try {
            metadata_t.setHdr((short) 4, meta_attr_type, meta_str_sizes);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        int metadata_size = metadata_t.size();
        metadata_t = new Tuple(metadata_size);
        try {
            metadata_t.setHdr((short) 4, meta_attr_type, meta_str_sizes);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        try {
            metadata_t = meta_fscan.get_next();
        }
        catch (Exception e) {
            e.printStackTrace(); 
        }
        String table_schema="";
        int num_attr= 0;
        try {
            table_schema = metadata_t.getStrFld(3);
            num_attr = metadata_t.getIntFld(4);
        }  
        catch (Exception e) {
            e.printStackTrace();
        }
        meta_fscan.close();

        ////////////////
        FldSpec[] projlist = new FldSpec[num_attr];
        RelSpec rel = new RelSpec(RelSpec.outer);
        for(int i=0;i<num_attr;i++)
        {
            projlist[i] = new FldSpec(rel,i+1);
        }
        
        FileScan fscan = null;

        AttrType attr_type[] = new AttrType[num_attr];
        String attr_tokens[] = table_schema.split("\\+");
        for(int i=0;i<num_attr;i++)
        {
            if(attr_tokens[i].equals("STR"))
            {
                attr_type[i] = new AttrType(AttrType.attrString);
            }
            else if(attr_tokens[i].equals("INT"))
            {
                attr_type[i] = new AttrType(AttrType.attrInteger);        
            }
        }
        // attr_type[0] = new AttrType(AttrType.attrString);
        // attr_type[1] = new AttrType(AttrType.attrInteger);
        // attr_type[2] = new AttrType(AttrType.attrInteger);

        short[] str_sizes = new short[num_attr];
        for(int i=0;i<num_attr;i++)
        {
            str_sizes[i] = (short)40;
        }
        
        try {
            fscan = new FileScan(filename, attr_type, str_sizes, (short) num_attr, num_attr, projlist, null);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        Tuple t = new Tuple();
        try {
            t.setHdr((short) 3, attr_type, str_sizes);
          }
          catch (Exception e) {
            e.printStackTrace();
        }
        try {
            t = fscan.get_next();
        }
        catch (Exception e) {
            e.printStackTrace(); 
        }

        // int i=0;
        while(t!=null)
        {
            // System.out.println("Count: "+Integer.toString(i++));
            for(int i=0;i<num_attr;i++)
            {
                // System.out.println();
                // System.out.print("Column "+Integer.toString(i+1)+": ");
                try {
                    if(attr_type[i].attrType == AttrType.attrReal)
                    {
                        System.out.print(t.getFloFld(i+1));
                    }
                    if(attr_type[i].attrType == AttrType.attrInteger)
                    {
                        System.out.print(t.getIntFld(i+1));
                    }
                    if(attr_type[i].attrType == AttrType.attrString)
                    {
                        System.out.print(t.getStrFld(i+1));
                    }
                } 
                catch (Exception e) 
                {
                    e.printStackTrace();
                }
                System.out.print("\t");
            }
            System.out.println();
            // System.out.println("LALALA");
            try {
                t = fscan.get_next();
            }
            catch (Exception e) {
                e.printStackTrace(); 
                break;
            }
        }
        fscan.close();
    }

    void insertData(String tablename, String filename) throws FileNotFoundException
    {
        String filepath = "Project/Phase 1/minjava/javaminibase/src/input_files/"+filename;
        
        File f1 = new File(filepath);
        Scanner scan = new Scanner(f1);
        // int num_attributes = Integer.valueOf(scan.nextLine());
        int num_attributes = Integer.valueOf(scan.nextLine().split(",")[0]);

        short str_sizes[] = new short[num_attributes];
        String attr_name[] = new String[num_attributes];
        AttrType attr_type[] = new AttrType[num_attributes];
        String conc_attr_name = "";
        String conc_attr_type = "";
        for(int i=0;i<num_attributes;i++)
        {
            str_sizes[i] = (short)40;
        }
        for(int i=0;i<num_attributes;i++)
        {
            String in_line = scan.nextLine();
            String[] tokens = in_line.split(",");
            attr_name[i] = tokens[0];
            if(tokens[1].equals("INT"))
            {
                attr_type[i] = new AttrType(AttrType.attrInteger);
            }
            else if(tokens[1].equals("STR"))
            {
                attr_type[i] = new AttrType(AttrType.attrString);
            }
            else
            {
                System.out.println("Wrong attribute type");
            }
            if(i==0)
            {
                conc_attr_name += attr_name[i];
                conc_attr_type += tokens[1];
            }
            else{
                conc_attr_name += "+"+attr_name[i];
                conc_attr_type += "+"+tokens[1];
            }
            // conc_attr_type
        }
        System.out.println(conc_attr_type);

        // open scan on meta heapfile and getnext
        FldSpec[] projlist = new FldSpec[4];
        RelSpec rel = new RelSpec(RelSpec.outer); 
        projlist[0] = new FldSpec(rel,1);
        projlist[1] = new FldSpec(rel,2);
        projlist[2] = new FldSpec(rel,3);
        projlist[3] = new FldSpec(rel,4);
        
        FileScan meta_fscan = null;

        AttrType meta_attr_type[] = new AttrType[4];
        meta_attr_type[0] = new AttrType(AttrType.attrString);
        meta_attr_type[1] = new AttrType(AttrType.attrString);
        meta_attr_type[2] = new AttrType(AttrType.attrString);
        meta_attr_type[3] = new AttrType(AttrType.attrInteger);

        short[] meta_str_sizes = new short[4];
        for(int i=0;i<4;i++)
        {
            meta_str_sizes[i] = (short)40;
        }
        
        try {
            meta_fscan = new FileScan(tablename+"_metadata", meta_attr_type, meta_str_sizes, (short) 4, 4, projlist, null);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        Tuple metadata_t = new Tuple();
        try {
            metadata_t.setHdr((short) 4, meta_attr_type, meta_str_sizes);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        int metadata_size = metadata_t.size();
        metadata_t = new Tuple(metadata_size);
        try {
            metadata_t.setHdr((short) 4, meta_attr_type, meta_str_sizes);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        try {
            metadata_t = meta_fscan.get_next();
        }
        catch (Exception e) {
            e.printStackTrace(); 
        }
        String table_schema="";
        try {
            table_schema = metadata_t.getStrFld(3);
        }  
        catch (Exception e) {
            e.printStackTrace();
        }
        meta_fscan.close();
        if(!(table_schema.equals(conc_attr_type)))
        {
            System.out.println("Schema dont match");
            try {
                SystemDefs.JavabaseBM.flushAllPages();
            } catch (Exception e){
                System.out.println("Error flushing the pages in the buffer");
            }
            return;
        }

        // tuple.get conc_attr_type.
        // if not match break saying error
        // else open scan on filename file and insert tuple
        
        //while sc.hasnextline()
        //tokenize
        //setattrtypes
        //tuple insert

        Tuple tup_temp = new Tuple();
        try {
            tup_temp.setHdr((short) num_attributes, attr_type, str_sizes);
        } catch (Exception e) {
            System.out.println(e);
        }
        int size = tup_temp.size();
        tup_temp = new Tuple(size);
        try {
            tup_temp.setHdr((short) num_attributes, attr_type, str_sizes);
        } catch (Exception e) {
            System.out.println(e);
        } 
        int count=0;
        while(scan.hasNextLine())
        {
            count++;
            String line = scan.nextLine();
            String[] tokens = line.split(",");
            if(tokens.length != num_attributes)
            {
                System.out.println("Number of attributes not matching");
                break;
            }
            else
            {
                RID rid;
                Heapfile table = null;
                try {
                    table = new Heapfile(tablename);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
                for (int i = 0; i < num_attributes; i++) 
                {
                    try{
                        if (attr_type[i].attrType == AttrType.attrInteger) {
                            tup_temp.setIntFld(i + 1, Integer.parseInt(tokens[i]));
                        }
                        else if (attr_type[i].attrType == AttrType.attrReal) {
                            tup_temp.setFloFld(i + 1, Float.parseFloat(tokens[i]));
                        }
                        else if (attr_type[i].attrType == AttrType.attrString) {
                            tup_temp.setStrFld(i + 1, tokens[i]);
                        }
                    }
                    catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                try {
                    rid = table.insertRecord(tup_temp.returnTupleByteArray());
                }
                catch (Exception e) {
                    e.printStackTrace();
                }

                tup_temp = new Tuple();
                try {
                    tup_temp.setHdr((short) num_attributes, attr_type, str_sizes);
                } catch (Exception e) {
                    System.out.println(e);
                }
                size = tup_temp.size();
                tup_temp = new Tuple(size);
                try {
                    tup_temp.setHdr((short) num_attributes, attr_type, str_sizes);
                } catch (Exception e) {
                    System.out.println(e);
                } 
            }
        }
        scan.close();
        try {
            SystemDefs.JavabaseBM.flushAllPages();
        } catch (Exception e){
            System.out.println("Error flushing the pages in the buffer");
        }
        System.out.println("Insertion into the table is completed");
        System.out.println(count);
    }

    void deleteData(String tablename, String filename) throws FileNotFoundException
    {
        // campute schema of file
        String filepath = "Project/Phase 1/minjava/javaminibase/src/input_files/"+filename;
        
        File f1 = new File(filepath);
        Scanner scan = new Scanner(f1);
        // int num_attributes = Integer.valueOf(scan.nextLine());
        int num_attributes = Integer.valueOf(scan.nextLine().split(",")[0]);

        short str_sizes[] = new short[num_attributes];
        String attr_name[] = new String[num_attributes];
        AttrType attr_type[] = new AttrType[num_attributes];
        String conc_attr_name = "";
        String conc_attr_type = "";
        for(int i=0;i<num_attributes;i++)
        {
            str_sizes[i] = (short)40;
        }
        for(int i=0;i<num_attributes;i++)
        {
            String in_line = scan.nextLine();
            String[] tokens = in_line.split(",");
            attr_name[i] = tokens[0];
            if(tokens[1].equals("INT"))
            {
                attr_type[i] = new AttrType(AttrType.attrInteger);
            }
            else if(tokens[1].equals("STR"))
            {
                attr_type[i] = new AttrType(AttrType.attrString);
            }
            else
            {
                System.out.println("Wrong attribute type");
            }
            if(i==0)
            {
                conc_attr_name += attr_name[i];
                conc_attr_type += tokens[1];
            }
            else{
                conc_attr_name += "+"+attr_name[i];
                conc_attr_type += "+"+tokens[1];
            }
            // conc_attr_type
        }
        System.out.println(conc_attr_type);

        // open table and get schema
        FldSpec[] meta_projlist = new FldSpec[4];
        RelSpec meta_rel = new RelSpec(RelSpec.outer); 
        meta_projlist[0] = new FldSpec(meta_rel,1);
        meta_projlist[1] = new FldSpec(meta_rel,2);
        meta_projlist[2] = new FldSpec(meta_rel,3);
        meta_projlist[3] = new FldSpec(meta_rel,4);
        
        FileScan meta_fscan = null;

        AttrType meta_attr_type[] = new AttrType[4];
        meta_attr_type[0] = new AttrType(AttrType.attrString);
        meta_attr_type[1] = new AttrType(AttrType.attrString);
        meta_attr_type[2] = new AttrType(AttrType.attrString);
        meta_attr_type[3] = new AttrType(AttrType.attrInteger);

        short[] meta_str_sizes = new short[4];
        for(int i=0;i<4;i++)
        {
            meta_str_sizes[i] = (short)40;
        }
        
        try {
            meta_fscan = new FileScan(tablename+"_metadata", meta_attr_type, meta_str_sizes, (short) 4, 4, meta_projlist, null);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        Tuple metadata_t = new Tuple();
        try {
            metadata_t.setHdr((short) 4, meta_attr_type, meta_str_sizes);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        int metadata_size = metadata_t.size();
        metadata_t = new Tuple(metadata_size);
        try {
            metadata_t.setHdr((short) 4, meta_attr_type, meta_str_sizes);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        try {
            metadata_t = meta_fscan.get_next();
        }
        catch (Exception e) {
            e.printStackTrace(); 
        }
        String table_schema="";
        String table_attribute_names="";
        try {
            table_schema = metadata_t.getStrFld(3);
            table_attribute_names = metadata_t.getStrFld(2);
        }  
        catch (Exception e) {
            e.printStackTrace();
        }
        meta_fscan.close();

        // if not match (ie conc_atts) - return
        if(!(table_attribute_names.equals(conc_attr_name)) || !(table_schema.equals(conc_attr_type)))
        {
            System.out.println("File and Table are not compatible.");
            return;
        }

        // else
        // scan all the file tuples into an arraylist of tuples

        Tuple table_tup = new Tuple();
        ArrayList<Tuple> outerAL = new ArrayList<Tuple>();
        while(scan.hasNextLine())
        {
            String line = scan.nextLine();
            String[] tokens = line.split(",");
            if(tokens.length != num_attributes)
            {
                System.out.println("Number of attributes not matching");
                break;
            }
            else
            {
                //create a tuple {{{{{{  CHANGE STRING SIZES}}}}}}
                table_tup = new Tuple();
                try {
                    table_tup.setHdr((short) num_attributes, attr_type, str_sizes);
                } catch (Exception e) {
                    System.out.println(e);
                }
                int table_tup_size = table_tup.size();
                table_tup = new Tuple(table_tup_size);
                try {
                    table_tup.setHdr((short) num_attributes, attr_type, str_sizes);
                } catch (Exception e) {
                    System.out.println(e);
                }
                
                try{
                    // insert tuple in the arraylist
                    for (int i = 0; i < num_attributes; i++) {
                        if (attr_type[i].attrType == AttrType.attrInteger) {
                            table_tup.setIntFld(i + 1, Integer.parseInt(tokens[i]));
                        }
                        else if (attr_type[i].attrType == AttrType.attrReal) {
                            table_tup.setFloFld(i + 1, Float.parseFloat(tokens[i]));
                        }
                        else if (attr_type[i].attrType == AttrType.attrString) {
                            table_tup.setStrFld(i + 1, tokens[i]);
                        }
                        else if (attr_type[i].attrType == AttrType.attrSymbol) {
                            table_tup.setStrFld(i + 1, tokens[i]);
                        }
                        else if (attr_type[i].attrType == AttrType.attrNull) {
                            table_tup.setStrFld(i + 1, tokens[i]);
                        }
                    }
                }
                catch (Exception e) {
                    System.out.println(e);
                }
                outerAL.add(table_tup);
                table_tup = new Tuple(table_tup_size);
                try {
                    table_tup.setHdr((short) num_attributes, attr_type, str_sizes);
                } catch (Exception e) {
                    System.out.println(e);
                }
            }
        }
        scan.close();
        // take a tuple from file and search tuple if table 
        Heapfile file1 = null;
        Scan file_scan = null;
        Tuple file_tup = new Tuple();
        Tuple dup_file_tup = new Tuple();
        try {
            file_tup.setHdr((short) num_attributes, attr_type, str_sizes);
            dup_file_tup.setHdr((short) num_attributes, attr_type, str_sizes);
        } catch (Exception e) {
            System.out.println(e);
        }
        int file_tup_size = file_tup.size();
        file_tup = new Tuple(file_tup_size);
        dup_file_tup = new Tuple(file_tup_size);
        try {
            file_tup.setHdr((short) num_attributes, attr_type, str_sizes);
            dup_file_tup.setHdr((short) num_attributes, attr_type, str_sizes);
        } catch (Exception e) {
            System.out.println(e);
        } 

        try {
            file1 = new Heapfile(tablename);
        } catch (Exception e) {
            System.out.println(e);
        }
        int num_recs=0;
        try {
            file_scan = new Scan(file1);
            num_recs = file1.getRecCnt();
        } catch (Exception e) {
            System.out.println(e);
        }

        System.out.println("Count Before: "+String.valueOf(num_recs));
        ///
        RID rid = new RID();
        try {
            file_tup = file_scan.getNext(rid);
        }
        catch (Exception e) {
            e.printStackTrace(); 
        }
        while (file_tup != null) {

            try{
                file_tup.setHdr((short) num_attributes, attr_type, str_sizes);
            }catch(Exception e){
                e.printStackTrace();
            }
            for(int p=0;p<outerAL.size();p++)
            {
                try{
                    dup_file_tup.setHdr((short) num_attributes, attr_type, str_sizes);
                }catch(Exception e){
                    e.printStackTrace();
                }
                dup_file_tup.tupleCopy(outerAL.get(p));
                try {
                    if(TupleUtils.Equal(file_tup, dup_file_tup, attr_type, num_attributes))
                    {
                        file1.deleteRecord(rid);
                    }
                    // file_tup = file_scan.getNext(rid);
                    
                    if(file1.getRecCnt()==0)
                    {
                        try {
                            SystemDefs.JavabaseBM.flushAllPages();
                        } catch (Exception e){
                           
                        }
                        return;
                    }
                    file_tup = file_scan.getNext(rid);
                }
                catch (Exception e){
                    e.printStackTrace();
                }
                
                if(file_tup == null){
                    // clean up
                    try {
                        if(file1.getRecCnt()!=0)
                        {
                            file_scan.closescan();
                        }
                        // return;
                    }
                    catch (Exception e){
                        e.printStackTrace();
                    }
                }
            }    
        }
        try {
            System.out.println("After: "+String.valueOf(file1.getRecCnt()));
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            if(file1.getRecCnt() == 0)
            {
                return;
            }
        } catch (Exception e1) {
            e1.printStackTrace();
        }
        try {
            file_scan.closescan();
            // return;open
        }
        catch (Exception e){
            e.printStackTrace();
        }
        try {
            SystemDefs.JavabaseBM.flushAllPages();
        } catch (Exception e){
           
        }
    }
    
    void outputIndex(String tablename, int key_attr_num)
    {
        // search in index_metadata table if index exists on that key.
        Heapfile imhf = null;
        try{
            imhf = new Heapfile(tablename+"_index_metadata");
        }
        catch(Exception e)
        {
            System.out.println("Error opening the index metadata file");
            e.printStackTrace();
        }
        FileScan meta_fscan = null;
        Tuple index_meta_tup = new Tuple();

        AttrType[] meta_data_attrs = new AttrType[5];
        meta_data_attrs[0] = new AttrType(AttrType.attrString);
        meta_data_attrs[1] = new AttrType(AttrType.attrString);
        meta_data_attrs[2] = new AttrType(AttrType.attrInteger);
        meta_data_attrs[3] = new AttrType(AttrType.attrInteger);
        meta_data_attrs[4] = new AttrType(AttrType.attrInteger);

        short[] meta_data_str_sizes = new short[5];
        meta_data_str_sizes[0] = 40;
        meta_data_str_sizes[1] = 40;
        meta_data_str_sizes[2] = 40;
        meta_data_str_sizes[3] = 40;
        meta_data_str_sizes[4] = 40;

        FldSpec[] meta_projlist = new FldSpec[4];
        RelSpec meta_rel = new RelSpec(RelSpec.outer); 
        meta_projlist[0] = new FldSpec(meta_rel,1);
        meta_projlist[1] = new FldSpec(meta_rel,2);
        meta_projlist[2] = new FldSpec(meta_rel,3);
        meta_projlist[3] = new FldSpec(meta_rel,4);
        meta_projlist[3] = new FldSpec(meta_rel,5);

        try {
            meta_fscan = new FileScan(tablename+"_index_metadata", meta_data_attrs, meta_data_str_sizes, (short) 5, 5, meta_projlist, null);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        try {
            index_meta_tup.setHdr((short) 5, meta_data_attrs, meta_data_str_sizes);
        }catch (Exception e) {
            e.printStackTrace();
        }
        int imt_size = index_meta_tup.size();
        index_meta_tup = new Tuple(imt_size);
        try {
            index_meta_tup.setHdr((short) 5, meta_data_attrs, meta_data_str_sizes);
        }catch (Exception e) {
            e.printStackTrace();
        }
        try {
            index_meta_tup = meta_fscan.get_next();
        }
        catch (Exception e) {
            e.printStackTrace(); 
        }
        ArrayList<String> al = new ArrayList<String>();
        while(index_meta_tup!=null)
        {
            int tup_key_attr_num = 0;
            try {
                tup_key_attr_num = index_meta_tup.getIntFld(3);
            }  
            catch (Exception e) {
                e.printStackTrace();
            }
            if(key_attr_num == tup_key_attr_num)
            {
                try {
                    al.add(index_meta_tup.getStrFld(1));
                } 
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
            try {
                index_meta_tup = meta_fscan.get_next();
            }
            catch (Exception e) {
                e.printStackTrace(); 
            }
            // if(index_meta_tup==null)
            // {
            //     meta_fscan.close();   
            // }    
        }
        meta_fscan.close();

        boolean cl_flag=false;
        if(al.size() > 1)
        {
            for(int i=0;i<al.size();i++)
            {
                if(al.get(i).equals("CL"))
                {
                    cl_flag = true;
                    break;
                }
            }
        }
        else if(al.size() == 1)
        {
            if(al.get(0).equals("CL"))
            {
                cl_flag = true;
            }
        }
        meta_fscan.close();

    


        // depending on clustered of inclustered, iterate over index file and print
    }

    AttrType[] get_attr(String table_name)
    {
        //open a scan on the table/heapfile
        Heapfile metadata_table=null;
        try {
            metadata_table = new Heapfile(table_name+"_metadata");
        } catch (Exception e1) {
            e1.printStackTrace();
        }
        FldSpec[] meta_projlist = new FldSpec[4];
        RelSpec meta_rel = new RelSpec(RelSpec.outer); 
        meta_projlist[0] = new FldSpec(meta_rel,1);
        meta_projlist[1] = new FldSpec(meta_rel,2);
        meta_projlist[2] = new FldSpec(meta_rel,3);
        meta_projlist[3] = new FldSpec(meta_rel,4);
        
        FileScan meta_fscan = null;

        AttrType meta_attr_type[] = new AttrType[4];
        meta_attr_type[0] = new AttrType(AttrType.attrString);
        meta_attr_type[1] = new AttrType(AttrType.attrString);
        meta_attr_type[2] = new AttrType(AttrType.attrString);
        meta_attr_type[3] = new AttrType(AttrType.attrInteger);

        short[] meta_str_sizes = new short[4];
        for(int i=0;i<4;i++)
        {
            meta_str_sizes[i] = (short)40;
        }
        
        try {
            meta_fscan = new FileScan(table_name+"_metadata", meta_attr_type, meta_str_sizes, (short) 4, 4, meta_projlist, null);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        Tuple metadata_t = new Tuple();
        try {
            metadata_t.setHdr((short) 4, meta_attr_type, meta_str_sizes);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        int metadata_size = metadata_t.size();
        metadata_t = new Tuple(metadata_size);
        try {
            metadata_t.setHdr((short) 4, meta_attr_type, meta_str_sizes);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        try {
            metadata_t = meta_fscan.get_next();
        }
        catch (Exception e) {
            e.printStackTrace(); 
        }
        String table_schema="";
        int num_cols = 0;
        try {
            table_schema = metadata_t.getStrFld(3);
            num_cols = metadata_t.getIntFld(4);
        }  
        catch (Exception e) {
            e.printStackTrace();
        }
        meta_fscan.close();

        AttrType[] attr = new AttrType[num_cols];
        String prim_attrs[] = table_schema.split("\\+");
        for(int i=0;i<num_cols;i++)
        {
            if(prim_attrs[i].equals("STR"))
            {
                attr[i] = new AttrType(AttrType.attrString);
            }
            else if(prim_attrs[i].equals("INT"))
            {
                attr[i] = new AttrType(AttrType.attrInteger);
            }
            else
            {
                System.out.println("Wrong format");
                return null;
            }
        }
        return attr;
    }

    void create_index_metadata(String tablename, String index_type, String index_structure, int index_attr_number, int split_pointer, int num_buckets)
    {
        String index_metadata_tablename = tablename+"_index_metadata";
        Heapfile metadata_table = null;
        try {
            metadata_table = new Heapfile(index_metadata_tablename);
        }
        catch (Exception e) {
            e.printStackTrace();
        }

        Tuple index_meta_tup = new Tuple();

        AttrType[] meta_data_attrs = new AttrType[5];
        meta_data_attrs[0] = new AttrType(AttrType.attrString);
        meta_data_attrs[1] = new AttrType(AttrType.attrString);
        meta_data_attrs[2] = new AttrType(AttrType.attrInteger);
        meta_data_attrs[3] = new AttrType(AttrType.attrInteger);
        meta_data_attrs[4] = new AttrType(AttrType.attrInteger);

        short[] meta_data_str_sizes = new short[5];
        meta_data_str_sizes[0] = 40;
        meta_data_str_sizes[1] = 40;
        meta_data_str_sizes[2] = 40;
        meta_data_str_sizes[3] = 40;
        meta_data_str_sizes[4] = 40;

        try {
            index_meta_tup.setHdr((short) 5, meta_data_attrs, meta_data_str_sizes);
        }catch (Exception e) {
            e.printStackTrace();
        }
        int imt_size = index_meta_tup.size();
        index_meta_tup = new Tuple(imt_size);
        try {
            index_meta_tup.setHdr((short) 5, meta_data_attrs, meta_data_str_sizes);
        }catch (Exception e) {
            e.printStackTrace();
        }

        try{
            index_meta_tup.setStrFld(1,index_type);
            index_meta_tup.setStrFld(2,index_structure);
            index_meta_tup.setIntFld(3,index_attr_number);
            index_meta_tup.setIntFld(4,split_pointer);
            index_meta_tup.setIntFld(5,num_buckets);
        }catch (Exception e) {
            e.printStackTrace();
        }
        try {
            metadata_table.insertRecord(index_meta_tup.returnTupleByteArray());
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        
        // Do we need to do this?
        try {
            SystemDefs.JavabaseBM.flushAllPages();
        } catch (Exception e){
           
        }
    }

    void update_split_pointer(String tablename, String index_type, String index_structure, int index_attr_number, int split_pointer)
    {
        Heapfile file1 = null;
        // open a scan on the index table
        String index_metadata_tablename = tablename + "_index_metadata";
        // Heapfile metadata_table = null;
        // try {
        //     metadata_table = new Heapfile(index_metadata_tablename);
        // }
        // catch (Exception e) {
        //     e.printStackTrace();
        // }

        Tuple imt_tup = new Tuple();
        AttrType meta_attr_type[] = new AttrType[5];
        meta_attr_type[0] = new AttrType(AttrType.attrString);
        meta_attr_type[1] = new AttrType(AttrType.attrString);
        meta_attr_type[2] = new AttrType(AttrType.attrInteger);
        meta_attr_type[3] = new AttrType(AttrType.attrInteger);
        meta_attr_type[4] = new AttrType(AttrType.attrInteger);

        short[] meta_str_sizes = new short[5];
        for(int i=0;i<5;i++)
        {
            meta_str_sizes[i] = (short)40;
        }
        
        try {
            imt_tup.setHdr((short) 5, meta_attr_type, meta_str_sizes);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        int metadata_size = imt_tup.size();
        imt_tup = new Tuple(metadata_size);
        try {
            imt_tup.setHdr((short) 5, meta_attr_type, meta_str_sizes);
        }
        catch (Exception e) {
            e.printStackTrace();
        }

        Scan ifscan = null;
        try {
            file1 = new Heapfile(index_metadata_tablename);
        } catch (Exception e) {
            System.out.println(e);
        }
        int num_recs=0;
        try {
            ifscan = new Scan(file1);
            num_recs = file1.getRecCnt();
        } catch (Exception e) {
            System.out.println(e);
        }

        RID rid = new RID();
        try {
            imt_tup = ifscan.getNext(rid);
        }
        catch (Exception e) {
            e.printStackTrace(); 
        }
        String temp_index_type="";
        String temp_index_struct="";
        int temp_index_attr_number=0;
        int temp_num_buckets=0;
        
        // get tuple where values match
        while (imt_tup != null) 
        {
            try{
                imt_tup.setHdr((short) 5, meta_attr_type, meta_str_sizes);
            }catch(Exception e){
                e.printStackTrace();
            }
            try {
                temp_index_attr_number = imt_tup.getIntFld(3);
                temp_index_struct = imt_tup.getStrFld(2);
                temp_index_type = imt_tup.getStrFld(1);
                temp_num_buckets = imt_tup.getIntFld(5);
            }  
            catch (Exception e) {
                e.printStackTrace();
            }
            // store those values and delete the tuple
            if(index_attr_number == temp_index_attr_number && index_structure.equals(temp_index_struct) && temp_index_type.equals(index_type))
            {
                try {
                    file1.deleteRecord(rid);
                    System.out.println("Deleted old index metadata");
                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                break;
            }
            else{
                try {
                    imt_tup = ifscan.getNext(rid);
                }
                catch (Exception e) {
                    e.printStackTrace(); 
                    break;
                }
            }
            // close the scan.
            if(imt_tup == null){
                // clean up
                try {
                    ifscan.closescan();
                    // return;
                }
                catch (Exception e){
                    e.printStackTrace();
                }
            }
        }

        Tuple insert_tup = new Tuple();
        
        //create a tuple with the values and insert into the table.
        try {
            insert_tup.setHdr((short) 5, meta_attr_type, meta_str_sizes);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        int insert_tup_size = insert_tup.size();
        insert_tup = new Tuple(insert_tup_size);
        try {
            insert_tup.setHdr((short) 5, meta_attr_type, meta_str_sizes);
        }
        catch (Exception e) {
            e.printStackTrace();
        }

        try{
            insert_tup.setStrFld(1, temp_index_type);
            insert_tup.setStrFld(2, temp_index_struct);
            insert_tup.setIntFld(3, temp_index_attr_number);
            insert_tup.setIntFld(4, split_pointer);
            insert_tup.setIntFld(5, temp_num_buckets);
        }
        catch (Exception e) {
            e.printStackTrace();
        }

        try {
            rid = file1.insertRecord(insert_tup.returnTupleByteArray());
            System.out.println("Inserted right index metadata");
        }
        catch (Exception e) {
            System.out.println("Cannot insert right metadata");
            e.printStackTrace();
        }

        //do we need to flush?
        try {
            SystemDefs.JavabaseBM.flushAllPages();
        } catch (Exception e){
            System.out.println("Error flushing pages in Buffer");
        }
    }

    void update_num_buckets(String tablename, String index_type, String index_structure, int index_attr_number, int num_buckets)
    {
        Heapfile file1 = null;
        // open a scan on the index table
        String index_metadata_tablename = tablename + "_index_metadata";
        // Heapfile metadata_table = null;
        // try {
        //     metadata_table = new Heapfile(index_metadata_tablename);
        // }
        // catch (Exception e) {
        //     e.printStackTrace();
        // }

        Tuple imt_tup = new Tuple();
        AttrType meta_attr_type[] = new AttrType[5];
        meta_attr_type[0] = new AttrType(AttrType.attrString);
        meta_attr_type[1] = new AttrType(AttrType.attrString);
        meta_attr_type[2] = new AttrType(AttrType.attrInteger);
        meta_attr_type[3] = new AttrType(AttrType.attrInteger);
        meta_attr_type[4] = new AttrType(AttrType.attrInteger);

        short[] meta_str_sizes = new short[5];
        for(int i=0;i<5;i++)
        {
            meta_str_sizes[i] = (short)40;
        }
        
        try {
            imt_tup.setHdr((short) 5, meta_attr_type, meta_str_sizes);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        int metadata_size = imt_tup.size();
        imt_tup = new Tuple(metadata_size);
        try {
            imt_tup.setHdr((short) 5, meta_attr_type, meta_str_sizes);
        }
        catch (Exception e) {
            e.printStackTrace();
        }

        Scan ifscan = null;
        try {
            file1 = new Heapfile(index_metadata_tablename);
        } catch (Exception e) {
            System.out.println(e);
        }
        int num_recs=0;
        try {
            ifscan = new Scan(file1);
            num_recs = file1.getRecCnt();
        } catch (Exception e) {
            System.out.println(e);
        }

        RID rid = new RID();
        try {
            imt_tup = ifscan.getNext(rid);
        }
        catch (Exception e) {
            e.printStackTrace(); 
        }
        String temp_index_type="";
        String temp_index_struct="";
        int temp_index_attr_number=0;
        int temp_split_pointer=0;
        
        // get tuple where values match
        while (imt_tup != null) 
        {
            try{
                imt_tup.setHdr((short) 5, meta_attr_type, meta_str_sizes);
            }catch(Exception e){
                e.printStackTrace();
            }
            try {
                temp_index_attr_number = imt_tup.getIntFld(3);
                temp_index_struct = imt_tup.getStrFld(2);
                temp_index_type = imt_tup.getStrFld(1);
                temp_split_pointer = imt_tup.getIntFld(4);
            }  
            catch (Exception e) {
                e.printStackTrace();
            }
            // store those values and delete the tuple
            if(index_attr_number == temp_index_attr_number && index_structure.equals(temp_index_struct) && temp_index_type.equals(index_type))
            {
                try {
                    file1.deleteRecord(rid);
                    System.out.println("Deleted old index metadata");
                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                break;
            }
            else{
                try {
                    imt_tup = ifscan.getNext(rid);
                }
                catch (Exception e) {
                    e.printStackTrace(); 
                    break;
                }
            }
            // close the scan.
            if(imt_tup == null){
                // clean up
                try {
                    ifscan.closescan();
                    // return;
                }
                catch (Exception e){
                    e.printStackTrace();
                }
            }
        }

        Tuple insert_tup = new Tuple();
        
        //create a tuple with the values and insert into the table.
        try {
            insert_tup.setHdr((short) 5, meta_attr_type, meta_str_sizes);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        int insert_tup_size = insert_tup.size();
        insert_tup = new Tuple(insert_tup_size);
        try {
            insert_tup.setHdr((short) 5, meta_attr_type, meta_str_sizes);
        }
        catch (Exception e) {
            e.printStackTrace();
        }

        try{
            insert_tup.setStrFld(1, temp_index_type);
            insert_tup.setStrFld(2, temp_index_struct);
            insert_tup.setIntFld(3, temp_index_attr_number);
            insert_tup.setIntFld(4, temp_split_pointer);
            insert_tup.setIntFld(5, num_buckets);
        }
        catch (Exception e) {
            e.printStackTrace();
        }

        try {
            rid = file1.insertRecord(insert_tup.returnTupleByteArray());
            System.out.println("Inserted right index metadata");
        }
        catch (Exception e) {
            System.out.println("Cannot insert right metadata");
            e.printStackTrace();
        }

        //do we need to flush?
        try {
            SystemDefs.JavabaseBM.flushAllPages();
        } catch (Exception e){
            
        }
    }

    int lookup_num_buckets(String tablename, String index_type, String index_structure, int index_attr_number)
    {
        Heapfile file1 = null;
        // open a scan on the index table
        String index_metadata_tablename = tablename + "_index_metadata";
        // Heapfile metadata_table = null;
        // try {
        //     metadata_table = new Heapfile(index_metadata_tablename);
        // }
        // catch (Exception e) {
        //     e.printStackTrace();
        // }

        Tuple imt_tup = new Tuple();
        AttrType meta_attr_type[] = new AttrType[5];
        meta_attr_type[0] = new AttrType(AttrType.attrString);
        meta_attr_type[1] = new AttrType(AttrType.attrString);
        meta_attr_type[2] = new AttrType(AttrType.attrInteger);
        meta_attr_type[3] = new AttrType(AttrType.attrInteger);
        meta_attr_type[4] = new AttrType(AttrType.attrInteger);

        short[] meta_str_sizes = new short[5];
        for(int i=0;i<5;i++)
        {
            meta_str_sizes[i] = (short)40;
        }
        
        try {
            imt_tup.setHdr((short) 5, meta_attr_type, meta_str_sizes);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        int metadata_size = imt_tup.size();
        imt_tup = new Tuple(metadata_size);
        try {
            imt_tup.setHdr((short) 5, meta_attr_type, meta_str_sizes);
        }
        catch (Exception e) {
            e.printStackTrace();
        }

        Scan ifscan = null;
        try {
            file1 = new Heapfile(index_metadata_tablename);
        } catch (Exception e) {
            System.out.println(e);
        }
        int num_recs=0;
        try {
            ifscan = new Scan(file1);
            num_recs = file1.getRecCnt();
        } catch (Exception e) {
            System.out.println(e);
        }

        RID rid = new RID();
        try {
            imt_tup = ifscan.getNext(rid);
        }
        catch (Exception e) {
            e.printStackTrace(); 
        }
        String temp_index_type="";
        String temp_index_struct="";
        int temp_index_attr_number=0;
        int found_num_buckets=0;
        
        // get tuple where values match
        while (imt_tup != null) 
        {
            try{
                imt_tup.setHdr((short) 5, meta_attr_type, meta_str_sizes);
            }catch(Exception e){
                e.printStackTrace();
            }
            try {
                temp_index_attr_number = imt_tup.getIntFld(3);
                temp_index_struct = imt_tup.getStrFld(2);
                temp_index_type = imt_tup.getStrFld(1);
                found_num_buckets = imt_tup.getIntFld(5);
            }  
            catch (Exception e) {
                e.printStackTrace();
            }
            // store those values and delete the tuple
            if(index_attr_number == temp_index_attr_number && index_structure.equals(temp_index_struct) && temp_index_type.equals(index_type))
            {
                break;
            }
            else{
                try {
                    imt_tup = ifscan.getNext(rid);
                }
                catch (Exception e) {
                    e.printStackTrace(); 
                    break;
                }
            }
            // close the scan.
            if(imt_tup == null){
                // clean up
                try {
                    ifscan.closescan();
                    // return;
                }
                catch (Exception e){
                    e.printStackTrace();
                }
            }
        }

        //do we need to flush?
        try {
            SystemDefs.JavabaseBM.flushAllPages();
        } catch (Exception e){
           
        }
        return found_num_buckets;
    }

    int lookup_splitpointer(String tablename, String index_type, String index_structure, int index_attr_number)
    {
        Heapfile file1 = null;
        // open a scan on the index table
        String index_metadata_tablename = tablename + "_index_metadata";
        // Heapfile metadata_table = null;
        // try {
        //     metadata_table = new Heapfile(index_metadata_tablename);
        // }
        // catch (Exception e) {
        //     e.printStackTrace();
        // }

        Tuple imt_tup = new Tuple();
        AttrType meta_attr_type[] = new AttrType[5];
        meta_attr_type[0] = new AttrType(AttrType.attrString);
        meta_attr_type[1] = new AttrType(AttrType.attrString);
        meta_attr_type[2] = new AttrType(AttrType.attrInteger);
        meta_attr_type[3] = new AttrType(AttrType.attrInteger);
        meta_attr_type[4] = new AttrType(AttrType.attrInteger);

        short[] meta_str_sizes = new short[5];
        for(int i=0;i<5;i++)
        {
            meta_str_sizes[i] = (short)40;
        }
        
        try {
            imt_tup.setHdr((short) 5, meta_attr_type, meta_str_sizes);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        int metadata_size = imt_tup.size();
        imt_tup = new Tuple(metadata_size);
        try {
            imt_tup.setHdr((short) 5, meta_attr_type, meta_str_sizes);
        }
        catch (Exception e) {
            e.printStackTrace();
        }

        Scan ifscan = null;
        try {
            file1 = new Heapfile(index_metadata_tablename);
        } catch (Exception e) {
            System.out.println(e);
        }
        int num_recs=0;
        try {
            ifscan = new Scan(file1);
            num_recs = file1.getRecCnt();
        } catch (Exception e) {
            System.out.println(e);
        }

        RID rid = new RID();
        try {
            imt_tup = ifscan.getNext(rid);
        }
        catch (Exception e) {
            e.printStackTrace(); 
        }
        String temp_index_type="";
        String temp_index_struct="";
        int temp_index_attr_number=0;
        int found_split_pointer=0;
        
        // get tuple where values match
        while (imt_tup != null) 
        {
            try{
                imt_tup.setHdr((short) 5, meta_attr_type, meta_str_sizes);
            }catch(Exception e){
                e.printStackTrace();
            }
            try {
                temp_index_attr_number = imt_tup.getIntFld(3);
                temp_index_struct = imt_tup.getStrFld(2);
                temp_index_type = imt_tup.getStrFld(1);
                found_split_pointer = imt_tup.getIntFld(4);
            }  
            catch (Exception e) {
                e.printStackTrace();
            }
            // store those values and delete the tuple
            if(index_attr_number == temp_index_attr_number && index_structure.equals(temp_index_struct) && temp_index_type.equals(index_type))
            {
                break;
            }
            else{
                try {
                    imt_tup = ifscan.getNext(rid);
                }
                catch (Exception e) {
                    e.printStackTrace(); 
                    break;
                }
            }
            // close the scan.
            if(imt_tup == null){
                // clean up
                try {
                    ifscan.closescan();
                    // return;
                }
                catch (Exception e){
                    e.printStackTrace();
                }
            }
        }

        //do we need to flush?
        try {
            SystemDefs.JavabaseBM.flushAllPages();
        } catch (Exception e){
            System.out.println("Error flushing pages in Buffer");
        }
        return found_split_pointer;
    }

    int get_clustered_key(String tablename)
    {
        Heapfile file1 = null;
        
        String index_metadata_tablename = tablename + "_index_metadata";
        Tuple imt_tup = new Tuple();
        AttrType meta_attr_type[] = new AttrType[5];
        meta_attr_type[0] = new AttrType(AttrType.attrString);
        meta_attr_type[1] = new AttrType(AttrType.attrString);
        meta_attr_type[2] = new AttrType(AttrType.attrInteger);
        meta_attr_type[3] = new AttrType(AttrType.attrInteger);
        meta_attr_type[4] = new AttrType(AttrType.attrInteger);

        short[] meta_str_sizes = new short[5];
        for(int i=0;i<5;i++)
        {
            meta_str_sizes[i] = (short)40;
        }
        
        try {
            imt_tup.setHdr((short) 5, meta_attr_type, meta_str_sizes);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        int metadata_size = imt_tup.size();
        imt_tup = new Tuple(metadata_size);
        try {
            imt_tup.setHdr((short) 5, meta_attr_type, meta_str_sizes);
        }
        catch (Exception e) {
            e.printStackTrace();
        }

        Scan ifscan = null;
        try {
            file1 = new Heapfile(index_metadata_tablename);
        } catch (Exception e) {
            System.out.println(e);
        }
        int num_recs=0;
        try {
            ifscan = new Scan(file1);
            num_recs = file1.getRecCnt();
        } catch (Exception e) {
            System.out.println(e);
        }

        RID rid = new RID();
        try {
            imt_tup = ifscan.getNext(rid);
        }
        catch (Exception e) {
            e.printStackTrace(); 
        }
        int temp_index_attr_number = -10;
        String temp_index_type = "";
        while (imt_tup != null) 
        {
            try{
                imt_tup.setHdr((short) 5, meta_attr_type, meta_str_sizes);
            }catch(Exception e){
                e.printStackTrace();
            }
            try {
                temp_index_attr_number = imt_tup.getIntFld(3);
                temp_index_type = imt_tup.getStrFld(1);
            }  
            catch (Exception e) {
                e.printStackTrace();
            }
            // store those values and delete the tuple
            if(temp_index_type.equals("CL"))
            {
                break;
            }
            else{
                try {
                    imt_tup = ifscan.getNext(rid);
                }
                catch (Exception e) {
                    e.printStackTrace(); 
                    break;
                }
            }
            // close the scan.
            if(imt_tup == null){
                // clean up
                try {
                    ifscan.closescan();
                    // return;
                }
                catch (Exception e){
                    e.printStackTrace();
                }
            }
        }
        return temp_index_attr_number;
    }
    
    ArrayList<Integer> get_unclustered_keys(String tablename)
    {
        ArrayList<Integer> al = new ArrayList<Integer>();
        Heapfile file1 = null;
        
        String index_metadata_tablename = tablename + "_index_metadata";
        Tuple imt_tup = new Tuple();
        AttrType meta_attr_type[] = new AttrType[5];
        meta_attr_type[0] = new AttrType(AttrType.attrString);
        meta_attr_type[1] = new AttrType(AttrType.attrString);
        meta_attr_type[2] = new AttrType(AttrType.attrInteger);
        meta_attr_type[3] = new AttrType(AttrType.attrInteger);
        meta_attr_type[4] = new AttrType(AttrType.attrInteger);

        short[] meta_str_sizes = new short[5];
        for(int i=0;i<5;i++)
        {
            meta_str_sizes[i] = (short)40;
        }
        
        try {
            imt_tup.setHdr((short) 5, meta_attr_type, meta_str_sizes);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        int metadata_size = imt_tup.size();
        imt_tup = new Tuple(metadata_size);
        try {
            imt_tup.setHdr((short) 5, meta_attr_type, meta_str_sizes);
        }
        catch (Exception e) {
            e.printStackTrace();
        }

        Scan ifscan = null;
        try {
            file1 = new Heapfile(index_metadata_tablename);
        } catch (Exception e) {
            System.out.println(e);
        }
        int num_recs=0;
        try {
            ifscan = new Scan(file1);
            num_recs = file1.getRecCnt();
        } catch (Exception e) {
            System.out.println(e);
        }

        RID rid = new RID();
        try {
            imt_tup = ifscan.getNext(rid);
        }
        catch (Exception e) {
            e.printStackTrace(); 
        }
        int temp_index_attr_number = -10;
        String temp_index_type = "";
        while (imt_tup != null) 
        {
            try{
                imt_tup.setHdr((short) 5, meta_attr_type, meta_str_sizes);
            }catch(Exception e){
                e.printStackTrace();
            }
            try {
                temp_index_attr_number = imt_tup.getIntFld(3);
                temp_index_type = imt_tup.getStrFld(1);
            }  
            catch (Exception e) {
                e.printStackTrace();
            }
            // store those values and delete the tuple
            if(temp_index_type.equals("UC"))
            {
                al.add(temp_index_attr_number);
            }
            else{
                try {
                    imt_tup = ifscan.getNext(rid);
                }
                catch (Exception e) {
                    e.printStackTrace(); 
                    break;
                }
            }
            // close the scan.
            if(imt_tup == null){
                // clean up
                try {
                    ifscan.closescan();
                    // return;
                }
                catch (Exception e){
                    e.printStackTrace();
                }
            }
        }
        if(al.size() == 0)
        {
            al.add(-10);
        }
        return al;
    }

    BTreeFile create_indexfile_sumofprefattr_sorted(String heapfilepath, AttrType[] attr, int num_cols, short[] str_sizes, int[] pref_list) 
    {
        Heapfile f = null;
        try {
            f = new Heapfile(heapfilepath);
        } catch (Exception e1) {
            e1.printStackTrace();
        }

        Scan scan = null;
        try {
            scan = new Scan(f);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // create the index file on the sum of pref attributes
        BTreeFile btf = null;
        try {
            btf = new BTreeFile("indexfile5", AttrType.attrReal, 4, 1/* delete */);
        } catch (Exception e) {
            e.printStackTrace();
            Runtime.getRuntime().exit(1);
        }

        RID rid = new RID();
        float key = 0;
        Tuple temp = null;

        try {
            temp = scan.getNext(rid);
        } catch (Exception e) {
            e.printStackTrace();
        }
        while (temp != null) {
            Tuple t = new Tuple();
            try {
                t.setHdr((short) num_cols, attr, str_sizes);
            } catch (Exception e) {
                e.printStackTrace();
            }
            t = new Tuple(t.size());
            try {
                t.setHdr((short) num_cols, attr, str_sizes);
            } catch (Exception e) {
                e.printStackTrace();
            }
            t.tupleCopy(temp);

            try {
                // find sum of pref attributes for each tuple to compute the key

                int i = 0;
                float sum = 0;
                for (i = 0; i < pref_list.length; i++) {
                    if (attr[pref_list[i] - 1].attrType == AttrType.attrInteger) {
                        try {
                            sum += t.getIntFld(pref_list[i]);
                        } catch (Exception e) {
                            System.out.println(e);
                        }

                    } else if (attr[pref_list[i] - 1].attrType == AttrType.attrReal) {
                        try {
                            sum += t.getFloFld(pref_list[i]);
                        }

                        catch (Exception e) {
                            System.out.println(e);
                        }

                    } else {
                        System.out.println("Not an integer or float so cannot add");
                    }
                }
                key = sum;
            } catch (Exception e) {
                e.printStackTrace();
            }

            try {
                btf.insert(new FloatKey(key), rid);
            } catch (Exception e) {
                e.printStackTrace();
            }

            try {
                temp = scan.getNext(rid);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        // close the file scan
        scan.closescan();
        return btf;
    }

    BTreeFile create_indexfile_sumofprefattr(String heapfilepath, AttrType[] attr, int num_cols, short[] str_sizes, int[] pref_list, int j) {
        Heapfile f = null;

        try {
            f = new Heapfile(heapfilepath);
        } catch (Exception e1) {
            e1.printStackTrace();
        } 

        Scan scan = null;
        try {
            scan = new Scan(f);
        }
        catch (Exception e) {
            e.printStackTrace();
        }

        // create the index file on the sum of pref attributes
        BTreeFile btf = null;
        try {
            btf = new BTreeFile("BTIndex"+j, AttrType.attrReal, 4, 1/* delete */);
        } catch (Exception e) {
            e.printStackTrace();
            Runtime.getRuntime().exit(1);
        }

        RID rid = new RID();
        float key = 0;
        Tuple temp = null;

        try {
            temp = scan.getNext(rid);
        } catch (Exception e) {
            e.printStackTrace();
        }
        while (temp != null) {
            Tuple t = new Tuple();
            try{
                t.setHdr((short)num_cols, attr, str_sizes);
            }catch(Exception e){
                e.printStackTrace();
            }
            t = new Tuple(t.size());
            try{
                t.setHdr((short)num_cols, attr, str_sizes);
            }catch(Exception e){
                e.printStackTrace();
            }
            t.tupleCopy(temp);

            try {
                // find sum of pref attributes for each tuple to compute the key

                int i = 0;
                float sum = 0;
                for (i = 0; i < str_sizes.length; i++) {
                    if (attr[pref_list[j] - 1].attrType == AttrType.attrInteger) {
                        try {
                            sum = t.getIntFld(pref_list[j]);
                        } catch (Exception e) {
                            System.out.println(e);
                        }

                    } else if (attr[pref_list[j] - 1].attrType == AttrType.attrReal) {
                        try {
                            sum = t.getFloFld(pref_list[j]);
                        }

                        catch (Exception e) {
                            System.out.println(e);
                        }

                    } else {
                        System.out.println("Not an integer or float so cannot add");
                    }
                
                key = sum;
            

            try {
                btf.insert(new FloatKey(key), rid);
            } catch (Exception e) {
                e.printStackTrace();
            }

            try {
                temp = scan.getNext(rid);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
        }

        int i=0;
        try{
            BT.printAllLeafPages(btf.getHeaderPage());
        }
        catch(Exception e){
            e.printStackTrace();
        }
        System.out.println(i);

        // close the file scan
        scan.closescan();
        return btf;
    }

    AttrType[] get_attr_types_from_input(String input_filename) throws FileNotFoundException
    {
        AttrType[] temp_attr_type;

        String input_filepath = "Project/Phase 1/minjava/javaminibase/src/input_files/"+input_filename;
        File f1 = new File(input_filepath);
        Scanner scan = new Scanner(f1);
        int num_attributes = Integer.valueOf(scan.nextLine().split(",")[0]);

        temp_attr_type = new AttrType[num_attributes];
        for(int i=0;i<num_attributes;i++)
        {
            String in_line = scan.nextLine();
            String[] tokens = in_line.split(",");
            if(tokens[1].equals("INT"))
            {
                temp_attr_type[i] = new AttrType(AttrType.attrInteger);
            }
            else if(tokens[1].equals("STR"))
            {
                temp_attr_type[i] = new AttrType(AttrType.attrString);
            }
            else
            {
                System.out.println("Wrong attribute type");
                break;
            }
        }
        scan.close();

        return temp_attr_type;
    }

    public void runQueriesInterface() throws UnknowAttrType, LowMemException, Exception  
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter query: ");
        String query;
        query = sc.nextLine();
        while(!query.equals("exit"))
        {
            System.out.println();
            System.out.println("Query: "+query);
            String[] query_terms = query.split(" ", -2);
            int num_terms = query_terms.length;
            PageId pid = new PageId();
            if(query_terms[0].equals("open_database"))
            {
                String db_name = query_terms[1];
                try
                {
                    db_name = query_terms[1];
                }
                catch(Exception e)
                {
                    System.out.println("please enter right attributes");
                    break;
                }
                openDB(db_name);
            }
            else if(query_terms[0].equals("close_database"))
            {
                try 
                {
                    closeDB();
                } 
                catch (Exception e) 
                {
                    e.printStackTrace();
                    System.out.println("error closing db");
                }
            }
            else if(query_terms[0].equals("create_table"))
            {
                String input_filename = "";
                try
                {
                    input_filename = query_terms[1];
                }
                catch(Exception e)
                {
                    System.out.println("please enter right attributes");
                }
                if(input_filename.equals("CLUSTERED"))
                {
                    int key_att_no = 0;
                    try{
                        key_att_no = Integer.valueOf(query_terms[3]);
                        input_filename = query_terms[4];
                    }
                    catch(Exception e)
                    {
                        e.printStackTrace();
                    }
                    pcounter.rcounter = 0;
                    pcounter.wcounter = 0;
                    createTable(input_filename);
                    String heapfilename = input_filename.split("\\.")[0];
                    AttrType[] in1 = get_attr(heapfilename);
                    short[] str_sizes = new short[in1.length];
                    for(int i=0;i<in1.length;i++)
                    {
                        str_sizes[i] = (short)40;
                    }
                    BTreeFileClustered btfc;
                    try{
                        btfc = new BTreeFileClustered(heapfilename, key_att_no-1,in1.length,in1, in1[key_att_no-1], str_sizes);
                    }
                    catch(Exception e)
                    {
                        e.printStackTrace();
                    }

                    AttrType[] meta_data_attrs = new AttrType[5];
                    meta_data_attrs[0] = new AttrType(AttrType.attrString);
                    meta_data_attrs[1] = new AttrType(AttrType.attrString);
                    meta_data_attrs[2] = new AttrType(AttrType.attrInteger);
                    meta_data_attrs[3] = new AttrType(AttrType.attrInteger);
                    meta_data_attrs[4] = new AttrType(AttrType.attrInteger);

                    short[] meta_data_str_sizes = new short[5];
                    meta_data_str_sizes[0] = 40; 
                    meta_data_str_sizes[1] = 40;
                    meta_data_str_sizes[2] = 40;
                    meta_data_str_sizes[3] = 40;
                    meta_data_str_sizes[4] = 40;

                    Tuple meta_tuple = new Tuple();
                    try {
                        meta_tuple.setHdr((short) 5, meta_data_attrs, meta_data_str_sizes);
                    }catch (Exception e) {
                        e.printStackTrace();
                    }
                    int mt_size = meta_tuple.size();
                    meta_tuple = new Tuple(mt_size);
                    try {
                        meta_tuple.setHdr((short) 5, meta_data_attrs, meta_data_str_sizes);
                    }catch (Exception e) {
                        e.printStackTrace();
                    }

                    Heapfile metadata_table = null;
                    try {
                        metadata_table = new Heapfile(heapfilename+"_index_metadata");
                    }
                    catch (Exception e) {
                        e.printStackTrace();
                    }

                    try{
                        meta_tuple.setStrFld(1,"CL");
                        meta_tuple.setStrFld(2,"BTREE");
                        meta_tuple.setIntFld(3,key_att_no);
                        meta_tuple.setIntFld(4,-10);
                        meta_tuple.setIntFld(5,-10);
                    }catch (Exception e) {
                        e.printStackTrace();
                    }
                    try {
                        metadata_table.insertRecord(meta_tuple.returnTupleByteArray());
                    }
                    catch (Exception e) {
                        e.printStackTrace();
                    }

                    System.out.println("Created Clustered Index");
                    System.out.println("Number of Reads: "+pcounter.rcounter);
                    System.out.println("Number of Writes: "+pcounter.wcounter);
                }
                else if(input_filename.equals("HASH"))
                {
                    // ::TODO::
                    // attrType2 = new AttrType[2];
                    // attrType2[0]= attr3[att_num-1];
                    // attrType2[1]= new AttrType(AttrType.attrString);

                    // attrType_lasthf = new AttrType[2];
                    // attrType_lasthf[0]= new AttrType(AttrType.attrInteger);
                    // attrType_lasthf[1]= new AttrType(AttrType.attrInteger);
                    // Iterator am1 = null;
                    // float targetUtilization = 80;
                    // UnclusteredHashIndex uchi = new UnclusteredHashIndex(null, null, att_num, attr3, targetUtilization, am1, tablename, tablename);
                    // //uchi.create_heapfile(tablename+".csv", attr3, attr3.length, stringsize, tablename);
                    // uchi.Insert(attr3, attrType2, attrType_lasthf, tablename, att_num, tablename);
                }
                else
                {
                    createTable(input_filename);
                }
            }
            else if(query_terms[0].equals("output_table"))
            {
                String filename = "";
                try
                {
                    filename = query_terms[1];
                }
                catch(Exception e)
                {
                    System.out.println("please enter valid table name");
                }
                outputTable(filename);
            }
            else if(query_terms[0].equals("insert_data"))
            {
                String filename = "";
                String tablename = "";
                try
                {
                    tablename = query_terms[1];
                    filename = query_terms[2];
                }
                catch(Exception e)
                {
                    System.out.println("please enter valid table and file names");
                }
                insertData(tablename, filename);
            }
            else if(query_terms[0].equals("delete_data"))
            {
                String filename = "";
                String tablename = "";
                try
                {
                    tablename = query_terms[1];
                    filename = query_terms[2];
                }
                catch(Exception e)
                {
                    System.out.println("please enter valid tablename");
                }
                deleteData(tablename, filename);
            }
            else if(query_terms[0].equals("create_index"))
            {
                String index_type = "";
                String tablename = "";
                int att_num = 0;
                try
                {
                    tablename = query_terms[3];
                    index_type = query_terms[1];
                    att_num = Integer.valueOf(query_terms[2]);
                }
                catch(Exception e)
                {
                    System.out.println("please enter valid parameters");
                }
                AttrType[] attr_type = get_attr(tablename);
                int att_int = 0;
                if(attr_type[att_num-1].equals(new AttrType(AttrType.attrInteger)))
                {
                    att_int = 1;
                }
                if(index_type.equals("BTREE"))
                {
                    BTreeFile btf = null;
                    try {
                    btf = new BTreeFile("unclustered"+tablename+String.valueOf(att_num)+"_BT", att_int,40, 1/*delete*/); 
                    }
                    catch (Exception e) 
                    {
                        e.printStackTrace();
                    }
                }
                else if(index_type.equals("HASH"))
                {
                // ::TODO::
                }
            }
            else if(query_terms[0].equals("output_index"))
            {
                String tablename = "";
                int att_num = 0;
                try
                {
                    tablename = query_terms[1];
                    att_num = Integer.valueOf(query_terms[2]);
                }
                catch(Exception e)
                {
                    System.out.println("please enter valid parameters");
                }
                // ::TODO::
            }

            else if(query_terms[0].equals("GROUPBY"))
            {
                GroupBywithSort gbws = null;
                GroupBywithHash gbwh = null;
                try
                {
                    String grpby_type = query_terms[1];
                    String grpby_cond = query_terms[2];
                    int g_att_no = Integer.valueOf(query_terms[3]);
                    String table_name;
                    int num_pages;
                    int agg_att_num[];
                    int num_agg_att = 0;
                    String out_table_name;
                    if(query_terms[num_terms-2].equals("MATER"))
                    {
                        out_table_name = query_terms[num_terms-1];
                        num_pages = Integer.valueOf(query_terms[num_terms-3]);
                        table_name = query_terms[num_terms-4];
                        agg_att_num = new int[num_terms-8];
                        num_agg_att = num_terms-8;
                        for(int k=0;k<num_terms-8;k++)
                        {
                            agg_att_num[k] = Integer.valueOf(query_terms[4+k]);
                        }
                    }
                    else
                    {
                        out_table_name = "";
                        num_pages = Integer.valueOf(query_terms[num_terms-1]);
                        table_name = query_terms[num_terms-2];
                        agg_att_num = new int[num_terms-6];
                        num_agg_att = num_terms-6;
                        for(int k=0;k<num_terms-6;k++)
                        {
                            agg_att_num[k] = Integer.valueOf(query_terms[4+k]);
                        }
                    }
                    /* AttrType[] in1, int len_in1, short[] t1_str_sizes, java.lang.String relationName,
            Iterator am1, FldSpec group_by_attr, AggType agg_type, FldSpec[] agg_list, FldSpec[] proj_list,
            int n_out_flds, int n_pages*/
                    AttrType[] in1 = get_attr(table_name);
                    short[] str_sizes = new short[in1.length];
                    for(int i=0;i<in1.length;i++)
                    {
                        str_sizes[i] = (short)40;
                    }
                    RelSpec rel1 = new RelSpec(RelSpec.outer);
                    FldSpec group_by_attr = new FldSpec(rel1, g_att_no);
                    // int agg_type_num = -10;
                    AggType agg_Type = null;
                    if(grpby_cond.equals("MIN"))
                    {
                        agg_Type = new AggType(AggType.min);
                    }
                    else if(grpby_cond.equals("MAX"))
                    {   
                        agg_Type = new AggType(AggType.max);
                    }
                    else if(grpby_cond.equals("AVG"))
                    {
                        agg_Type = new AggType(AggType.avg);
                    }
                    else if(grpby_cond.equals("SKY"))
                    {
                        agg_Type = new AggType(AggType.skyline);
                    }
                    else
                    {
                        System.out.println("please enter right aggregation function");
                        break;
                    }
                    FldSpec[] agglist = new FldSpec[num_agg_att];
                    for(int i=0;i<num_agg_att;i++)
                    {
                        agglist[i] = new FldSpec(rel1, agg_att_num[i]);
                    }

                    FldSpec[] projlist;
                    RelSpec rel = new RelSpec(RelSpec.outer);

                    if (agg_Type.aggType == AggType.avg) {
                        projlist = new FldSpec[2];
                        for (int i = 0; i < 2; i++) {
                            projlist[i] = new FldSpec(rel, i + 1);
                        }
                    } else {
                        projlist = new FldSpec[in1.length];
                        for (int i = 0; i < in1.length; i++) {
                            projlist[i] = new FldSpec(rel, i + 1);
                        }
                    }

                    if(grpby_type.equals("SORT"))
                    {
                        gbws = new GroupBywithSort(in1, in1.length, str_sizes, table_name, null, group_by_attr, agg_Type, agglist, projlist, in1.length, num_pages);

                        Tuple t = new Tuple();
                        try {
                            t.setHdr((short) in1.length, in1, str_sizes);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        int size = t.size();
                
                        t = new Tuple(size);
                        try {
                            t.setHdr((short) in1.length, in1, str_sizes);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        // if the agg type is average
                        AttrType[] avgatt = new AttrType[2];
                        for (int i = 0; i < 1; i++) {
                            avgatt[i] = in1[projlist[group_by_attr.offset-1].offset - 1];
                        }
                        avgatt[1] = new AttrType(AttrType.attrReal);

                        // if the aggtype is average
                        Tuple avg = new Tuple();
                        try {
                            avg.setHdr((short) (2), avgatt, str_sizes);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        avg = new Tuple(avg.size());
                        try {
                            avg.setHdr((short) (2), avgatt, str_sizes);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        if(agg_Type.aggType == AggType.avg){
                            try {
                                avg = gbws.get_next();
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                    
                            while (avg != null) {
                                try {
                                    avg.print(avgatt);
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                    
                                try {
                                    avg = gbws.get_next();
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                        }
                        else{
                            try {
                                t = gbws.get_next();
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                    
                            while (t != null) {
                                try {
                                    t.print(in1);
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                    
                                try {
                                    t = gbws.get_next();
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                        }

                        gbws.close();
                    }
                    else if(grpby_type.equals("HASH"))
                    {
                        gbwh = new GroupBywithHash(in1, in1.length, str_sizes, table_name, null, group_by_attr, agg_Type, agglist, projlist, in1.length, num_pages, null);

                        Tuple t = new Tuple();
                        try {
                            t.setHdr((short) in1.length, in1, str_sizes);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        int size = t.size();
                
                        t = new Tuple(size);
                        try {
                            t.setHdr((short) in1.length, in1, str_sizes);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        // if the agg type is average
                        AttrType[] avgatt = new AttrType[2];
                        for (int i = 0; i < 1; i++) {
                            avgatt[i] = in1[projlist[group_by_attr.offset-1].offset - 1];
                        }
                        avgatt[1] = new AttrType(AttrType.attrReal);

                        // if the aggtype is average
                        Tuple avg = new Tuple();
                        try {
                            avg.setHdr((short) (2), avgatt, str_sizes);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        avg = new Tuple(avg.size());
                        try {
                            avg.setHdr((short) (2), avgatt, str_sizes);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        if(agg_Type.aggType == AggType.avg){
                            try {
                                avg = gbwh.get_next();
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                    
                            while (avg != null) {
                                try {
                                    avg.print(avgatt);
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                    
                                try {
                                    avg = gbwh.get_next();
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                        }
                        else{
                            try {
                                t = gbwh.get_next();
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                    
                            while (t != null) {
                                try {
                                    t.print(in1);
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                    
                                try {
                                    t = gbwh.get_next();
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                        }

                        gbwh.close();
                    }
                }
                catch(Exception e)
                {
                    e.printStackTrace();
                }
            }

            else if(query_terms[0].equals("JOIN"))
            {
                String join_type = query_terms[1];
                String outer_table_name = query_terms[2];
                int outer_att_num = Integer.valueOf(query_terms[3]);
                String inner_table_name = query_terms[4];
                int inner_att_num = Integer.valueOf(query_terms[5]);
                String operator = query_terms[6];
                int num_pages = Integer.valueOf(query_terms[7]);
                String output_table_name = "";
                if(query_terms[num_terms-2].equals("MATER"))
                {
                    output_table_name = query_terms[num_terms-1];
                }
            }

            else if(query_terms[0].equals("TOPKJOIN"))
            {
                String join_type = query_terms[1];
                int k = Integer.valueOf(query_terms[2]);
                String outer_table_name = query_terms[3];
                int outer_j_att_no = Integer.valueOf(query_terms[4]);
                int outer_m_att_no = Integer.valueOf(query_terms[5]);
                String inner_table_name = query_terms[6];
                int inner_j_att_no = Integer.valueOf(query_terms[7]);
                int inner_m_att_no = Integer.valueOf(query_terms[8]);
                int num_pages = Integer.valueOf(query_terms[9]);
                String output_table_name="";

                AttrType[] in1;
                in1 = new AttrType[3];
                in1[0]= new AttrType(AttrType.attrString);
                in1[1]= new AttrType(AttrType.attrInteger);
                in1[2]= new AttrType(AttrType.attrInteger);

                AttrType[] in2;
                in2 = new AttrType[3];
                in2[0]= new AttrType(AttrType.attrString);
                in2[1]= new AttrType(AttrType.attrInteger);
                in2[2]= new AttrType(AttrType.attrInteger);

                short[] str_sizes = new short[in1.length];
                    for(int i=0;i<in1.length;i++)
                    {
                        str_sizes[i] = (short)40;
                    }

                RelSpec rel = new RelSpec(RelSpec.outer);
                RelSpec rel1 = new RelSpec(RelSpec.innerRel);

                FldSpec inner_j_att_no1 = new FldSpec(rel1, inner_j_att_no);
                FldSpec outer_j_att_no1 = new FldSpec(rel, outer_j_att_no);

                FldSpec inner_m_att_no1 = new FldSpec(rel1, inner_m_att_no);
                FldSpec outer_m_att_no1 = new FldSpec(rel, outer_m_att_no);

                if(query_terms[num_terms-2].equals("MATER"))
                {
                    output_table_name = query_terms[num_terms-1];
                }
                NRAJoin nra = null;
                TopK_HashJoin topkhashjoin = null;
                if(join_type.equals("NRA"))
                {
                     nra = new NRAJoin(in1, in1.length, str_sizes, in2, in2.length, str_sizes, num_pages, inner_table_name, outer_table_name, inner_j_att_no1, inner_m_att_no1, outer_j_att_no1, outer_m_att_no1, k);
                     Tuple t = new Tuple();
                    try {
                        t.setHdr((short) (2*in1.length+1), in1, str_sizes);
                    } catch (Exception e) {
                    }

                    t = new Tuple(t.size());
                    try {
                        t.setHdr((short) (2*in1.length+1), in1, str_sizes);
                    } catch (Exception e) {
                    }

                    try {
                        t = nra.get_next();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    while (t != null) {
                        try {
                            // System.out.println(t.getFloFld(1) + " " + t.getFloFld(2) + " " + t.getFloFld(3) + " " + t.getFloFld(4)+ " " + t.getFloFld(5));
                            ///////////////////////////////////////////
                            for(int j=0;j<(2*in1.length+1);j++)
                            {
                                if(in1[j].attrType == AttrType.attrInteger)
                                {
                                    System.out.print(t.getIntFld(j+1)+ "    ");
                                }
                                else if(in1[j].attrType == AttrType.attrString)
                                {
                                    System.out.print(t.getStrFld(j+1)+ "    ");
                                }
                                else if(in1[j].attrType == AttrType.attrReal)
                                {
                                    System.out.print(t.getFloFld(j+1)+ "    ");
                                }
                            }
                            System.out.println();
                            ///////////////////////////////////////////
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        try {
                            t = nra.get_next();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }

                    if (t == null) {

                        try {
                            nra.close();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
                else if(join_type.equals("HASH"))
                {
                    topkhashjoin = new TopK_HashJoin(in1, in1.length, str_sizes, inner_j_att_no1, inner_m_att_no1, in2, in2.length, str_sizes, outer_j_att_no1, outer_m_att_no1, inner_table_name, outer_table_name, k, num_pages);
                    Tuple t = new Tuple();
                    try {
                        t.setHdr((short) (2*in1.length+1), in1, str_sizes);
                    } catch (Exception e) {
                    }

                    t = new Tuple(t.size());
                    try {
                        t.setHdr((short) (2*in1.length+1), in1, str_sizes);
                    } catch (Exception e) {
                    }

                    try {
                        t = topkhashjoin.get_next();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    while (t != null) {
                        try {
                            // System.out.println(t.getFloFld(1) + " " + t.getFloFld(2) + " " + t.getFloFld(3) + " " + t.getFloFld(4)+ " " + t.getFloFld(5));
                            ///////////////////////////////////////////
                            for(int j=0;j<(2*in1.length+1);j++)
                            {
                                if(in1[j].attrType == AttrType.attrInteger)
                                {
                                    System.out.print(t.getIntFld(j+1)+ "    ");
                                }
                                else if(in1[j].attrType == AttrType.attrString)
                                {
                                    System.out.print(t.getStrFld(j+1)+ "    ");
                                }
                                else if(in1[j].attrType == AttrType.attrReal)
                                {
                                    System.out.print(t.getFloFld(j+1)+ "    ");
                                }
                            }
                            System.out.println();
                            ///////////////////////////////////////////
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        try {
                            t = topkhashjoin.get_next();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }

                    if (t == null) {

                        try {
                            topkhashjoin.close();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
            

                
            }
            
            else if(query_terms[0].equals("skyline"))
            {
                String tablename = "";
                String skyline_type = "";
                int num_pages = 0;
                int pref_att_list[] = null;
                String out_table_name = "";
                try
                {
                    skyline_type = query_terms[1];
                    if(query_terms[num_terms-2].equals("MATER"))
                    {
                        out_table_name = query_terms[num_terms-1];
                        num_pages = Integer.valueOf(query_terms[num_terms-3]);
                        tablename = query_terms[num_terms-4];
                        pref_att_list = new int[num_terms-6];
                        for(int k=0;k<num_terms-6;k++)
                        {
                            pref_att_list[k] = Integer.valueOf(query_terms[2+k]);
                        }
                    }
                    else
                    {
                        out_table_name = "";
                        num_pages = Integer.valueOf(query_terms[num_terms-1]);
                        tablename = query_terms[num_terms-2];
                        pref_att_list = new int[num_terms-4];
                        for(int k=0;k<num_terms-4;k++)
                        {
                            pref_att_list[k] = Integer.valueOf(query_terms[2+k]);
                        }
                    }
                }
                catch(Exception e)
                {
                    e.printStackTrace();
                }
                AttrType[] attr_type = get_attr(tablename);
                short[] str_sizes = new short[attr_type.length];
                for(int i=0;i<attr_type.length;i++)
                {
                    str_sizes[i] = (short)40;
                }

                if(skyline_type.equals("NLS"))
                {
                    NestedLoopsSky nls = null;
                    try{
                        nls = new NestedLoopsSky(attr_type, attr_type.length, str_sizes, null, tablename, pref_att_list, pref_att_list.length, num_pages);
                    }
                    catch(Exception e)
                    {
                        e.printStackTrace();
                    }

                    Tuple t = new Tuple();
                    try {
                        t.setHdr((short) attr_type.length, attr_type, str_sizes);
                    } catch (Exception e) {
                    }

                    t = new Tuple(t.size());
                    try {
                        t.setHdr((short) attr_type.length, attr_type, str_sizes);
                    } catch (Exception e) {
                    }

                    try {
                        t = nls.get_next();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    while (t != null) {
                        try {
                            // System.out.println(t.getFloFld(1) + " " + t.getFloFld(2) + " " + t.getFloFld(3) + " " + t.getFloFld(4)+ " " + t.getFloFld(5));
                            ///////////////////////////////////////////
                            for(int j=0;j<attr_type.length;j++)
                            {
                                if(attr_type[j].attrType == AttrType.attrInteger)
                                {
                                    System.out.print(t.getIntFld(j+1)+ "    ");
                                }
                                else if(attr_type[j].attrType == AttrType.attrString)
                                {
                                    System.out.print(t.getStrFld(j+1)+ "    ");
                                }
                                else if(attr_type[j].attrType == AttrType.attrReal)
                                {
                                    System.out.print(t.getFloFld(j+1)+ "    ");
                                }
                            }
                            System.out.println();
                            ///////////////////////////////////////////
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        try {
                            t = nls.get_next();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }

                    if (t == null) {

                        try {
                            nls.close();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
                else if(skyline_type.equals("BNLS"))
                {
                    BlockNestedLoopSky bnls = null;
                    try{
                        bnls = new BlockNestedLoopSky(attr_type, attr_type.length, str_sizes, null, tablename, pref_att_list, pref_att_list.length, num_pages);
                    }
                    catch(Exception e)
                    {
                        e.printStackTrace();
                    }
                    Tuple t = new Tuple();
                    try {
                        t.setHdr((short) attr_type.length, attr_type, str_sizes);
                    } catch (Exception e) {
                    }

                    t = new Tuple(t.size());
                    try {
                        t.setHdr((short) attr_type.length, attr_type, str_sizes);
                    } catch (Exception e) {
                    }

                    try {
                        t = bnls.get_next();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    while (t != null) {
                        try {
                            // System.out.println(t.getFloFld(1) + " " + t.getFloFld(2) + " " + t.getFloFld(3) + " " + t.getFloFld(4)+ " " + t.getFloFld(5));
                            ///////////////////////////////////////////
                            for(int j=0;j<attr_type.length;j++)
                            {
                                if(attr_type[j].attrType == AttrType.attrInteger)
                                {
                                    System.out.print(t.getIntFld(j+1)+ "    ");
                                }
                                else if(attr_type[j].attrType == AttrType.attrString)
                                {
                                    System.out.print(t.getStrFld(j+1)+ "    ");
                                }
                                else if(attr_type[j].attrType == AttrType.attrReal)
                                {
                                    System.out.print(t.getFloFld(j+1)+ "    ");
                                }
                            }
                            System.out.println();
                            ///////////////////////////////////////////
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        try {
                            t = bnls.get_next();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }

                    if (t == null) {

                        try {
                            bnls.close();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
                else if(skyline_type.equals("SFS"))
                {
                    SortFirstSky sfs = null;
                    try{
                        sfs = new SortFirstSky(attr_type, attr_type.length, str_sizes, null, tablename, pref_att_list, pref_att_list.length, num_pages);
                    }
                    catch(Exception e)
                    {
                        e.printStackTrace();
                    }
                    Tuple t = new Tuple();
                    try {
                        t.setHdr((short) attr_type.length, attr_type, str_sizes);
                    } catch (Exception e) {
                    }

                    t = new Tuple(t.size());
                    try {
                        t.setHdr((short) attr_type.length, attr_type, str_sizes);
                    } catch (Exception e) {
                    }

                    try {
                        t = sfs.get_next();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    while (t != null) {
                        try {
                            // System.out.println(t.getFloFld(1) + " " + t.getFloFld(2) + " " + t.getFloFld(3) + " " + t.getFloFld(4)+ " " + t.getFloFld(5));
                            ///////////////////////////////////////////
                            for(int j=0;j<attr_type.length;j++)
                            {
                                if(attr_type[j].attrType == AttrType.attrInteger)
                                {
                                    System.out.print(t.getIntFld(j+1)+ "    ");
                                }
                                else if(attr_type[j].attrType == AttrType.attrString)
                                {
                                    System.out.print(t.getStrFld(j+1)+ "    ");
                                }
                                else if(attr_type[j].attrType == AttrType.attrReal)
                                {
                                    System.out.print(t.getFloFld(j+1)+ "    ");
                                }
                            }
                            System.out.println();
                            ///////////////////////////////////////////
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        try {
                            t = sfs.get_next();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }

                    if (t == null) {

                        try {
                            sfs.close();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
                else if(skyline_type.equals("BTSS"))
                {
                    Iterator am1 = null;
                    BTreeFile btf = create_indexfile_sumofprefattr_sorted(tablename, attr_type, attr_type.length, str_sizes, pref_att_list);
                    BTreeSortedSky btss = null;
                    try{
                        btss = new BTreeSortedSky(attr_type, attr_type.length, str_sizes, am1 , tablename, pref_att_list, pref_att_list.length, btf, num_pages);
                    }
                    catch(Exception e)
                    {
                        e.printStackTrace();
                    }
                    Tuple t = new Tuple();
                    try {
                        t.setHdr((short) attr_type.length, attr_type, str_sizes);
                    } catch (Exception e) {
                    }

                    t = new Tuple(t.size());
                    try {
                        t.setHdr((short) attr_type.length, attr_type, str_sizes);
                    } catch (Exception e) {
                    }

                    try {
                        t = btss.get_next();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    while (t != null) {
                        try {
                            // System.out.println(t.getFloFld(1) + " " + t.getFloFld(2) + " " + t.getFloFld(3) + " " + t.getFloFld(4)+ " " + t.getFloFld(5));
                            ///////////////////////////////////////////
                            for(int j=0;j<attr_type.length;j++)
                            {
                                if(attr_type[j].attrType == AttrType.attrInteger)
                                {
                                    System.out.print(t.getIntFld(j+1)+ "    ");
                                }
                                else if(attr_type[j].attrType == AttrType.attrString)
                                {
                                    System.out.print(t.getStrFld(j+1)+ "    ");
                                }
                                else if(attr_type[j].attrType == AttrType.attrReal)
                                {
                                    System.out.print(t.getFloFld(j+1)+ "    ");
                                }
                            }
                            System.out.println();
                            ///////////////////////////////////////////
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        try {
                            t = btss.get_next();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }

                    if (t == null) {

                        try {
                            btss.close();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
                else if(skyline_type.equals("BTS"))
                {
                    Iterator am1 = null;
                    BTreeFile[] btf = new BTreeFile[pref_att_list.length];
                    for(int i=0; i<pref_att_list.length; i++)
                    {
                        btf[i]  = create_indexfile_sumofprefattr("unsortedfile", attr_type, attr_type.length, str_sizes, pref_att_list, i);
                    }
                    BTreeSky bts = null;
                    try{
                        bts = new BTreeSky(attr_type, attr_type.length, str_sizes, am1, tablename, pref_att_list, pref_att_list.length, btf ,num_pages);
                    }
                    catch(Exception e)
                    {
                        e.printStackTrace();
                    }
                    Tuple t = new Tuple();
                    try {
                        t.setHdr((short) attr_type.length, attr_type, str_sizes);
                    } catch (Exception e) {
                    }

                    t = new Tuple(t.size());
                    try {
                        t.setHdr((short) attr_type.length, attr_type, str_sizes);
                    } catch (Exception e) {
                    }

                    try {
                        t = bts.get_next();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    while (t != null) {
                        try {
                            // System.out.println(t.getFloFld(1) + " " + t.getFloFld(2) + " " + t.getFloFld(3) + " " + t.getFloFld(4)+ " " + t.getFloFld(5));
                            ///////////////////////////////////////////
                            for(int j=0;j<attr_type.length;j++)
                            {
                                if(attr_type[j].attrType == AttrType.attrInteger)
                                {
                                    System.out.print(t.getIntFld(j+1)+ "    ");
                                }
                                else if(attr_type[j].attrType == AttrType.attrString)
                                {
                                    System.out.print(t.getStrFld(j+1)+ "    ");
                                }
                                else if(attr_type[j].attrType == AttrType.attrReal)
                                {
                                    System.out.print(t.getFloFld(j+1)+ "    ");
                                }
                            }
                            System.out.println();
                            ///////////////////////////////////////////
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        try {
                            t = bts.get_next();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }

                    if (t == null) {
                        try {
                            bts.close();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
            }

            System.out.println();
            System.out.println("-------------------------------------------------");
            System.out.println("Enter query: ");
            query = sc.nextLine();
        }
        sc.close();
    }

}
public class final_integrate {
    public static void main(String[] args) throws UnknowAttrType, LowMemException, Exception
    {
        TaskIntegration ti = new TaskIntegration();
        ti.runQueriesInterface();

        // AttrType temp_attr_type[] = ti.get_attr_types_from_input("three.csv");
        // for(int i=0;i<temp_attr_type.length;i++)
        // {
        //     System.out.println(temp_attr_type[i]);
        // }
    } 
}
