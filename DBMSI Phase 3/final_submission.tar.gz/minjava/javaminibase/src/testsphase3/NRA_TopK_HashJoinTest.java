package testsphase3;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import global.AttrType;
import global.Catalogglobal;
import global.GlobalConst;
import global.RID;
import global.SystemDefs;
import heap.FieldNumberOutOfBoundException;
import heap.FileAlreadyDeletedException;
import heap.HFBufMgrException;
import heap.HFDiskMgrException;
import heap.HFException;
import heap.Heapfile;
import heap.InvalidSlotNumberException;
import heap.InvalidTupleSizeException;
import heap.Tuple;
import iterator.FldSpec;
import iterator.JoinsException;
import iterator.RelSpec;
import iterator.SortException;
import iterator.*;


public class NRA_TopK_HashJoinTest implements GlobalConst, Catalogglobal {
    static void create_heapfile(String input_filepath, AttrType[] attr, int num_cols, short[] str_sizes,
    String output_heapfile) throws InvalidSlotNumberException, InvalidTupleSizeException, HFDiskMgrException, HFBufMgrException, IOException, HFException
    {
    String nameRoot = "task2";
    String dbpath = "/tmp/" + nameRoot + System.getProperty("user.name") + ".minibase-db";
    System.out.println(dbpath);
    SystemDefs sysdef = new SystemDefs(dbpath, 10000, NUMBUF, "Clock");

    // before_creating_heapfile();
    File file = new File(input_filepath);
    ArrayList<Tuple> outerAL = new ArrayList();

    Tuple tup_temp = new Tuple();
    try {
        tup_temp.setHdr((short) num_cols, attr, str_sizes);
    } catch (Exception e) {
        System.out.println(e);
    }
    int size = tup_temp.size(); 
    try {
        tup_temp.setHdr((short) num_cols, attr, str_sizes);
    } catch (Exception e) {
        System.out.println(e);
    }

    try {
        Scanner sc = new Scanner(file);
        String gb = sc.nextLine();
        while (sc.hasNextLine()) {
          //  count++;
            String line = sc.nextLine();
            String[] tokens = line.split(",");
            int k =0;
            for (int i = 0; i < tokens.length; i++) {
                if(tokens[i].equals("")){
                    continue;
                }
                if (attr[k].attrType == AttrType.attrInteger) {
                    tup_temp.setIntFld(i + 1, Integer.parseInt(tokens[i]));
                }
                if (attr[k].attrType == AttrType.attrReal) {
                    tup_temp.setFloFld(k+ 1, Float.parseFloat(tokens[i]));
                }
                if (attr[k].attrType == AttrType.attrString) {
                    tup_temp.setStrFld(i + 1, tokens[i]);
                }
                if (attr[k].attrType == AttrType.attrSymbol) {
                    tup_temp.setStrFld(i + 1, tokens[i]);
                }
                if (attr[k].attrType == AttrType.attrNull) {
                    tup_temp.setStrFld(i + 1, tokens[i]);
                }
                k++;
            }
            outerAL.add(tup_temp);
            tup_temp = new Tuple(size);
            try {
                tup_temp.setHdr((short) num_cols, attr, str_sizes);
            } catch (Exception e) {
                System.out.println(e);
            }
        }
        sc.close();
    } catch (Exception e) {
        e.printStackTrace();
    }

    Heapfile hf = null;
    RID rid;
    try {
        hf = new Heapfile(output_heapfile);
    } catch (Exception e) {
        e.printStackTrace();
    }

    // Tuple tf;
    for (Tuple t : outerAL) {
        try {
            rid = hf.insertRecord(new Tuple(t).returnTupleByteArray());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    System.out.println(hf.getRecCnt());
    Heapfile karan = new Heapfile("rutva1");
    System.out.println(karan.getRecCnt());

    
}   
    public static void main(String[] args) throws FieldNumberOutOfBoundException, JoinsException, SortException, IOException, FileAlreadyDeletedException, InvalidTupleSizeException, HFBufMgrException, HFDiskMgrException, HFException, InvalidSlotNumberException {
        String nameRoot = "task5a";
        String dbpath = "/tmp/" + nameRoot + System.getProperty("user.name") + ".minibase-db";
        SystemDefs sysdef = new SystemDefs(dbpath, 10000, 10000, "Clock");
        String filename1 = "/Users/rutvapatel98/Desktop/minibase_s21-main/r_sii2000_1_75_200.txt";
        String filename2 = "/Users/rutvapatel98/Desktop/minibase_s21-main/r_sii2000_10_75_200.txt";


        // float[] data_1 = new float[10];
        // float[] data_2 = new float[10];
        // float[] data_3 = new float[10];

        AttrType[] attrType = new AttrType[3];
        attrType[0] = new AttrType(AttrType.attrString);
        attrType[1] = new AttrType(AttrType.attrInteger);
        attrType[2] = new AttrType(AttrType.attrInteger);

        short[] str_sizes = new short[1];
        str_sizes[0] = (short) MAXNAME;

        System.out.println("R Relation");


        // for (int i = 0; i < 10; i++) {
        //     data_1[i] = (float) (i+1);
        //     data_2[i] = (float) (i+2);
        //     data_3[i] = (float) (-2 * i + 10);
        //     System.out.println(data_1[i] +  "    " +data_2[i]+ "     " +data_3[i]);
        // }

        create_heapfile(filename1, attrType, attrType.length, str_sizes, "rutva1");

        create_heapfile(filename2, attrType, attrType.length, str_sizes, "relation2");
        
        // create a tuple of appropriate size for outer relation
        Tuple R = new Tuple();
        try {
            R.setHdr((short) attrType.length, attrType, str_sizes);
        } catch (Exception e) {
            e.printStackTrace();
        }
        int size = R.size();

        // create a tuple of appropriate size for inner relation
        Tuple S = new Tuple();
        try {
            S.setHdr((short) attrType.length, attrType, str_sizes);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Create file for outer relation
        RID rid;
        Heapfile Rfile = null;
        try {
            Rfile = new Heapfile("relation1");
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Create file for inner relation
        RID r;
        Heapfile Sfile = null;
        try {
            Sfile = new Heapfile("relation2");
        } catch (Exception e) {
            e.printStackTrace();
        }

        R = new Tuple(size);
        try {
            R.setHdr((short) attrType.length, attrType, str_sizes);
        } catch (Exception e) {
            e.printStackTrace();
        }

        S = new Tuple(size);
        try {
            S.setHdr((short) attrType.length, attrType, str_sizes);
        } catch (Exception e) {
            e.printStackTrace();
        }

        //insert data in first heapfile
        // for (int i = 0; i < data_1.length; i++) {
        //     try {
        //         R.setFloFld(1, data_1[i]);
        //         R.setFloFld(2, data_2[i]);
        //         R.setFloFld(3, data_3[i]);
                
        //     } catch (Exception e) {
        //         e.printStackTrace();
        //     }

        //     try {
        //         rid = Rfile.insertRecord(R.returnTupleByteArray());
        //     } catch (Exception e) {
        //         e.printStackTrace();
        //     }
        // }

        System.out.println("S Relation");

        // for (int i = 0; i < 10; i++) {
        //     data_1[i] = (float) (i+1);
        //     data_2[i] = (float) (i+20);
        //     data_3[i] = (float) (2 * i + 10);
        //     System.out.println(data_1[i] +  "    " +data_2[i]+ "     " +data_3[i]);

        // }

        //  //insert data in second heapfile
        //  for (int i = 0; i < data_1.length; i++) {
        //     try {
        //         S.setFloFld(1, data_1[i]);
        //         S.setFloFld(2, data_2[i]);
        //         S.setFloFld(3, data_3[i]);
        //     } catch (Exception e) {
        //         e.printStackTrace();
        //     }

        //     try {
        //         r = Sfile.insertRecord(S.returnTupleByteArray());
        //     } catch (Exception e) {
        //         e.printStackTrace();
        //     }
        // }

        NRAJoin nraj = null;
        short[] t1_str_sizes = new short[1];
        t1_str_sizes[0] = (short) MAXNAME;

        short[] t1_str_sizes_for_result = new short[1];
        t1_str_sizes_for_result[0] = (short) MAXNAME;

        RelSpec rel = new RelSpec(RelSpec.outer);
        RelSpec relin = new RelSpec(RelSpec.innerRel);

        FldSpec join_attr_1 = new FldSpec(rel, 3);
        FldSpec join_attr_2 = new FldSpec(relin, 3);

        FldSpec mergeAttr1 = new FldSpec(rel, 2);
        FldSpec mergeAttr2 = new FldSpec(rel, 2);
        
        int n_pages = 20;
        AttrType[] x = new AttrType[7];
        x[0] = new AttrType(AttrType.attrString);
        x[1] = new AttrType(AttrType.attrInteger);
        x[2] = new AttrType(AttrType.attrInteger);
        x[3] = new AttrType(AttrType.attrString);
        x[4] = new AttrType(AttrType.attrInteger);
        x[5] = new AttrType(AttrType.attrInteger);
        x[6] = new AttrType(AttrType.attrReal);

        Heapfile hf = new Heapfile("relation1");
        System.out.println(hf.getRecCnt());

        try {
            nraj = new NRAJoin(attrType, attrType.length, t1_str_sizes,attrType, attrType.length, t1_str_sizes, n_pages,"relation1", "relation2",join_attr_1, mergeAttr1, join_attr_2, mergeAttr2, 3);
        } catch (Exception e) {
            e.printStackTrace();
        }

        Tuple ans = new Tuple();
        try{
            ans.setHdr((short) (2*attrType.length + 1), x, t1_str_sizes_for_result);
        }catch(Exception e){
            e.printStackTrace();
        }
        ans = new Tuple(ans.size());
        try{
            ans.setHdr((short) (2*attrType.length + 1), x, t1_str_sizes_for_result);
        }catch(Exception e){
            e.printStackTrace();
        }

        try {
            ans = nraj.get_next();
        } catch (Exception e) {
            e.printStackTrace();
        }

        while (ans != null) {
            try {
                ans.print(x);
            } catch (Exception e) {
                e.printStackTrace();
            }

            try {
                ans = nraj.get_next();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        nraj.close();
    }


   
}
