package testsphase3;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import diskmgr.pcounter;
import global.AggType;
import global.AttrType;
import global.Catalogglobal;
import global.GlobalConst;
import global.RID;
import global.SystemDefs;
import heap.Heapfile;
import heap.Scan;
import heap.Tuple;
import iterator.FldSpec;
import iterator.GroupBywithHash;
import iterator.GroupBywithSort;
import iterator.Iterator;
import iterator.JoinsException;
import iterator.RelSpec;
import iterator.SortException;

public class GroupBywithHashTest implements GlobalConst, Catalogglobal {

    static void create_heapfile(String input_filepath, AttrType[] attr, int num_cols, short[] str_sizes,
        String output_heapfile)
        {
        String nameRoot = "phase3task3b";
        String dbpath = "/tmp/" + nameRoot + System.getProperty("user.name") + ".minibase-db";
        //System.out.println(dbpath);
        SystemDefs sysdef = new SystemDefs(dbpath, 10000, NUMBUF, "Clock");

        // before_creating_heapfile();
        File file = new File(input_filepath);
        ArrayList<Tuple> outerAL = new ArrayList();

        Tuple tup_temp = new Tuple();
        try {
            tup_temp.setHdr((short) num_cols, attr, str_sizes);
        } catch (Exception e) {
            System.out.println(e);
        }
        int size = tup_temp.size();
        tup_temp = new Tuple(size);
        try {
            tup_temp.setHdr((short) num_cols, attr, str_sizes);
        } catch (Exception e) {
            System.out.println(e);
        }

        try {
            Scanner sc = new Scanner(file);
            String gb = sc.nextLine();
            while (sc.hasNextLine()) {
              //  count++;
                String line = sc.nextLine();
                String[] tokens = line.split(",");
                int k =0;
                for (int i = 0; i < tokens.length; i++) {
                    if(tokens[i].equals("")){
                        continue;
                    }
                    if (attr[k].attrType == AttrType.attrInteger) {
                        tup_temp.setIntFld(i + 1, Integer.parseInt(tokens[i]));
                    }
                    if (attr[k].attrType == AttrType.attrReal) {
                        tup_temp.setFloFld(k+ 1, Float.parseFloat(tokens[i]));
                    }
                    if (attr[k].attrType == AttrType.attrString) {
                        tup_temp.setStrFld(i + 1, tokens[i]);
                    }
                    if (attr[k].attrType == AttrType.attrSymbol) {
                        tup_temp.setStrFld(i + 1, tokens[i]);
                    }
                    if (attr[k].attrType == AttrType.attrNull) {
                        tup_temp.setStrFld(i + 1, tokens[i]);
                    }
                    k++;
                }
                outerAL.add(tup_temp);
                tup_temp = new Tuple(size);
                try {
                    tup_temp.setHdr((short) num_cols, attr, str_sizes);
                } catch (Exception e) {
                    System.out.println(e);
                }
            }
            sc.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        Heapfile hf = null;
        RID rid;
        try {
            hf = new Heapfile(output_heapfile);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Tuple tf;
        for (Tuple t : outerAL) {
            try {
                rid = hf.insertRecord(new Tuple(t).returnTupleByteArray());
                //t.print(attr);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        
    }   
    public static void main(String[] args) throws JoinsException, SortException, IOException{
        String nameRoot = "phase3task3a";
        String dbpath = "/tmp/" + nameRoot + System.getProperty("user.name") + ".minibase-db";
        SystemDefs sysdef = new SystemDefs(dbpath, 10000, 10000, "Clock");

        AttrType[] attrType = new AttrType[3];
        attrType[0] = new AttrType(AttrType.attrString);
        attrType[1] = new AttrType(AttrType.attrInteger);
        attrType[2] = new AttrType(AttrType.attrInteger);

        short[] str_sizes = new short[2];
        str_sizes[0] = 32;
        str_sizes[1] = 64;

        // create a tuple of appropriate size
        Tuple t = new Tuple();
        try {
           t.setHdr((short)attrType.length, attrType, str_sizes);
        } catch (Exception e) {
            e.printStackTrace();
        }
        int size = t.size();

        t = new Tuple(size);
        try {
            t.setHdr((short)attrType.length, attrType, str_sizes);
        } catch (Exception e) {
            e.printStackTrace();
        }

        GroupBywithHash gbws = null;
        short[] t1_str_sizes = new short[1];
        t1_str_sizes[0]=(short) MAXNAME;
        Iterator am1 = null;

        AggType aggType = new AggType(AggType.skyline);
        
        FldSpec[] projlist;
        RelSpec rel = new RelSpec(RelSpec.outer); 
        if (aggType.aggType == AggType.avg) {
            projlist = new FldSpec[2];
            for (int i = 0; i < 2; i++) {
                projlist[i] = new FldSpec(rel, i + 1);
            }
        } else {
            projlist = new FldSpec[attrType.length];
            for (int i = 0; i < attrType.length; i++) {
                projlist[i] = new FldSpec(rel, i + 1);
            }
        }

        FldSpec[] agglist = new FldSpec[2];
        RelSpec rel1 = new RelSpec(RelSpec.outer);
        agglist[0] = new FldSpec(rel1, 2);
        agglist[1] = new FldSpec(rel1, 3);
        String filename = "/Users/riya/Documents/DBMSI/Project/Phase 1/minjava/javaminibase/src/input_files/Phase3_report_dataset/r_sii2000_10_10_10.txt";
        String datafilename = "hashindex";
        create_heapfile(filename, attrType, attrType.length, str_sizes, datafilename);

        //for the reads and writes
        pcounter.rcounter = 0;
        pcounter.wcounter = 0;

        try {
            gbws = new GroupBywithHash(attrType, attrType.length, t1_str_sizes, datafilename, am1, projlist[0],
                    aggType, agglist, null, 2, 20, null);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // if the agg type is average
        AttrType[] avgatt = new AttrType[2];
        for (int i = 0; i < 1; i++) {
            avgatt[i] = attrType[projlist[0].offset - 1];
        }
        avgatt[1] = new AttrType(AttrType.attrReal);

        // if the aggtype is average
        Tuple avg = new Tuple();
        try {
            avg.setHdr((short) (2), avgatt, str_sizes);
        } catch (Exception e) {
            e.printStackTrace();
        }
        avg = new Tuple(avg.size());
        try {
            avg.setHdr((short) (2), avgatt, str_sizes);
        } catch (Exception e) {
            e.printStackTrace();
        }

        if(aggType.aggType == AggType.avg){
            try {
                avg = gbws.get_next();
            } catch (Exception e) {
                e.printStackTrace();
            }
    
            while (avg != null) {
                try {
                    avg.print(avgatt);
                } catch (IOException e) {
                    e.printStackTrace();
                }
    
                try {
                    avg = gbws.get_next();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        else{
            try {
                t = gbws.get_next();
            } catch (Exception e) {
                e.printStackTrace();
            }
    
            while (t != null) {
                try {
                    t.print(attrType);
                } catch (IOException e) {
                    e.printStackTrace();
                }
    
                try {
                    t = gbws.get_next();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

        gbws.close();

        System.out.printf("Number of reads: %d \n", pcounter.rcounter);
        System.out.printf("Number of writes: %d \n", pcounter.wcounter);
    }
}
