package testsphase3;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import HashIndex.*;
import diskmgr.pcounter;
import global.AttrType;
import global.RID;
import global.SystemDefs;
import heap.HFBufMgrException;
import heap.HFDiskMgrException;
import heap.Heapfile;
import heap.InvalidSlotNumberException;
import heap.InvalidTupleSizeException;
import heap.Tuple;
import iterator.HashIndexScan;
import iterator.Iterator;

public class HashIndextest {
    private static final int NUMBUF = 1000;

    static void create_heapfile(String input_filepath, AttrType[] attr, int num_cols, short[] str_sizes,
        String output_heapfile) throws InvalidSlotNumberException, InvalidTupleSizeException, HFDiskMgrException, HFBufMgrException, IOException
        {
        String nameRoot = "task2";
        String dbpath = "/tmp/" + nameRoot + System.getProperty("user.name") + ".minibase-db";
        System.out.println(dbpath);
        SystemDefs sysdef = new SystemDefs(dbpath, 100000, NUMBUF, "Clock");

        // before_creating_heapfile();
        File file = new File(input_filepath);
        ArrayList<Tuple> outerAL = new ArrayList();

        Tuple tup_temp = new Tuple();
        try {
            tup_temp.setHdr((short) num_cols, attr, str_sizes);
        } catch (Exception e) {
            System.out.println(e);
        }
        int size = tup_temp.size();
        tup_temp = new Tuple(size);
        try {
            tup_temp.setHdr((short) num_cols, attr, str_sizes);
        } catch (Exception e) {
            System.out.println(e);
        }

        try {
            Scanner sc = new Scanner(file);
            String gb = sc.nextLine();
            while (sc.hasNextLine()) {
              //  count++;
                String line = sc.nextLine();
                String[] tokens = line.split(",");
                int k =0;
                for (int i = 0; i < tokens.length; i++) {
                    if(tokens[i].equals("")){
                        continue;
                    }
                    if (attr[k].attrType == AttrType.attrInteger) {
                        tup_temp.setIntFld(i + 1, Integer.parseInt(tokens[i]));
                    }
                    if (attr[k].attrType == AttrType.attrReal) {
                        tup_temp.setFloFld(k+ 1, Float.parseFloat(tokens[i]));
                    }
                    if (attr[k].attrType == AttrType.attrString) {
                        tup_temp.setStrFld(i + 1, tokens[i]);
                    }
                    if (attr[k].attrType == AttrType.attrSymbol) {
                        tup_temp.setStrFld(i + 1, tokens[i]);
                    }
                    if (attr[k].attrType == AttrType.attrNull) {
                        tup_temp.setStrFld(i + 1, tokens[i]);
                    }
                    k++;
                }
                outerAL.add(tup_temp);
                tup_temp = new Tuple(size);
                try {
                    tup_temp.setHdr((short) num_cols, attr, str_sizes);
                } catch (Exception e) {
                    System.out.println(e);
                }
            }
            sc.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        Heapfile hf = null;
        RID rid;
        try {
            hf = new Heapfile(output_heapfile);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Tuple tf;
        for (Tuple t : outerAL) {
            try {
                rid = hf.insertRecord(new Tuple(t).returnTupleByteArray());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        System.out.println("Records in Data file: "+hf.getRecCnt());
        
    }    
    
    public static void main(String Args[]) throws Exception
    {
        short[] Psizes = {};
        short[] stringsize = new short[2];
        stringsize[0] = 32;
        stringsize[1] = 64;
        String filename = "r_sii2000_1_75_200.txt";
        String tablename = "r_sii2000_1_75_200";
        String filenameToInsert = "/Users/rutvapatel98/Desktop/minibase_s21-main/data2insert.txt";

        AttrType[] attrs;
        int num_cols = 3;
        attrs = new AttrType[5];
        for(int i = 0; i< 5; i++){
            attrs[i] = new AttrType(AttrType.attrReal);
        }
        int sizeOfInt = 4;
        int sizeOfFloat = 4;
        int max = 10;   // comes from attrData char strVal[10]
        if (sizeOfInt > max)
        max = (short) sizeOfInt;
        if (sizeOfFloat > max)
        max = (short) sizeOfFloat;
        
        short[] str_sizes = new short[1];
        str_sizes[0] = (short) max;
        Iterator am1 = null;
        short[] t1_str_sizes = new short[attrs.length];        
        float targetUtilization = 80;

        AttrType[] attr3;
        attr3 = new AttrType[3];
        attr3[0] = new AttrType(AttrType.attrString);
        attr3[1] = new AttrType(AttrType.attrInteger);
        attr3[2] = new AttrType(AttrType.attrInteger);

        Tuple tuple = new Tuple();
        try {
            tuple.setHdr((short) num_cols, attr3, stringsize);
        } catch (Exception e) {
            System.out.println(e);
        }
        tuple.setIntFld(1, 22);
        tuple.setIntFld(2, 0);
        tuple.setIntFld(3, 0);

        Tuple tupletodelete = new Tuple();
        try {
            tupletodelete.setHdr((short) num_cols, attr3, stringsize);
        } catch (Exception e) {
            System.out.println(e);
        }
        tupletodelete.setStrFld(1, "1aaaaaaaa");
        tupletodelete.setIntFld(2, 35);
        tupletodelete.setIntFld(3, 25);
        int prefAttr = 1;

        String datafilename = tablename;
        //for unclustered hash index (insertion and table creation)
        //create_heapfile(filename, attr3, attr3.length, stringsize, datafilename);
        pcounter.rcounter =0;
        pcounter.wcounter=0;
        AttrType[] attrType_lasthf;
        attrType_lasthf = new AttrType[2];
        attrType_lasthf[0]= new AttrType(AttrType.attrInteger);
        attrType_lasthf[1]= new AttrType(AttrType.attrInteger);

        AttrType[] attr2;
        attr2 = new AttrType[2];
        attr2[0]= attr3[prefAttr-1];
        attr2[1]= new AttrType(AttrType.attrString);
       //UnclusteredHashIndex uchi = new UnclusteredHashIndex(tablename, tuple, prefAttr, attr3 , targetUtilization, am1, tablename, datafilename);
       //uchi.Insert(attr3, attr2, attrType_lasthf, tablename, prefAttr, datafilename);
       //for clustered hash index (insertion and table creation)
       ClusteredHashIndex chi;


       chi = new ClusteredHashIndex(filename, prefAttr, attr3 , targetUtilization, am1, tablename, datafilename);

       //chi.Delete(tupletodelete, tablename, prefAttr, attr3, datafilename);


        //scan unclustered index

        // HashIndexScan hius;
        // hius = new HashIndexScan(datafilename, "indexfilename", attr3, tablename, prefAttr,2,"2" );
        // Tuple tuc = new Tuple();
        // while(tuc!=null)
        // {
        //     try{
        //         tuc = hius.get_next_unclustered();
        //         if(tuc==null)
        //         {
        //             System.out.println("the iterator for unclustered index ends");
        //             break;
        //         }
        //         try{
        //             tuc.setHdr((short)num_cols, attr3, stringsize);
        //         }catch(Exception e){
    
        //         }
        //         tuc.print(attr3);
        //     }
        //     catch (Exception e) {
        //         e.printStackTrace();
        //     }
        // }



        //scan clustered index
        HashIndexScan hfs;
        int equalityKey = 2;
        String equalityValue = "8";

        hfs = new HashIndexScan(datafilename, "indexfilename", attr3, "tableName", prefAttr, equalityKey, equalityValue);
        System.out.printf("Number of reads: %d \n", pcounter.rcounter);
        System.out.printf("Number of writes: %d \n", pcounter.wcounter);
    //     Tuple t = new Tuple();

    //     while(t!=null)
    //     {
    //     try {

    //         t = hfs.get_next();
    //         if(t==null)
    //             {
    //             System.out.println("the iterator ends");
    //             break;
    //             }
    //         try{
    //             t.setHdr((short)num_cols, attr3, stringsize);
    //         }catch(Exception e){

    //         }
    //         t.print(attr3);
    //     } 
    //     catch (Exception e) {
    //         e.printStackTrace();
    //     }
    // }


        //

    //     Tuple t3b = new Tuple();

    //     while(t3b!=null)
    //     {
    //     try {
    //         t3b = hfs.get_next_withKey_unclustered();
    //         if(t3b==null)
    //             {
    //             System.out.println("the iterator ends");
    //             break;
    //             }
    //         try{
    //             t3b.setHdr((short)num_cols, attr3, stringsize);
    //         }catch(Exception e){

    //         }
    //         t3b.print(attr3);
    //     } 
    //     catch (Exception e) {
    //         e.printStackTrace();
    //     }
    // }



    // Tuple t3b = new Tuple();

    //     while(t3b!=null)
    //     {
    //     try {
    //         t3b = hfs.get_next_withKey_clustered();
    //         if(t3b==null)
    //             {
    //             System.out.println("the iterator ends");
    //             break;
    //             }
    //         try{
    //             t3b.setHdr((short)num_cols, attr3, stringsize);
    //         }catch(Exception e){

    //         }
    //         t3b.print(attr3);
    //     } 
    //     catch (Exception e) {
    //         e.printStackTrace();
    //     }
    // }
    }

   
}
