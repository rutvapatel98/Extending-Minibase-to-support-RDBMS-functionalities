package testsphase3;

import java.io.IOException;

import btree.BTreeFile;
import btree.FloatKey;
import global.*;
import heap.*;
import iterator.*;

public class IndexNestedLoopJoinsTest implements GlobalConst, Catalogglobal {
    public static void main(String[] args) throws FieldNumberOutOfBoundException, JoinsException, SortException,
            IOException, InvalidSlotNumberException, InvalidTupleSizeException, HFDiskMgrException, HFBufMgrException {
        String nameRoot = "task4a";
        String dbpath = "/tmp/" + nameRoot + System.getProperty("user.name") + ".minibase-db";
        SystemDefs sysdef = new SystemDefs(dbpath, 10000, 10000, "Clock");

        float[] data_1 = new float[10];
        float[] data_2 = new float[10];
        float[] data_3 = new float[10];

        AttrType[] attrType = new AttrType[3];
        attrType[0] = new AttrType(AttrType.attrReal);
        attrType[1] = new AttrType(AttrType.attrReal);
        attrType[2] = new AttrType(AttrType.attrReal);

        short[] str_sizes = new short[1];
        str_sizes[0] = (short) MAXNAME;

        for (int i = 0; i < 10; i++) {
            data_1[i] = (float) (i + 1);
            data_2[i] = (float) (i + 2);
            data_3[i] = (float) (-2 * i + 10);
        }

        // create a tuple of appropriate size for outer relation
        Tuple R = new Tuple();
        try {
            R.setHdr((short) attrType.length, attrType, str_sizes);
        } catch (Exception e) {
            e.printStackTrace();
        }
        int size = R.size();

        // create a tuple of appropriate size for inner relation
        Tuple S = new Tuple();
        try {
            S.setHdr((short) attrType.length, attrType, str_sizes);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Create file for outer relation
        RID rid;
        Heapfile Rfile = null;
        try {
            Rfile = new Heapfile("relation1");
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Create file for inner relation
        RID r;
        Heapfile Sfile = null;
        try {
            Sfile = new Heapfile("relation2");
        } catch (Exception e) {
            e.printStackTrace();
        }

        R = new Tuple(size);
        try {
            R.setHdr((short) attrType.length, attrType, str_sizes);
        } catch (Exception e) {
            e.printStackTrace();
        }

        S = new Tuple(size);
        try {
            S.setHdr((short) attrType.length, attrType, str_sizes);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // insert data in first heapfile
        for (int i = 0; i < data_1.length; i++) {
            try {
                R.setFloFld(1, data_1[i]);
                R.setFloFld(2, data_2[i]);
                R.setFloFld(3, data_3[i]);
            } catch (Exception e) {
                e.printStackTrace();
            }

            try {
                rid = Rfile.insertRecord(R.returnTupleByteArray());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        for (int i = 0; i < 10; i++) {
            data_1[i] = (float) (i + 1);
            data_2[i] = (float) (i + 20);
            data_3[i] = (float) (2 * i + 10);
        }

        // insert data in second heapfile
        for (int i = 0; i < data_1.length; i++) {
            try {
                S.setFloFld(1, data_1[i]);
                S.setFloFld(2, data_2[i]);
                S.setFloFld(3, data_3[i]);
            } catch (Exception e) {
                e.printStackTrace();
            }

            try {
                r = Sfile.insertRecord(S.returnTupleByteArray());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        // scan on the inner relation
        Scan inner = null;
        try {
            inner = new Scan(Sfile);
        } catch (Exception e) {
            e.printStackTrace();
        }

        IndexNestedLoopJoins inlj = null;
        short[] t1_str_sizes = new short[1];
        t1_str_sizes[0] = (short) MAXNAME;
        Iterator am1 = null;

        FldSpec[] projlist = new FldSpec[2 * attrType.length];
        RelSpec rel = new RelSpec(RelSpec.outer);
        RelSpec relin = new RelSpec(RelSpec.innerRel);
        for (int i = 0; i < 2 * attrType.length; i++) {
            if (i < attrType.length) {
                projlist[i] = new FldSpec(rel, i + 1);
            } else {
                projlist[i] = new FldSpec(relin, i + 1 - attrType.length);
            }
        }

        FldSpec join_attr_1 = new FldSpec(rel, 1);
        FldSpec join_attr_2 = new FldSpec(relin, 1);

        CondExpr[] outFilter = new CondExpr[2];
        outFilter[1] = null;
        outFilter[0] = new CondExpr();
        outFilter[0].op = new AttrOperator(AttrOperator.aopEQ);
        outFilter[0].type1 = new AttrType(AttrType.attrSymbol);
        outFilter[0].operand1.symbol = new FldSpec(rel, 1);
        outFilter[0].type2 = new AttrType(AttrType.attrSymbol);
        outFilter[0].operand2.symbol = new FldSpec(relin, 1);

        int n_pages = 20;
        AttrType[] x = new AttrType[6];
        x[0] = new AttrType(AttrType.attrReal);
        x[1] = new AttrType(AttrType.attrReal);
        x[2] = new AttrType(AttrType.attrReal);
        x[3] = new AttrType(AttrType.attrReal);
        x[4] = new AttrType(AttrType.attrReal);
        x[5] = new AttrType(AttrType.attrReal);

        // **********************

        BTreeFile btf = null;
        try {
            btf = new BTreeFile("innerindex", AttrType.attrReal, 4, 1/* delete */);
        } catch (Exception e) {
            e.printStackTrace();
            Runtime.getRuntime().exit(1);
        }

        // System.out.println("BTreeIndex created successfully.\n");

        rid = new RID();
        float key = 0;
        Tuple temp = null;

        try {
            S.setHdr((short) attrType.length, attrType, str_sizes);
        } catch (Exception e) {
            e.printStackTrace();
        }

        S = new Tuple(size);
        try {
            S.setHdr((short) attrType.length, attrType, str_sizes);
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            S.tupleCopy(inner.getNext(rid));
        } catch (Exception e) {
            e.printStackTrace();
        }
        int count = 1;
        while (count < Sfile.getRecCnt()) {
            // S.tupleCopy(temp);

            count++;

            try {
                // find sum of pref attributes for each tuple to compute the key

                int i = 0;
                key = S.getFloFld(1);
            } catch (Exception e) {
                e.printStackTrace();
            }

            try {
                btf.insert(new FloatKey(key), rid);
            } catch (Exception e) {
                e.printStackTrace();
            }

            try {
                S.setHdr((short) attrType.length, attrType, str_sizes);
            } catch (Exception e) {
                e.printStackTrace();
            }

            S = new Tuple(size);
            try {
                S.setHdr((short) attrType.length, attrType, str_sizes);
            } catch (Exception e) {
                e.printStackTrace();
            }

            try {
                S.tupleCopy(inner.getNext(rid));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        // close the file scan
        inner.closescan();

        // **********************

        try {
            inlj = new IndexNestedLoopJoins(attrType, attrType.length, t1_str_sizes, attrType, attrType.length,
                    t1_str_sizes, n_pages, "relation1", "relation2", projlist, 2 * attrType.length, "innerindex",
                    outFilter);
        } catch (Exception e) {
            e.printStackTrace();
        }

        Tuple ans = new Tuple();
        try {
            ans.setHdr((short) (2 * attrType.length), x, t1_str_sizes);
        } catch (Exception e) {
            e.printStackTrace();
        }
        ans = new Tuple(ans.size());
        try {
            ans.setHdr((short) (2 * attrType.length), x, t1_str_sizes);
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            ans = inlj.get_next();
        } catch (Exception e) {
            e.printStackTrace();
        }

        while (ans != null) {
            try {
                ans.print(x);
            } catch (Exception e) {
                e.printStackTrace();
            }

            try {
                ans = inlj.get_next();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        inlj.close();
    }
}
