package testsphase3;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import diskmgr.DB;
import global.AttrType;
import global.GlobalConst;
import global.PageId;
import global.RID;
import global.SystemDefs;
import heap.HFBufMgrException;
import heap.HFDiskMgrException;
import heap.Heapfile;
import heap.InvalidSlotNumberException;
import heap.InvalidTupleSizeException;
import heap.Scan;
import heap.Tuple;
import iterator.FileScan;
import iterator.FldSpec;
import iterator.RelSpec;
import tests.TestDriver;


class integrate extends TestDriver implements GlobalConst{
    public static void create_data_heapfile(String input_filepath, String table_name) throws InvalidSlotNumberException, InvalidTupleSizeException, HFDiskMgrException, HFBufMgrException, IOException
    {
        File file = new File(input_filepath);
        Heapfile table_hf = null;
        RID rid;
        ArrayList<Tuple> outerAL = new ArrayList();
        boolean file_exists = true;

        Tuple tup_temp = new Tuple();
        if(file.exists())
        {
            file_exists = true;
        }
        else
        {
            //create a new heapfile(table)
            file_exists = false;
            try {
                table_hf = new Heapfile(table_name);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        //open scanner and read top few lines, parse and call insert_into_schema
        try 
        {
            Scanner sc = new Scanner(file);
            int num_attributes = Integer.valueOf(sc.nextLine());
            short str_sizes[] = new short[num_attributes];
            for(int i=0;i<num_attributes;i++)
            {
                str_sizes[i] = (short)100;
            }

            String attr_name[] = new String[num_attributes];
            AttrType attr_type[] = new AttrType[num_attributes];
            String conc_attr_name = "";
            String conc_attr_type = "";
            for(int i=0;i<num_attributes;i++)
            {
                String in_line = sc.nextLine();
                String[] tokens = in_line.split(" ");
                attr_name[i] = tokens[0];
                if(tokens[1].equals("INT"))
                {
                    attr_type[i] = new AttrType(AttrType.attrInteger);
                }
                else if(tokens[1].equals("STR"))
                {
                    attr_type[i] = new AttrType(AttrType.attrString);
                }
                else
                {
                    System.out.println("Wrong attribute type");
                }
                if(i==0)
                {
                    conc_attr_name += attr_name[i];
                    conc_attr_type += tokens[1];
                }
                else{
                    conc_attr_name += "+"+attr_name[i];
                    conc_attr_type += "+"+tokens[1];
                }
                // System.out.println(attr_type[i]+"___"+attr_name[i]);
            }
            System.out.println(conc_attr_type+"___"+conc_attr_name);
            //comment the if part while testing, to check if tuple is added to schema file
            if(!file_exists)
            {
                insert_into_schema_heapfile(conc_attr_name, conc_attr_type, table_name);
            }
            int count = 0;
            while(sc.hasNextLine())
            {
                count++;
                String line = sc.nextLine();
                String[] tokens = line.split(" ");
                if(tokens.length != num_attributes)
                {
                    System.out.println("Number of attributes not matching");
                    break;
                }
                else
                {
                    //create a tuple {{{{{{  CHANGE STRING SIZES}}}}}}
                    tup_temp = new Tuple();
                    try {
                        tup_temp.setHdr((short) num_attributes, attr_type, str_sizes);
                    } catch (Exception e) {
                        System.out.println(e);
                    }
                    int size = tup_temp.size();
                    tup_temp = new Tuple(size);
                    try {
                        tup_temp.setHdr((short) num_attributes, attr_type, str_sizes);
                    } catch (Exception e) {
                        System.out.println(e);
                    }
                    
                    // insert tuple in the heapfile(table)
                    for (int i = 0; i < num_attributes; i++) {
                        if (attr_type[i].attrType == AttrType.attrInteger) {
                            tup_temp.setIntFld(i + 1, Integer.parseInt(tokens[i]));
                        }
                        if (attr_type[i].attrType == AttrType.attrReal) {
                            tup_temp.setFloFld(i + 1, Float.parseFloat(tokens[i]));
                        }
                        if (attr_type[i].attrType == AttrType.attrString) {
                            tup_temp.setStrFld(i + 1, tokens[i]);
                        }
                        if (attr_type[i].attrType == AttrType.attrSymbol) {
                            tup_temp.setStrFld(i + 1, tokens[i]);
                        }
                        if (attr_type[i].attrType == AttrType.attrNull) {
                            tup_temp.setStrFld(i + 1, tokens[i]);
                        }
                    }
                    outerAL.add(tup_temp);
                    tup_temp = new Tuple(size);
                    try {
                        tup_temp.setHdr((short) num_attributes, attr_type, str_sizes);
                    } catch (Exception e) {
                        System.out.println(e);
                    }
                }
            }
            System.out.println(count);
            sc.close();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        //Then read the remaining lines and write them into the table
        // }
        try{
            // hf = new Heapfile("testheapfile2.in");
            table_hf = new Heapfile(table_name);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        Tuple t = new Tuple();
        
        //set headers
        AttrType[] temp_attr = new AttrType[3];
        temp_attr[0] = new AttrType(AttrType.attrString);
        temp_attr[1] = new AttrType(AttrType.attrInteger);
        temp_attr[2] = new AttrType(AttrType.attrInteger);
        short[] temp_str_sizes = new short[3];
        temp_str_sizes[0] = 100;
        temp_str_sizes[1] = 100;
        temp_str_sizes[2] = 100;
        try {
            t.setHdr((short) 3, temp_attr, temp_str_sizes);
        } catch (Exception e) {
            System.out.println(e);
        }
        int size = tup_temp.size();
        t = new Tuple(size);
        try {
            t.setHdr((short) 3, temp_attr, temp_str_sizes);
        } catch (Exception e) {
            System.out.println(e);
        }

        // for(Tuple t:outerAL) 
        for(int i=0;i<outerAL.size();i++) 
        {
            try{
                t = outerAL.get(i);
                rid = table_hf.insertRecord(t.returnTupleByteArray());
                
            }
            catch (Exception e) {
                e.printStackTrace();
            }
            // PageId tmpId = new PageId();

            // try {
            // tmpId = SystemDefs.JavabaseDB.get_file_entry(table_name);
            // }
            // catch (Exception e) {
            //     e.printStackTrace();
            // }

            try {
                t.setHdr((short) 3, temp_attr, temp_str_sizes);
            } catch (Exception e) {
                System.out.println(e);
            }
            size = tup_temp.size();
            t = new Tuple(size);
            try {
                t.setHdr((short) 3, temp_attr, temp_str_sizes);
            } catch (Exception e) {
                System.out.println(e);
            }
        }
        System.out.println(table_hf.getRecCnt());
    }

    static public void print_from_heapfile(String heapfile_name,int num_cols, AttrType[] attrtype, short[] str_sizes)
    {
        Heapfile hf = null;
        int n =0;
        try{
            hf = new Heapfile(heapfile_name);
            n = hf.getRecCnt();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println(n);
        FldSpec[] projlist = new FldSpec[3];
        RelSpec rel = new RelSpec(RelSpec.outer); 
        projlist[0] = new FldSpec(rel, 1);
        projlist[1] = new FldSpec(rel, 2);
        projlist[2] = new FldSpec(rel, 3);
        
        FileScan fscan = null;
        
        try {
            fscan = new FileScan(heapfile_name, attrtype, str_sizes, (short) num_cols, 3, projlist, null);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        Tuple t = new Tuple();
        try {
            t.setHdr((short) num_cols, attrtype, str_sizes);
          }
          catch (Exception e) {
            e.printStackTrace();
        }
        try {
            t = fscan.get_next();
        }
        catch (Exception e) {
            e.printStackTrace(); 
        }

        // int i=0;
        while(t!=null)
        {
            // System.out.println("Count: "+Integer.toString(i++));
            for(int i=0;i<num_cols;i++)
            {
                System.out.print("Column "+Integer.toString(i+1)+": ");
                try {
                    if(attrtype[i].attrType == AttrType.attrReal)
                    {
                        System.out.print(t.getFloFld(i+1));
                    }
                    if(attrtype[i].attrType == AttrType.attrInteger)
                    {
                        System.out.print(t.getIntFld(i+1));
                    }
                    if(attrtype[i].attrType == AttrType.attrString)
                    {
                        System.out.print(t.getStrFld(i+1));
                    }
                } 
                catch (Exception e) 
                {
                    e.printStackTrace();
                }
                System.out.print("\t");
            }
            System.out.println();
            System.out.println("LALALA");
            try {
                t = fscan.get_next();
            }
            catch (Exception e) {
                e.printStackTrace(); 
            }
        }
    }

    // public void create_schema_heapfile()
    // {

    // }
    // public void insert_into_heapfile()
    // {

    // }
    public void delete_from_heapfile()
    {
        //open a inputfile
        // read each tuple in the file
        // for each file, search in the the heapfile assocaited and delete that tuple
    }

    public static void insert_into_schema_heapfile(String attr_names_concatenated, String attr_type_concatenated, String table_name)
    {
        // String[] attr_names = attr_names_concatenated.split("+");
        // String[] attr_types = attr_type_concatenated.split("+");
        // int num_columns = attr_names.length;
        AttrType[] attr = new AttrType[3];
        attr[0] = new AttrType(AttrType.attrString);
        attr[1] = new AttrType(AttrType.attrString);
        attr[2] = new AttrType(AttrType.attrString);
        short str_sizes[] = new short[3];
        for(int i=0;i<3;i++)
        {
            str_sizes[i] = (short)100;
        }

        Tuple tup_temp = new Tuple();
        try {
            tup_temp.setHdr((short) 3, attr, str_sizes);
        } catch (Exception e) {
            System.out.println(e);
        }
        int size = tup_temp.size();
        tup_temp = new Tuple(size);
        try {
            tup_temp.setHdr((short) 3, attr, str_sizes);
        } catch (Exception e) {
            System.out.println(e);
        }

        try{
        tup_temp.setStrFld(1, table_name);
        tup_temp.setStrFld(2, attr_names_concatenated);
        tup_temp.setStrFld(3, attr_type_concatenated);
        }
        catch (Exception e) {
            System.out.println(e);
        }
        Heapfile table_hf = null;
        RID rid = null;
        try{
            table_hf = new Heapfile("metadata_heapfile");
        }
        catch (Exception e) {
            System.out.println(e);
        }
        try{
            rid = table_hf.insertRecord(tup_temp.returnTupleByteArray());
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
    public static void main(String[] args) throws IOException, InvalidSlotNumberException, InvalidTupleSizeException, HFDiskMgrException, HFBufMgrException
    {
        // String dbpath = "/Users/nithyavardhanveerati/Desktop/CSE 510 - DBMSI/Project/Phase III/dbs/"+"integrate_test"+System.getProperty("user.name")+".minibase-db";
        // try {
        //     SystemDefs sysdef = new SystemDefs( dbpath, NUMBUF+20, NUMBUF, "Clock" );
        //   }
        // catch(Exception e)
        // {
        //     e.printStackTrace();
        // }
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter query: ");
        String query;
        query = scan.nextLine();
        SystemDefs sysdef;
        while(!query.equals("exit"))
        {
            System.out.println(query);
            String[] query_terms = query.split(" ", -2);
            int num_terms = query_terms.length;
            
            if(query_terms[0].equals("open_database"))
            {
                String database_name = query_terms[1];
                String dbpath = "/Users/riya/Documents/DBMSI/Project/Phase 1/minjava/javaminibase/src/dbs/"+database_name+System.getProperty("user.name")+".minibase-db";
                try{
                    // SystemDefs sysdef = new SystemDefs( dbpath, NUMBUF+20, NUMBUF, "Clock" );
                    File nf = new File(dbpath);
                    if (nf.exists()){
                        System.out.println("exists");
                        sysdef = new SystemDefs( dbpath, 0,  100, "Clock" );
                    } else {
                        System.out.println("doesnt exist");
                        sysdef = new SystemDefs( dbpath, 8193,  100, "Clock" );
                    }
                    SystemDefs.JavabaseDB.openDB(database_name);
                }
                catch(Exception e)
                {
                    e.printStackTrace();
                }
                
                System.out.println("\t"+database_name);
                System.out.println("\t"+query_terms[0]);
                System.out.println();
            }
            else if(query_terms[0].equals("close_database"))
            {
                try 
                {
                    SystemDefs.JavabaseBM.flushAllPages();
                } 
                catch (Exception e)
                {
                    System.out.println("Issue with flushing all pages in Buffer");
                }
                try{
                SystemDefs.JavabaseDB.closeDB();
                }
                catch (Exception e)
                {
                    System.out.println("DB cannot be closed");
                }
                // SystemDefs.JavabaseDB.closeDB();
                System.out.println("\t"+query_terms[0]);
                System.out.println();
            }
            else if(query_terms[0].equals("create_table"))
            {
                String filename;
                if(query_terms[1].equals("CLUSTERED"))
                {
                    filename = query_terms[4];
                    int att_no = Integer.valueOf(query_terms[3]);
                    //open file and parse file logic
                    if(query_terms[2].equals("BTREE"))
                    {
                        System.out.println("\t"+filename);
                        System.out.println("\t"+query_terms[2]);
                        System.out.println("\t"+att_no);
                        System.out.println("\t"+query_terms[0]);
                        System.out.println();
                    }
                    else if(query_terms[2].equals("HASH"))
                    {
                        System.out.println("\t"+filename);
                        System.out.println("\t"+query_terms[2]);
                        System.out.println("\t"+att_no);
                        System.out.println("\t"+query_terms[0]);
                        System.out.println();
                    }
                }
                else
                {
                    filename = query_terms[1];

                    String table_name = "details";
                    // create_data_heapfile("../src/input_files/new_nvr_data.txt", table_name);
                    create_data_heapfile(filename, table_name);
                    //TODO: Remove hard code from here
                    AttrType temp[] = new AttrType[3];
                    temp[0] = new AttrType(AttrType.attrString);
                    temp[1] = new AttrType(AttrType.attrInteger);
                    temp[2] = new AttrType(AttrType.attrInteger);
                    short str_sizes[] = new short[3];
                    for(int i=0;i<3;i++)
                    {
                        str_sizes[i] = (short)100;
                    }
                    Heapfile hf =null;
                    try{
                        hf = new Heapfile("details");
                        System.out.print(hf.getRecCnt());
                    }catch(Exception e){
                        e.printStackTrace();
                    }
                    //print_from_heapfile(table_name,3,temp,str_sizes);


                    System.out.println("\t"+filename);
                    System.out.println("\t"+query_terms[0]);
                    System.out.println();
                }
            }
            else if(query_terms[0].equals("create_index"))
            {
                String table_name = query_terms[3];
                int att_no = Integer.valueOf(query_terms[2]);
                if(query_terms[1].equals("BTREE"))
                {
                    System.out.println("\t"+table_name);
                    System.out.println("\t"+query_terms[1]);
                    System.out.println("\t"+att_no);
                    System.out.println("\t"+query_terms[0]);
                    System.out.println();
                }
                else if(query_terms[1].equals("HASH"))
                {
                    System.out.println("\t"+table_name);
                    System.out.println("\t"+query_terms[1]);
                    System.out.println("\t"+att_no);
                    System.out.println("\t"+query_terms[0]);
                    System.out.println();
                }
            }
            else if(query_terms[0].equals("insert_data"))
            {
                String table_name = query_terms[1];
                String file_name = query_terms[2];

                System.out.println("\t"+table_name);
                System.out.println("\t"+file_name);
                System.out.println("\t"+query_terms[0]);
                System.out.println();

            }
            else if(query_terms[0].equals("delete_data"))
            {
                String table_name = query_terms[1];
                String file_name = query_terms[2];

                System.out.println("\t"+table_name);
                System.out.println("\t"+file_name);
                System.out.println("\t"+query_terms[0]);
                System.out.println();

            }
            else if(query_terms[0].equals("output_table"))
            {
                String table_name = query_terms[1];

                System.out.println("\t"+table_name);
                System.out.println("\t"+query_terms[0]);
                System.out.println();

            }
            else if(query_terms[0].equals("output_index"))
            {
                String table_name = query_terms[1];
                int att_no = Integer.valueOf(query_terms[2]);

                System.out.println("\t"+table_name);
                System.out.println("\t"+att_no);
                System.out.println("\t"+query_terms[0]);
                System.out.println();
            }
            else if(query_terms[0].equals("skyline"))
            {
                String skyline_type = query_terms[1];
                String table_name;
                int num_pages;
                int att_num[];
                String out_table_name;
                if(query_terms[num_terms-2].equals("MATER"))
                {
                    out_table_name = query_terms[num_terms-1];
                    num_pages = Integer.valueOf(query_terms[num_terms-3]);
                    table_name = query_terms[num_terms-4];
                    att_num = new int[num_terms-6];
                    for(int k=0;k<num_terms-6;k++)
                    {
                        att_num[k] = Integer.valueOf(query_terms[2+k]);
                    }

                    System.out.println("\t"+skyline_type);
                    System.out.println("\t"+table_name);
                    System.out.println("\t"+num_pages);
                    System.out.println("\t"+out_table_name);
                    System.out.println("\t"+num_terms);
                    for(int k=0;k<num_terms-6;k++)
                    {
                        System.out.println("\t\t"+att_num[k]);
                    }
                    System.out.println();
                }
                else
                {
                    out_table_name = "";
                    num_pages = Integer.valueOf(query_terms[num_terms-1]);
                    table_name = query_terms[num_terms-2];
                    att_num = new int[num_terms-4];
                    for(int k=0;k<num_terms-4;k++)
                    {
                        att_num[k] = Integer.valueOf(query_terms[2+k]);
                    }

                    System.out.println("\t"+skyline_type);
                    System.out.println("\t"+table_name);
                    System.out.println("\t"+num_pages);
                    System.out.println("\t"+num_terms);
                    System.out.println("\t"+att_num.length);
                    for(int k=0;k<num_terms-4;k++)
                    {
                        System.out.println("\t\t"+att_num[k]);
                    }
                    System.out.println();
                }
                
            }
            else if(query_terms[0].equals("GROUPBY"))
            {
                String grpby_type = query_terms[1];
                String grpby_cond = query_terms[2];
                int g_att_no = Integer.valueOf(query_terms[3]);
                String table_name;
                int num_pages;
                int att_num[];
                String out_table_name;
                if(query_terms[num_terms-2].equals("MATER"))
                {
                    out_table_name = query_terms[num_terms-1];
                    num_pages = Integer.valueOf(query_terms[num_terms-3]);
                    table_name = query_terms[num_terms-4];
                    att_num = new int[num_terms-8];
                    for(int k=0;k<num_terms-8;k++)
                    {
                        att_num[k] = Integer.valueOf(query_terms[4+k]);
                    }

                    System.out.println("\t"+grpby_type);
                    System.out.println("\t"+grpby_cond);
                    System.out.println("\t"+g_att_no);
                    System.out.println("\t"+table_name);
                    System.out.println("\t"+num_pages);
                    System.out.println("\t"+out_table_name);
                    System.out.println("\t"+num_terms);
                    System.out.println("\t"+att_num.length);
                    for(int k=0;k<num_terms-8;k++)
                    {
                        System.out.println("\t\t"+att_num[k]);
                    }
                    System.out.println();

                }
                else
                {
                    out_table_name = "";
                    num_pages = Integer.valueOf(query_terms[num_terms-1]);
                    table_name = query_terms[num_terms-2];
                    att_num = new int[num_terms-6];
                    for(int k=0;k<num_pages-6;k++)
                    {
                        att_num[k] = Integer.valueOf(query_terms[4+k]);
                    }

                    System.out.println("\t"+grpby_type);
                    System.out.println("\t"+grpby_cond);
                    System.out.println("\t"+g_att_no);
                    System.out.println("\t"+table_name);
                    System.out.println("\t"+num_pages);
                    System.out.println("\t"+num_terms);
                    System.out.println("\t"+att_num.length);
                    for(int k=0;k<num_terms-6;k++)
                    {
                        System.out.println("\t\t"+att_num[k]);
                    }
                    System.out.println();
                }
            }
            else if(query_terms[0].equals("JOIN"))
            {
                String join_type = query_terms[1];
                String outer_table_name = query_terms[2];
                int outer_att_num = Integer.valueOf(query_terms[3]);
                String inner_table_name = query_terms[4];
                int inner_att_num = Integer.valueOf(query_terms[5]);
                String operator = query_terms[6];
                int num_pages = Integer.valueOf(query_terms[7]);
                String output_table_name = "";
                if(query_terms[num_terms-2].equals("MATER"))
                {
                    output_table_name = query_terms[num_terms-1];
                }

                System.out.println("\t"+join_type);
                System.out.println("\t"+outer_table_name);
                System.out.println("\t"+outer_att_num);
                System.out.println("\t"+inner_att_num);
                System.out.println("\t"+inner_table_name);
                System.out.println("\t"+num_terms);
                System.out.println("\t"+operator);
                System.out.println("\t"+num_pages);
                System.out.println("\t"+output_table_name);
            }
            else if(query_terms[0].equals("TOPKJOIN"))
            {
                String join_type = query_terms[1];
                int k = Integer.valueOf(query_terms[2]);
                String outer_table_name = query_terms[3];
                int outer_j_att_no = Integer.valueOf(query_terms[4]);
                int outer_m_att_no = Integer.valueOf(query_terms[5]);
                String inner_table_name = query_terms[6];
                int inner_j_att_no = Integer.valueOf(query_terms[7]);
                int inner_m_att_no = Integer.valueOf(query_terms[8]);
                int num_pages = Integer.valueOf(query_terms[9]);
                String output_table_name="";
                if(query_terms[num_terms-2].equals("MATER"))
                {
                    output_table_name = query_terms[num_terms-1];
                }

                System.out.println("\t"+join_type);
                System.out.println("\t"+outer_table_name);
                System.out.println("\t"+outer_j_att_no);
                System.out.println("\t"+outer_m_att_no);
                System.out.println("\t"+k);
                System.out.println("\t"+inner_table_name);
                System.out.println("\t"+inner_j_att_no);
                System.out.println("\t"+inner_m_att_no);
                System.out.println("\t"+num_terms);
                System.out.println("\t"+num_pages);
                System.out.println("\t"+output_table_name);
            }
            query = scan.nextLine();
        }
        // String table_name = "details";
        // create_data_heapfile("../src/input_files/new_nvr_data.txt", table_name);
        // //TODO: Remove hard code from here
        // AttrType temp[] = new AttrType[3];
        // temp[0] = new AttrType(AttrType.attrString);
        // temp[1] = new AttrType(AttrType.attrInteger);
        // temp[2] = new AttrType(AttrType.attrInteger);
        // short str_sizes[] = new short[3];
        // for(int i=0;i<3;i++)
        // {
        //     str_sizes[i] = (short)100;
        // }
        // print_from_heapfile(table_name,3,temp,str_sizes);
    }
}