package testsphase3;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import diskmgr.pcounter;
import global.AggType;
import global.AttrType;
import global.Catalogglobal;
import global.GlobalConst;
import global.RID;
import global.SystemDefs;
import heap.Heapfile;
import heap.Scan;
import heap.Tuple;
import iterator.FldSpec;
import iterator.GroupBywithSort;
import iterator.Iterator;
import iterator.JoinsException;
import iterator.RelSpec;
import iterator.SortException;

public class GroupBywithSortTest implements GlobalConst, Catalogglobal {

    static void create_heapfile(String input_filepath, AttrType[] attr, int num_cols, short[] str_sizes,
        String output_heapfile)
        {
        String nameRoot = "phase3task3b";
        String dbpath = "/tmp/" + nameRoot + System.getProperty("user.name") + ".minibase-db";
        //System.out.println(dbpath);
        SystemDefs sysdef = new SystemDefs(dbpath, 10000, NUMBUF, "Clock");

        // before_creating_heapfile();
        File file = new File(input_filepath);
        ArrayList<Tuple> outerAL = new ArrayList();

        Tuple tup_temp = new Tuple();
        try {
            tup_temp.setHdr((short) num_cols, attr, str_sizes);
        } catch (Exception e) {
            System.out.println(e);
        }
        int size = tup_temp.size();
        tup_temp = new Tuple(size);
        try {
            tup_temp.setHdr((short) num_cols, attr, str_sizes);
        } catch (Exception e) {
            System.out.println(e);
        }

        try {
            Scanner sc = new Scanner(file);
            String gb = sc.nextLine();
            while (sc.hasNextLine()) {
              //  count++;
                String line = sc.nextLine();
                String[] tokens = line.split(",");
                int k =0;
                for (int i = 0; i < tokens.length; i++) {
                    if(tokens[i].equals("")){
                        continue;
                    }
                    if (attr[k].attrType == AttrType.attrInteger) {
                        tup_temp.setIntFld(i + 1, Integer.parseInt(tokens[i]));
                    }
                    if (attr[k].attrType == AttrType.attrReal) {
                        tup_temp.setFloFld(k+ 1, Float.parseFloat(tokens[i]));
                    }
                    if (attr[k].attrType == AttrType.attrString) {
                        tup_temp.setStrFld(i + 1, tokens[i]);
                    }
                    if (attr[k].attrType == AttrType.attrSymbol) {
                        tup_temp.setStrFld(i + 1, tokens[i]);
                    }
                    if (attr[k].attrType == AttrType.attrNull) {
                        tup_temp.setStrFld(i + 1, tokens[i]);
                    }
                    k++;
                }
                outerAL.add(tup_temp);
                tup_temp = new Tuple(size);
                try {
                    tup_temp.setHdr((short) num_cols, attr, str_sizes);
                } catch (Exception e) {
                    System.out.println(e);
                }
            }
            sc.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        Heapfile hf = null;
        RID rid;
        try {
            hf = new Heapfile(output_heapfile);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Tuple tf;
        for (Tuple t : outerAL) {
            try {
                rid = hf.insertRecord(new Tuple(t).returnTupleByteArray());
                //t.print(attr);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        
    }   
    public static void main(String[] args) throws JoinsException, SortException, IOException {
        String nameRoot = "task3a";
        String dbpath = "/tmp/" + nameRoot + System.getProperty("user.name") + ".minibase-db";
        SystemDefs sysdef = new SystemDefs(dbpath, 10000, 10000, "Clock");

        // String[] data_1 = new String[10];
        // float[] data_2 = new float[10];
        // float[] data_3 = new float[10];

        // for (int i = 0; i < 10; i++) {
        //     if (i < 2) {
        //         data_1[i] = "apple";
        //     } else if (i < 4) {
        //         data_1[i] = "bombay";
        //     } else if (i < 6) {
        //         data_1[i] = "pizza";
        //     } else if (i < 8) {
        //         data_1[i] = "rome";
        //     } else {
        //         data_1[i] = "zebra";
        //     }
        //     data_2[i] = (float) (i);
        //     data_3[i] = (float) (-2 * i + 10);
        // }

        // String[] data_1 = {"9aaaaaaaa", "1aaaaaaaa", "10aaaaaaaa", "8aaaaaaaa", "7aaaaaaaa", "8aaaaaaaa", "2aaaaaaaa", "9aaaaaaaa", "6aaaaaaaa", "7aaaaaaaa", "9aaaaaaaa", "3aaaaaaaa", "6aaaaaaaa", "8aaaaaaaa", "9aaaaaaaa"};
        // int[] data_2 = {3, 7, 5, 10, 7, 8, 2, 5, 1, 1, 8, 6, 8, 1, 2};
        // int[] data_3 = {8, 2, 6, 7, 1, 9, 10, 4, 8, 8, 4, 9, 5, 6, 3};

        AttrType[] attrType = new AttrType[3];
        attrType[0] = new AttrType(AttrType.attrString);
        attrType[1] = new AttrType(AttrType.attrInteger);
        attrType[2] = new AttrType(AttrType.attrInteger);

        short[] str_sizes = new short[1];
        str_sizes[0] = (short) MAXNAME;

        // create a tuple of appropriate size
        Tuple t = new Tuple();
        try {
            t.setHdr((short) attrType.length, attrType, str_sizes);
        } catch (Exception e) {
            e.printStackTrace();
        }
        int size = t.size();

        // Create unsorted data file "unsortedfile"
        // RID rid;
        // Heapfile f = null;
        // try {
        //     f = new Heapfile("unsortedfile");
        // } catch (Exception e) {
        //     e.printStackTrace();
        // }

        t = new Tuple(size);
        try {
            t.setHdr((short) attrType.length, attrType, str_sizes);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // for (int i = 0; i < data_1.length; i++) {
        //     try {
        //         t.setStrFld(1, data_1[i]);
        //         t.setIntFld(2, data_2[i]);
        //         t.setIntFld(3, data_3[i]);
        //     } catch (Exception e) {
        //         e.printStackTrace();
        //     }

        //     try {
        //         rid = f.insertRecord(t.returnTupleByteArray());
        //     } catch (Exception e) {
        //         e.printStackTrace();
        //     }
        // }

        // create an scan on the heapfile conataining the data
        // Scan scan = null;

        // try {
        //     scan = new Scan(f);
        // } catch (Exception e) {
        //     e.printStackTrace();
        //     Runtime.getRuntime().exit(1);
        // }

        GroupBywithSort gbws = null;
        short[] t1_str_sizes = new short[1];
        t1_str_sizes[0] = (short) MAXNAME;
        Iterator am1 = null;

        AggType aggType = new AggType(AggType.avg);

        FldSpec[] projlist;
        RelSpec rel = new RelSpec(RelSpec.outer);

        if (aggType.aggType == AggType.max) {
            projlist = new FldSpec[2];
            for (int i = 0; i < 2; i++) {
                projlist[i] = new FldSpec(rel, i + 1);
            }
        } else {
            projlist = new FldSpec[attrType.length];
            for (int i = 0; i < attrType.length; i++) {
                projlist[i] = new FldSpec(rel, i + 1);
            }
        }

        FldSpec[] agglist = new FldSpec[2];
        RelSpec rel1 = new RelSpec(RelSpec.outer);
        agglist[0] = new FldSpec(rel1, 2);
        agglist[1] = new FldSpec(rel1, 3);

        String filename = "/Users/riya/Documents/DBMSI/Project/Phase 1/minjava/javaminibase/src/input_files/Phase3_report_dataset/r_sii2000_10_75_200.txt";
        String datafilename = "unsortedfile";
        create_heapfile(filename, attrType, attrType.length, str_sizes, datafilename);

        //for the reads and writes
        pcounter.rcounter = 0;
        pcounter.wcounter = 0;


        try {
            gbws = new GroupBywithSort(attrType, attrType.length, t1_str_sizes, "unsortedfile", am1, projlist[0],
                    aggType, agglist, projlist, 2, 20);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // if the agg type is average
        AttrType[] avgatt = new AttrType[2];
        for (int i = 0; i < 1; i++) {
            avgatt[i] = attrType[projlist[0].offset - 1];
        }
        avgatt[1] = new AttrType(AttrType.attrReal);

        // if the aggtype is average
        Tuple avg = new Tuple();
        try {
            avg.setHdr((short) (2), avgatt, str_sizes);
        } catch (Exception e) {
            e.printStackTrace();
        }
        avg = new Tuple(avg.size());
        try {
            avg.setHdr((short) (2), avgatt, str_sizes);
        } catch (Exception e) {
            e.printStackTrace();
        }

        if(aggType.aggType == AggType.avg){
            try {
                avg = gbws.get_next();
            } catch (Exception e) {
                e.printStackTrace();
            }
    
            while (avg != null) {
                try {
                    avg.print(avgatt);
                } catch (IOException e) {
                    e.printStackTrace();
                }
    
                try {
                    avg = gbws.get_next();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        else{
            try {
                t = gbws.get_next();
            } catch (Exception e) {
                e.printStackTrace();
            }
    
            while (t != null) {
                try {
                    t.print(attrType);
                } catch (IOException e) {
                    e.printStackTrace();
                }
    
                try {
                    t = gbws.get_next();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

        gbws.close();

        System.out.printf("Number of reads: %d \n", pcounter.rcounter);
        System.out.printf("Number of writes: %d \n", pcounter.wcounter);
    }
}
