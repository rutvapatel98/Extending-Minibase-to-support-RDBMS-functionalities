package skyline;

import java.io.*;
import global.*;
import bufmgr.*;
import diskmgr.*;
import heap.*;
import iterator.*;
import index.*;
import java.util.Random;
import btree.*;

public class BTreeSkyTest implements GlobalConst {
    public static void main(String[] args) {

        String nameRoot = "task4_new_version";
        String dbpath = "/tmp/"+nameRoot+System.getProperty("user.name")+".minibase-db";
        SystemDefs sysdef = new SystemDefs(dbpath,100000,1000,"Clock");

        int[] data_1 =  {23, 67, 34, 10, 21, 56, 90, 11, 45, 20};
        int[] data_2 =  {70, 85, 12, 31, 65, 27, 29, 67, 39, 75};
        
        AttrType[] attrType = new AttrType[2];
        attrType[0] = new AttrType(AttrType.attrInteger);
        attrType[1] = new AttrType(AttrType.attrInteger);

        int[] pref_list = {1,2};

        // create a tuple of appropriate size
        Tuple t = new Tuple();
        try {
            t.setHdr((short) 2, attrType, null);
        }
        catch (Exception e) {
            e.printStackTrace();
        }

        
        int size = t.size();

        // Create unsorted data file "unsortedfile"
        RID             rid;
        Heapfile        f = null;
        try {
            f = new Heapfile("unsortedfile");
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        
        t = new Tuple(size);
        try {
            t.setHdr((short) 2, attrType, null);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        
        for (int i=0; i<data_1.length; i++) {
            try {
                t.setIntFld(1, data_1[i]);
                t.setIntFld(2, data_2[i]);
            }
            catch (Exception e) {
                e.printStackTrace();
            }
            
            try {
                rid = f.insertRecord(t.getTupleByteArray());
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }

        try{
            System.out.println(f.getRecCnt());
        }
        catch (Exception e){
            e.printStackTrace();
        }

        // create an scan on the heapfile conataining the data
        Scan scan = null;
        
        try {
            scan = new Scan(f);
        }
        catch (Exception e) {
            e.printStackTrace();
            Runtime.getRuntime().exit(1);
        }

        // create the index file on the sum of pref attributes
        BTreeFile[] btf = new BTreeFile[pref_list.length];
        
       // btf = null;
    for(int i=0; i<pref_list.length;i++)
    {   
        try {
            scan = new Scan(f);
        }
        catch (Exception e) {
            e.printStackTrace();
            Runtime.getRuntime().exit(1);
        }
        rid = new RID();
        int key = 0;
        Tuple temp = null;
        
        try {
            temp = scan.getNext(rid);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
                btf[i] = null;

        try {
            btf[i] = new BTreeFile("BTIndex"+i, AttrType.attrInteger, 4, 1/*delete*/); 
        }
        catch (Exception e) {
            e.printStackTrace();
            Runtime.getRuntime().exit(1);
        }

        System.out.println("BTreeIndex" +i+ "created successfully.\n"); 
            
      

        while ( temp != null) {
            t.tupleCopy(temp);
            
            try {
                //find sum of pref attributes for each tuple to compute the key

              //  int i=0;
                float sum=0;
                
                    if(attrType[pref_list[i]-1].attrType == AttrType.attrInteger)
                    {
                        try
                        {
                            sum = t.getIntFld(pref_list[i]);
        
                        }
                        catch(Exception e)
                        {
                            System.out.println(e);
                        }
                        
                    }
                    else if(attrType[pref_list[i]-1].attrType == AttrType.attrReal)
                    {
                        try
                        {
                            sum = t.getIntFld(pref_list[i]);
        
                        }
        
                        catch(Exception e)
                        {
                            System.out.println(e);
                        }
                        
                    }
                    else
                    {
                        System.out.println("Not an integer or float so cannot add");
                    }
                

                key = (int)sum;
            }
            catch (Exception e) {
                e.printStackTrace();
            }
            
            try {
                btf[i].insert(new IntegerKey(key), rid); 
            }
            catch (Exception e) {
                e.printStackTrace();
            }

            try {
                temp = scan.getNext(rid);
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }
    
        // close the file scan
        scan.closescan();
        
        System.out.println("BTreeIndex "+i+ "file created successfully.\n"); 
    }
        //create the BTree
        // open existing index
        int amt_of_mem = 10;
        Iterator am1 = null;
        java.lang.String relationName  = "unsortedfile";
        int n_pages = 10;
        short[] t1_str_sizes = new short[attrType.length];
        BTreeSky btss = null;
        try {
            // for(int i=0; i<pref_list.length;i++)
            // { 
            btss = new BTreeSky(attrType, attrType.length, t1_str_sizes, am1, relationName, pref_list, pref_list.length, btf, n_pages);
            //}
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
