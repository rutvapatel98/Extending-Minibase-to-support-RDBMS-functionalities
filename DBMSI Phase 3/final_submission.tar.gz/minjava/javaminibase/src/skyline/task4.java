package skyline;

import java.io.*; 
import global.*;
import bufmgr.*;
import diskmgr.*;
import heap.*;
import iterator.*;
import index.*;
import java.util.Random;
import btree.*;;

public class task4 {
    public static void main(String[] argv) {

        String nameRoot = "task4_new_version";
        String dbpath = "/tmp/"+nameRoot+System.getProperty("user.name")+".minibase-db";
        SystemDefs sysdef = new SystemDefs(dbpath,1000,1000,"Clock");

        int[] data_1 = { 23, 67, 34, 10, 21, 56, 90, 11, 45, 20, 80 };
        int[] data_2 = {70, 85, 12, 31, 65, 27, 29, 67, 39, 75};
        
        AttrType[] attrType = new AttrType[2];
        attrType[0] = new AttrType(AttrType.attrReal);
        attrType[1] = new AttrType(AttrType.attrReal);

        int[] pref_list = {1,2};

        // create a tuple of appropriate size
        Tuple t = new Tuple();
        try {
            t.setHdr((short) 2, attrType, null);
        }
        catch (Exception e) {
            e.printStackTrace();
        }

        
        int size = t.size();

        // Create unsorted data file "unsortedfile"
        RID             rid;
        Heapfile        f = null;
        try {
            f = new Heapfile("unsortedfile");
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        
        t = new Tuple(size);
        try {
            t.setHdr((short) 2, attrType, null);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        
        for (int i=0; i<data_1.length; i++) {
            try {
                    t.setFloFld(1, data_1[i]);
                    t.setFloFld(2, data_2[i]);
            }
            catch (Exception e) {
                e.printStackTrace();
            }
            
            try {
                rid = f.insertRecord(t.getTupleByteArray());
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }

        try{
            System.out.println(f.getRecCnt());
        }
        catch (Exception e){
            e.printStackTrace();
        }

        // create an scan on the heapfile conataining the data
        Scan scan = null;
        
        try {
            scan = new Scan(f);
        }
        catch (Exception e) {
            e.printStackTrace();
            Runtime.getRuntime().exit(1);
        }

        // create the index file on the sum of pref attributes
        BTreeFile[] btf = new BTreeFile[pref_list.length];
        
       // btf = null;
    for(int i=0; i<pref_list.length;i++)
    {   
        try {
            scan = new Scan(f);
        }
        catch (Exception e) {
            e.printStackTrace();
            Runtime.getRuntime().exit(1);
        }
        rid = new RID();
        int key = 0;
        Tuple temp = null;
        
        try {
            temp = scan.getNext(rid);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
                btf[i] = null;

        try {
            btf[i] = new BTreeFile("BTIndex"+i, AttrType.attrInteger, 4, 1/*delete*/); 
        }
        catch (Exception e) {
            e.printStackTrace();
            Runtime.getRuntime().exit(1);
        }

        System.out.println("BTreeIndex" +i+ "created successfully.\n"); 
            
      

        while ( temp != null) {
            t.tupleCopy(temp);
            
            try {
                //find sum of pref attributes for each tuple to compute the key

              //  int i=0;
                float sum=0;
                
                    if(attrType[pref_list[i]-1].attrType == AttrType.attrInteger)
                    {
                        try
                        {
                            sum = t.getIntFld(pref_list[i]);
        
                        }
                        catch(Exception e)
                        {
                            System.out.println(e);
                        }
                        
                    }
                    else if(attrType[pref_list[i]-1].attrType == AttrType.attrReal)
                    {
                        try
                        {
                            sum = t.getIntFld(pref_list[i]);
        
                        }
        
                        catch(Exception e)
                        {
                            System.out.println(e);
                        }
                        
                    }
                    else
                    {
                        System.out.println("Not an integer or float so cannot add");
                    }
                

                key = (int)sum;
            }
            catch (Exception e) {
                e.printStackTrace();
            }
            
            try {
                btf[i].insert(new IntegerKey(key), rid); 
            }
            catch (Exception e) {
                e.printStackTrace();
            }

            try {
                temp = scan.getNext(rid);
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }
    
        // close the file scan
        scan.closescan();
        
        System.out.println("BTreeIndex "+i+ "file created successfully.\n"); 
    }
        //create the BTree
        // open existing index
        int amt_of_mem = 10;
        Iterator am1 = null;
        java.lang.String relationName  = "trial";
        int n_pages = 10;
        for(int i=0; i<pref_list.length;i++)
            { 
        BTreeSortedSky(attrType, attrType.length, 0, amt_of_mem, am1, relationName, pref_list, pref_list.length, "BTIndex"+i, n_pages, btf[i]);
            }


            //store

            //to use printPage, you need arguments pageID and keyType -> issue is padeID

            //take the first element from the first btree 

            Tuple temp_tuple = new Tuple();
            
            try {
                temp_tuple.setHdr((short) 2, attrType, null);
            } catch (Exception e) {
                e.printStackTrace();
            }

            Tuple iter_tuple = new Tuple();
            
            try {
                iter_tuple.setHdr((short) 2, attrType, null);
            } catch (Exception e) {
                e.printStackTrace();
            }
            // Create unsorted data file "unsortedfile"
            RID ridx;
            Heapfile skyline_candidate = null;
            try {
                skyline_candidate = new Heapfile("skyline_candidate");
            } catch (Exception e) {
                e.printStackTrace();
            }

            

            short[] attrSize = new short[2];
            short REC_LEN1 = 32; 
            short REC_LEN2 = 160; 
            attrSize[0] = REC_LEN2;
            attrSize[1] = REC_LEN1;

           // AttrType  comparison_type = new AttrType(AttrType.attrInteger);
		   //comparison_type.attrType = AttrType.attrInteger;

            
            FldSpec[] projlist = new FldSpec[2];
            RelSpec rel = new RelSpec(RelSpec.outer); 
            projlist[0] = new FldSpec(rel, 1);
            projlist[1] = new FldSpec(rel, 2); 
            for(int i=0; i<pref_list.length; i++)
            {
                if(i==0)
                {
                    //store tuple as temp_tuple to compare with other tuples
                            // start index scan
                            IndexScan iscan = null;
                            try {
                                iscan = new IndexScan(new IndexType(IndexType.B_Index), "unsortedfile", "BTIndex"+i, attrType, attrSize, 2, 2, projlist, null, 2, false);
                                temp_tuple = iscan.get_next();    
                            }
                            catch (Exception e) {
                                e.printStackTrace();
                                }
                }
                else{
                    IndexScan iscan = null;
                            try {
                                iscan = new IndexScan(new IndexType(IndexType.B_Index), "unsortedfile", "BTIndex"+i, attrType, attrSize, 2, 2, projlist, null, 2, false);
                                iter_tuple = iscan.get_next();    

                            }
                            catch (Exception e) {
                                e.printStackTrace();
                                }
                    //else compare this to the temp_tuple and add elements in the heap that will be sent to block nested loop
                    //while get next is not null (we dont reach till the end of the btree) we keep comparing til we find temp_tuple    
                    boolean heap_empty = true;
                    while(iter_tuple!=null)
                    {
                        //compare iter_tuple and temp_tuple
                        try {
                            //TODO: change attrType
                            int comp_res = TupleUtils.CompareTupleWithTuple(attrType[i], iter_tuple, i+1, temp_tuple, i+1);
                            
                           // boolean comp_res = TupleUtils.Equal(iter_tuple, temp_tuple, attrType[0], 2);

                            if(comp_res==0)
                            {
                                //iter_tuple and temp_tuple are the same
                                //Hence, we break the loop and check in the next pref attribute BTree
                                break;
                            }
                            else if(comp_res > 0)
                            {

                                //insert the iter_tuple in Heap skyline_candidate after checking if it is not there already
                                
                                // create an scan on the heapfile conataining the data
                            
                                FileScan scan_skc_hf = null;
                                projlist = new FldSpec[2];
                                rel = new RelSpec(RelSpec.outer); 
                                projlist[0] = new FldSpec(rel, 1);
                                projlist[1] = new FldSpec(rel, 2);
                                
                                try {
                                    scan_skc_hf = new FileScan("skyline_candidate", attrType, null, (short) 2, 2, projlist, null);
                                }
                                catch (Exception e) {
                                e.printStackTrace();
                                }
                                rid = new RID();
                                // int key = 0;
                                Tuple temptuple = new Tuple();
                                try {
                                    temptuple.setHdr((short) 2, attrType, null);
                                } catch (Exception e) {

                                    e.printStackTrace();
                                }

                                
                                if(heap_empty)
                                {   
                                    t = new Tuple(size);
                                    try {
                                    t.setHdr((short) 2, attrType, null);
                                    }
                                    catch (Exception e) {
                                    
                                    e.printStackTrace();
                                    }
                                    t.tupleCopy(temp_tuple);
                                    try {
                                        rid = skyline_candidate.insertRecord(t.returnTupleByteArray());
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                    heap_empty = false;
                                    continue;
                                }
                                try {
                                    temptuple = scan_skc_hf.get_next();
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }

                                boolean iter_tuple_found = false;

                                //while we reach the end of the heapfile 
                                while(temptuple!=null)
                                {
                                    //int comp_tuple = TupleUtils.CompareTupleWithTuple(attrType[0], iter_tuple, 2, temptuple, 2);
                                    // System.out.println("iter_tuple:" + iter_tuple.getIntFld(1) + " " +iter_tuple.getIntFld(2));
                                    // System.out.println("temptuple:" + temptuple.getIntFld(1) + " " +temptuple.getIntFld(2));
                                    boolean comp_tuple = TupleUtils.Equal( iter_tuple,temptuple,attrType, 2);
                                    if(comp_tuple== true)
                                    {
                                        iter_tuple_found = true;
                                    }
                                    
                                    try {
                                        temptuple = scan_skc_hf.get_next();
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                }

                                if(!iter_tuple_found)
                                {
                                    try {
                                        t = new Tuple(size);
                                        try {
                                        t.setHdr((short) 2, attrType, null);
                                        }
                                        catch (Exception e) {
                                        
                                        e.printStackTrace();
                                        }
                                        t.tupleCopy(iter_tuple);

                                        rid = skyline_candidate.insertRecord(t.returnTupleByteArray());
                                        System.out.println("Inserting :" + t.getIntFld(1) +"-" +t.getIntFld(2));
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                }


                                //get next to get next tuple
                                iter_tuple = iscan.get_next();    

                            }
                              }catch (Exception e){
                           // throw new PredEvalException (e,"TupleUtilsException is caught by PredEval.java");
                              }

                    }
                }
            }

            FileScan scan_heapFile = null;
            projlist = new FldSpec[2];
            rel = new RelSpec(RelSpec.outer); 
            projlist[0] = new FldSpec(rel, 1);
            projlist[1] = new FldSpec(rel, 2);
            
            try {
                scan_heapFile = new FileScan("skyline_candidate", attrType, null, (short) 2, 2, projlist, null);
            }
            catch (Exception e) {
            e.printStackTrace();
            }

                    
                                try {
                                    System.out.println("rec cnt:" + skyline_candidate.getRecCnt());
                                } catch (InvalidSlotNumberException | InvalidTupleSizeException | HFDiskMgrException
                                        | HFBufMgrException | IOException e1) {
                                    // TODO Auto-generated catch block
                                    e1.printStackTrace();
                                }
                                // int key = 0;
                                Tuple tempetuple2 = new Tuple();
                                
                                try {
                                    tempetuple2.setHdr((short) 2, attrType, null);
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                                try {
                                    tempetuple2 = scan_heapFile.get_next();
                                   System.out.println(tempetuple2.getIntFld(1));
                                   System.out.println(tempetuple2.getIntFld(2));

                                    
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                                SortFirstSky sfs = null;
                                try{
                                    sfs = new SortFirstSky(attrType, attrType.length, null, null, "skyline_candidate" , pref_list, pref_list.length,  2);
                                }catch(Exception e){
                                    e.printStackTrace();
                                }

                                try {
                                    t = sfs.get_next();
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                        
                                while(t != null)
                                {
                                    try {
                                        System.out.println("final answer pls be right" +t.getIntFld(1) + " " + t.getIntFld(2));
                                    } catch (FieldNumberOutOfBoundException | IOException e) {
                                        e.printStackTrace();
                                    }
                        
                                    try {
                                        t = sfs.get_next();
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                }

    }

    public static void BTreeSortedSky(AttrType[] in1, int len_in1, int i, int amt_of_mem, Iterator am1, java.lang.String relationName, int[] pref_list, int length, String string, int n_pages, BTreeFile btf){

        try {
            btf = new BTreeFile(string);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        
        System.out.println(string+ " opened successfully.\n"); 
        
        RID rid = new RID();
        int key1;
        Tuple temp1 = null;

        FldSpec[] projlist = new FldSpec[2];
        RelSpec rel = new RelSpec(RelSpec.outer); 
        projlist[0] = new FldSpec(rel, 1);
        projlist[1] = new FldSpec(rel, 2); 

        short REC_LEN1 = 32; 
        short REC_LEN2 = 160; 
        short[] attrSize = new short[2];
        attrSize[0] = REC_LEN2;
        attrSize[1] = REC_LEN1;
        
        // start index scan
        IndexScan iscan = null;
        try {
            iscan = new IndexScan(new IndexType(IndexType.B_Index), "unsortedfile", string, in1, attrSize, 2, 2, projlist, null, 2, false);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        

        int count = 0;
        Tuple t = new Tuple();
        t = null;
        String outval = null;
        
        try {
            t = iscan.get_next();
        }
        catch (Exception e) {
            e.printStackTrace(); 
        }

        if (t == null) {
            System.err.println("no record retrieved");
        }
        
        try {
            t = iscan.get_next();
            System.out.println("testtt" +t);
        }
        catch (Exception e) {
            e.printStackTrace(); 
        }
        
        // clean up
        try {
            iscan.close();
        }
        catch (Exception e) {
            e.printStackTrace();
        }

        //print the leaf nodes
        try{
            BT.printAllLeafPages(btf.getHeaderPage());
        }
        catch(Exception e){
            e.printStackTrace();
        }
        
    }
}
