package skyline;
import java.io.*;
import global.*;
import bufmgr.*;
import diskmgr.*;
import heap.*;
import iterator.*;
import index.*;
import java.util.Random;

public class sortFirstSkyTest implements GlobalConst{
    public static void main(String[] args) {
        int[] data_int_1 = new int[50]; // = { 23, 67, 34, 10, 21, 56, 90, 11, 45, 20, 80 };
        int[] data_int_2 = new int[50]; // = { 70, 85, 12, 31, 65, 27, 29, 67, 39, 75, 70 };

        for (int i = 0; i < 50; i++) {
           data_int_1[i] = i + 1;
            data_int_2[i] = -2 * (i + 1) + 10;
        }
        // int NUM_RECORDS = 500;
        // int len_in = 2;

        int[] pref_list = {1,2};
        String nameRoot = "task33";
        String dbpath = "/tmp/" + nameRoot + System.getProperty("user.name") + ".minibase-db";
        SystemDefs sysdef = new SystemDefs( dbpath, 1000, NUMBUF, "Clock" );
        
        AttrType[] attrType = new AttrType[2];
        attrType[0] = new AttrType(AttrType.attrInteger);
        attrType[1] = new AttrType(AttrType.attrInteger);

        RID             rid;
        Heapfile        f = null;
        Heapfile        skyline = null;

        Tuple t = new Tuple();
        try {
            t.setHdr((short) 2, attrType, null);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        t = new Tuple(t.size());
        try {
            t.setHdr((short) 2, attrType, null);
        }
        catch (Exception e) {
            e.printStackTrace();
        }

        //input file to find the skyline
        try {
            f = new Heapfile("test2.in");
        }
        catch (Exception e) {
        
            e.printStackTrace();
        }
        
        for (int i=0; i<data_int_1.length; i++) {
            try {
                t.setIntFld(1, data_int_1[i]);
                t.setIntFld(2, data_int_2[i]);
            }
            catch (Exception e) {
                e.printStackTrace();
            }
            
            try {
                rid = f.insertRecord(t.returnTupleByteArray());
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }

        SortFirstSky sfs = null;
        try {
            sfs = new SortFirstSky(attrType, attrType.length, null, null, "test2.in", pref_list, pref_list.length,2);
        } catch (Exception e1) {
            e1.printStackTrace();
        }

        try {
            t = sfs.get_next();
        } catch (Exception e) {
            e.printStackTrace();
        }

        while(t != null)
        {
            try {
                System.out.println(t.getIntFld(1) + " " + t.getIntFld(2));
            } catch (FieldNumberOutOfBoundException | IOException e) {
                e.printStackTrace();
            }

            try {
                t = sfs.get_next();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }
}
