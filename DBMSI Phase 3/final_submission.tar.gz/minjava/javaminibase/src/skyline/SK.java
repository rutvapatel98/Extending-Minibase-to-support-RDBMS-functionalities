package skyline;
import heap.*;
import global.*;

import java.io.*;
import bufmgr.*;
import diskmgr.*;

public class SK 
{
    

    public static void main(String args[])
    {
        AttrType[] attrs;
        Tuple tuple1;
        Tuple tuple2;

        tuple1 = new Tuple(Tuple.max_size);
        tuple2 = new Tuple(Tuple.max_size);
        attrs = new AttrType[5];
        
        attrs[0] = new AttrType(AttrType.attrInteger);  
        attrs[1] = new AttrType(AttrType.attrInteger);
        attrs[2] = new AttrType(AttrType.attrReal);
        attrs[3] = new AttrType(AttrType.attrReal);
        attrs[4] = new AttrType(AttrType.attrString);

        int sizeOfInt = 4;
        int sizeOfFloat = 4;
        int max = 10;   // comes from attrData char strVal[10]
        if (sizeOfInt > max)
        max = (short) sizeOfInt;
        if (sizeOfFloat > max)
        max = (short) sizeOfFloat;
        
        short[] str_sizes = new short[1];
        str_sizes[0] = (short) max;
       
      
      try {
	tuple1.setHdr((short)5, attrs, str_sizes);
    tuple2.setHdr((short)5, attrs, str_sizes);
      }
      catch (Exception e) {
        System.out.println("hello");
      }
      try
      {
        // tuple.setIntFld(0, 500);
        tuple1.setIntFld(1, 500);
        tuple1.setIntFld(2, 500);
        float f1 = 35.00F;
        float f2 = 41.00F;
        tuple1.setFloFld(3, f1);
        tuple1.setFloFld(4, f2);
        tuple1.setStrFld(5, "500");
        // tuple.setStrFld(3, "hell");
        tuple2.setIntFld(1, 100);
        tuple2.setIntFld(2, 100);
        float f11 = 36.00F;
        float f21 = 45.00F;
        tuple2.setFloFld(3, f11);
        tuple2.setFloFld(4, f21);
        tuple2.setStrFld(5, "500");

        System.out.println("records inserted");
      }
      catch(Exception e)
      {
        System.out.println(e);
        System.out.println("records not inserted");
      }

      try
      {
        // tuple.setIntFld(0, 500);
        System.out.println(tuple1.getIntFld(1)+"\t"+tuple1.getIntFld(2)+tuple1.getFloFld(3)+"\t"+tuple1.getFloFld(4)+"\t"+tuple1.getStrFld(5));
        System.out.println(tuple2.getIntFld(1)+"\t"+tuple2.getIntFld(2)+tuple2.getFloFld(3)+"\t"+tuple2.getFloFld(4)+"\t"+tuple2.getStrFld(5));
        // System.out.println(tuple.getStrFld(3));
        
        System.out.println("records printed");
      }
      catch(Exception e)
      {
        System.out.println(e);
        System.out.println("records not printed");
      }
      try{
          int[] a = {1,2,3,4};
          int[] a1 = {1,2};
          short b = 0;
        System.out.println(Dominates(tuple1, attrs, tuple2, attrs, b, str_sizes, a, a.length));
        System.out.println(Dominates(tuple1, attrs, tuple2, attrs, b, str_sizes, a1, a1.length));
        System.out.println(CompareTupleWithTuplePref(tuple1, attrs, tuple2, attrs, b, str_sizes, a, a.length));
      }
      catch(Exception e)
      {
        System.out.println(e);
        System.out.println("records not printed");
      }
    }

    public static int Dominates(Tuple t1, AttrType[] type1, Tuple t2, AttrType[] type2, short len_in, short[] str_sizes, int[] pref_list, int pref_list_length) throws FieldNumberOutOfBoundException, IOException
    {
        int i=0;
        int flag=0;
        for(i=0;i<pref_list_length;i++)
        {
            if(type1[pref_list[i]-1].attrType == AttrType.attrInteger)
            {
                try{
                        if(t1.getIntFld(pref_list[i]) > t2.getIntFld(pref_list[i]))
                    {
                        flag = 1;
                    }
                    else if(t1.getIntFld(pref_list[i]) < t2.getIntFld(pref_list[i]))
                    {
                        flag = -1;
                        break;
                    }
                }
                catch(FieldNumberOutOfBoundException e)
                {
                    e.printStackTrace();
                    System.out.println(e);
                }
            }
            else if(type1[pref_list[i]-1].attrType == AttrType.attrReal)
            {
                try
                {
                    if(t1.getFloFld(pref_list[i]) > t2.getFloFld(pref_list[i]))
                    {
                        flag = 1;
                    }
                    else if(t1.getFloFld(pref_list[i]) < t2.getFloFld(pref_list[i]))
                    {
                        flag = -1;
                        break;
                    }
                }
                catch(FieldNumberOutOfBoundException e)
                {
                    System.out.println(e);
                }
                
            }
            else
            {
                //Throw not right attribute exception
                //Break
            }
        }
        if(flag == 1)
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }

    public static int CompareTupleWithTuplePref(Tuple t1,AttrType[] type1,Tuple t2,AttrType[] type2,short len_in,short[] str_sizes,
  int[] pref_list,int pref_list_length)
  {
    int i=0;
        float sum1=0, sum2=0;
        for(i=0;i<pref_list_length;i++)
        {
            if(type1[pref_list[i]-1].attrType == AttrType.attrInteger)
            {
                try
                {
                    sum1 += t1.getIntFld(pref_list[i]);

                    sum2 += t2.getIntFld(pref_list[i]);
                }
                catch(Exception e)
                {
                    System.out.println(e);
                }
                
            }
            else if(type1[pref_list[i]-1].attrType == AttrType.attrReal)
            {
                try
                {
                    sum1 += t1.getFloFld(pref_list[i]);

                    sum2 += t2.getFloFld(pref_list[i]);
                }

                catch(Exception e)
                {
                    System.out.println(e);
                }
                
            }
            else
            {
                System.out.println("Not an integer or float so cannot add");
            }
        }
        if(sum1 > sum2)
        {
            return 1;
        }
        else if(sum1 < sum2)
        {
            return -1;
        }
        return 0;
  }  
}