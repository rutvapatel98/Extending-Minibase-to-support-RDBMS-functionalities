package HashIndex;

import global.AttrType;
import heap.Heapfile;
import iterator.Iterator;
import java.io.File;
import java.io.IOException;

import heap.Tuple;
import java.util.ArrayList;
import java.util.Scanner;

import org.w3c.dom.Attr;

import diskmgr.Page;
import global.PageId;
import global.RID;
import global.SystemDefs;
import heap.FieldNumberOutOfBoundException;
import heap.HFPage;
import heap.Scan;
import iterator.TupleUtils;

public class ClusteredHashIndex {
    private static final int NUMBUF = 1000;
    String _fileName;
    int _key;
    AttrType _keyType;
    float _targetUtilization;
    String _insertRecordFilename;
    Iterator _am1;
    short[] Psizes = {};
    short[] stringsize = new short[2];
    int _noOfRecords;
    int N;
    int splitPointer = 0;
    int temp; //number of tuples that are allowed in 1 heapfile
    int num_cols = 2;
    int num_cols3 = 3;
    AttrType[] lastattr;
    AttrType[] attrType2;
    AttrType[] attrType3;
    AttrType[] lastlevelattrs;
    AttrType[] attruc2;

    String datafilename;

    int hash = 0;

    //remove these variables later on 
    Boolean unclusterexists = true;

    static void create_heapfile(String input_filepath, AttrType[] attr, int num_cols, short[] str_sizes,
    String output_heapfile) {
    String nameRoot = "task2";
    String dbpath = "/tmp/" + nameRoot + System.getProperty("user.name") + ".minibase-db";
    System.out.println(dbpath);
    SystemDefs sysdef = new SystemDefs(dbpath, 10000, NUMBUF, "Clock");

    // before_creating_heapfile();
    File file = new File(input_filepath);
    ArrayList<Tuple> outerAL = new ArrayList();

    Tuple tup_temp = new Tuple();
    try {
        tup_temp.setHdr((short) num_cols, attr, str_sizes);
    } catch (Exception e) {
        System.out.println(e);
    }
    int size = tup_temp.size();
    tup_temp = new Tuple(size);
    try {
        tup_temp.setHdr((short) num_cols, attr, str_sizes);
    } catch (Exception e) {
        System.out.println(e);
    }

    try {
        Scanner sc = new Scanner(file);
        String gb = sc.nextLine();
        while (sc.hasNextLine()) {
          //  count++;
            String line = sc.nextLine();
            String[] tokens = line.split(",");
            int k =0;
            for (int i = 0; i < tokens.length; i++) {
                if(tokens[i].equals("")){
                    continue;
                }
                if (attr[k].attrType == AttrType.attrInteger) {
                    tup_temp.setIntFld(i + 1, Integer.parseInt(tokens[i]));
                }
                if (attr[k].attrType == AttrType.attrReal) {
                    tup_temp.setFloFld(k+ 1, Float.parseFloat(tokens[i]));
                }
                if (attr[k].attrType == AttrType.attrString) {
                    tup_temp.setStrFld(i + 1, tokens[i]);
                }
                if (attr[k].attrType == AttrType.attrSymbol) {
                    tup_temp.setStrFld(i + 1, tokens[i]);
                }
                if (attr[k].attrType == AttrType.attrNull) {
                    tup_temp.setStrFld(i + 1, tokens[i]);
                }
                k++;
            }
            outerAL.add(tup_temp);
            tup_temp = new Tuple(size);
            try {
                tup_temp.setHdr((short) num_cols, attr, str_sizes);
            } catch (Exception e) {
                System.out.println(e);
            }
        }
        sc.close();
    } catch (Exception e) {
        e.printStackTrace();
    }

    Heapfile hf = null;
    RID rid;
    try {
        hf = new Heapfile(output_heapfile);
    } catch (Exception e) {
        e.printStackTrace();
    }

    // Tuple tf;
    for (Tuple t : outerAL) {
        try {
            rid = hf.insertRecord(new Tuple(t).returnTupleByteArray());
            t.print(attr);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    
}

    public ClusteredHashIndex(String fileName, int key, AttrType[] attrType3, Float targetUtilization, Iterator am1, String tableName, String _datafilename) throws Exception
    {
        System.out.println("clustered hash index");
        _fileName = fileName;
        //_insertRecordFilename = insertRecordFilename;
        _key = key;
        _keyType = attrType3[key-1];
        _targetUtilization = targetUtilization;
        _am1 = am1;
        datafilename = _datafilename;
        stringsize[0] = 128;
        stringsize[1] = 128;

        attrType3 = new AttrType[3];
        attrType3[0] = new AttrType(AttrType.attrString);
        attrType3[1] = new AttrType(AttrType.attrInteger);
        attrType3[2] = new AttrType(AttrType.attrInteger);

        attruc2 = new AttrType[2];
        attruc2[0] = new AttrType(AttrType.attrInteger);
        attruc2[1] = new AttrType(AttrType.attrInteger);

        attrType2 = new AttrType[2];
        attrType2[0] = new AttrType(AttrType.attrInteger); //attrType3[key-1];
        attrType2[1] = new AttrType(AttrType.attrString);


        lastattr = new AttrType[2];
        lastattr[0] = _keyType;
        lastattr[1] = new AttrType(AttrType.attrInteger);

        lastlevelattrs = new AttrType[2];
        lastlevelattrs[0] = attrType3[key-1];
        lastlevelattrs[1] = new AttrType(AttrType.attrString);

        //creating the main heapfile
        create_heapfile(_fileName, attrType3, 3, stringsize, "clustereddatafile");


        //creating the direcotry storing <hash, heapfile name>
        Heapfile maindirectory = new Heapfile("clusteredhash"+tableName+key);
        
        Tuple temptuple = new Tuple();
        try {
            temptuple.setHdr((short) num_cols, attrType2, stringsize);
        } catch (Exception e) {
            System.out.println(e);
        }

        temptuple.setIntFld(1, 0);
        temptuple.setStrFld(2, "clusteredhash"+tableName+key+"0");

        //maindirectory.printHeapFile(attrType2, "maindirectory", num_cols, Psizes);

        maindirectory.insertRecord(new Tuple(temptuple).returnTupleByteArray());
        
        temptuple = new Tuple();
        try {
            temptuple.setHdr((short) num_cols, attrType2, stringsize);
        } catch (Exception e) {
            System.out.println(e);
        }

        temptuple.setIntFld(1, 1);
        temptuple.setStrFld(2, "clusteredhash"+tableName+key+"1");

        maindirectory.insertRecord(new Tuple(temptuple).returnTupleByteArray());

        //scan clusteredhashindex and get tuples to insert
        Insert(attrType3, attrType2, lastattr, tableName, key, lastlevelattrs);

    }

    public void Insert(AttrType[] attrs3, AttrType[] attrs, AttrType[] lastattr, String tableName, int key, AttrType[] lastlevelattrs) throws Exception
  {
        Heapfile datafile = new Heapfile(datafilename);
        Tuple t = new Tuple();
        int num_cols = 2;
        try {
            t.setHdr((short) num_cols, attrs, stringsize);
        } catch (Exception e) {
            System.out.println(e);
        }

        temp = (HFPage.MAX_SPACE-HFPage.DPFIXED)/(t.size()+HFPage.SIZE_OF_SLOT);

        N = 2;
        Heapfile        maindirectory = null; //heapfile that stores all the tuples 
        maindirectory = new Heapfile("clustereddatafile");
        Scan scan = new Scan(maindirectory);
        Tuple temptuple = new Tuple();
        RID ridmd = new RID();
        int noOfRecords = 0; 
        while((temptuple=scan.getNext(ridmd))!=null)
        {
            boolean foundpageid = false;
            try {
                temptuple.setHdr((short) num_cols3, attrs3, stringsize);
            } catch (Exception e) {
                System.out.println(e);
            }
            temptuple.print(attrs3);
            ++noOfRecords;
            //System.out.println(temptuple.getIntFld(2));
           // N = Math.round((noOfRecords)/(temp*_targetUtilization/100))+1;

            // if(attrs3[key-1].attrType==AttrType.attrString)
            // {
            //     hash = 7;
            //     for (int i = 0; i < (temptuple.getStrFld(key)).length(); i++) {
            //         hash = hash * 31 + temptuple.getStrFld(key).charAt(i);
            //     }
            //     hash = hash%N;
            // }
            // else if(attrs3[key-1].attrType==AttrType.attrInteger)
            // {
            //     hash = temptuple.getIntFld(key)%N;
            // }
            // else if(attrs3[key].attrType==AttrType.attrReal)
            // {
            //     hash = (int) ((temptuple.getFloFld(key)*100)%N);
            // }

            hash = HashFunction(attrs3, key, temptuple);


            if((_targetUtilization/100) < noOfRecords/(temp*(N+splitPointer)))
            {
                //split pointer logic aka perform linear hashing

                //add a new element in the directory and increment N 
                Heapfile directory = null;
                directory = new Heapfile("clusteredhash"+tableName+key);
                Tuple tmd = new Tuple();
                try {   
                    tmd.setHdr((short) num_cols, attrs, stringsize);
                } catch (Exception e) {
                    System.out.println(e);
                }                                                
                       tmd.setIntFld(1, N+splitPointer);
                       tmd.setStrFld(2, "clusteredhash"+tableName+key+String.valueOf(N+splitPointer));
                       System.out.println("Inserting :" + tmd.getIntFld(1) +"-" +tmd.getStrFld(2));
                       directory.insertRecord(new Tuple(tmd).returnTupleByteArray());
                   

                                   
                    int hashval = HashFunction(attrs3, key, temptuple);
                   if(hashval >= splitPointer)
                   {
                            //keep in the same bucket
                   }
                   else
                   {
                        //rehash to the new bucket added (delete from current bucket and rehash to new bucket)
                        //hash = temptuple.getIntFld(1)%(2*N);
                                    
                        Heapfile hfbeforesplit = new Heapfile("clusteredhash"+tableName+key+hash); 
                        Scan scanbeforesplit = new Scan(hfbeforesplit);
                        Tuple insertnew = new Tuple();

                        if(attrs3[key-1].attrType==AttrType.attrInteger)
                        insertnew.setIntFld(1, temptuple.getIntFld(key));
                        else if(attrs[key-1].attrType==AttrType.attrString)
                        insertnew.setStrFld(1, temptuple.getStrFld(key));
                        insertnew.setStrFld(2, "clusteredhash"+tableName+key+"key"+"_"+String.valueOf(temptuple.getStrFld(key)));
                        hfbeforesplit.insertRecord(new Tuple(insertnew).getTupleByteArray());

                        //add to the new bucket
                        Heapfile heapfiletoadd = null;
                        heapfiletoadd = new Heapfile("clusteredhash"+tableName+key+String.valueOf(N+splitPointer));
                        heapfiletoadd = new Heapfile("clusteredhash"+tableName+key+String.valueOf(N+splitPointer));
                        heapfiletoadd.insertRecord(new Tuple(temptuple).returnTupleByteArray());
                   }
                        //scan whole bucket and rehash elements
                        Heapfile rehashhf = new Heapfile("clusteredhash"+tableName+key+splitPointer); 
                        Scan rehashscan = new Scan(rehashhf);
                        Tuple rehashtuple = new Tuple();
                        RID rehashrid = new RID();
                        //RID[] ridstoshift = new RID[rehashhf.getRecCnt()];
                        ArrayList<RID> ridstoshift = new ArrayList<RID>();
                        int increhash = 0;
                        while((rehashtuple=rehashscan.getNext(rehashrid))!=null)
                        {
                            RID ridds = rehashscan.getRID();
                            try {
                                rehashtuple.setHdr((short) num_cols, lastlevelattrs, stringsize);
                            } catch (Exception e) {
                                System.out.println(e);
                            }  
                            rehashtuple.print(lastlevelattrs);  
                            try {
                                rehashtuple.setHdr((short) num_cols, lastlevelattrs, stringsize);
                            } catch (Exception e) {
                                System.out.println(e);
                            }    
                            int rehashcount = ReHashFunction(attrs3, key, rehashtuple) ;  
                               if(rehashcount==splitPointer)
                               {
                                   //nothing happens. it stays in the same bucket
                               }
                               else{
                                   //move to the new formed bucket
                                   ridstoshift.add(ridds);
                                   //ridstoshift[increhash]=rehashrid;
                                   //increhash++;
                               }

                        }

                        //add to the new bucket
                        Heapfile heapfiletoadd = null;
                        heapfiletoadd = new Heapfile("clusteredhash"+tableName+key+String.valueOf(N+splitPointer));
                        for(int i=0; i<ridstoshift.size(); i++)
                        {
                            Tuple tupled = new Tuple();
                            try {
                                tupled.setHdr((short) num_cols, lastlevelattrs, stringsize);
                            } catch (Exception e) {
                                System.out.println(e);
                            }
                            tupled = rehashhf.getRecord(ridstoshift.get(i));
                            try {
                                tupled.setHdr((short) num_cols, lastlevelattrs, stringsize);
                            } catch (Exception e) {
                                System.out.println(e);
                            }
                            heapfiletoadd.insertRecord(new Tuple(tupled).returnTupleByteArray());
                        
                        }


                        //delete from previous bucket
                        for(int i=0; i<ridstoshift.size(); i++)
                        {
                            Tuple tupledd = rehashhf.getRecord(ridstoshift.get(i));
                            try {
                                tupledd.setHdr((short) num_cols, lastlevelattrs, stringsize);
                            } catch (Exception e) {
                                System.out.println(e);
                            }
                            tupledd.print(lastlevelattrs);
                            rehashhf.deleteRecord(ridstoshift.get(i));
                            
                        }
                        if(rehashhf.getRecCnt()==0)
                            rehashhf.deleteFile();
                        



                        // //delete from the previous bucket
                        // Scan sctoaddnew = new Scan(directory);
                        // Tuple tp = new Tuple();
                        // RID rid22 = new RID();
                        // while((tp=scan.getNext(rid22))!=null)
                        // {
                        //     try {
                        //         tp.setHdr((short) num_cols, attrs, stringsize);
                        //     } catch (Exception e) {
                        //         System.out.println(e);
                        //     }
                        //     if(TupleUtils.Equal(tp,temptuple,attrs3,attrs3.length))
                        //     {
                        //         directory.deleteRecord(rid22);
                        //     }
                        // }


                        
                   
                        splitPointer++;  
                        
                        if(splitPointer==N)
                        {
                            splitPointer = 0;
                            N=2*N;
                        }


            }



            //open the heapfile

            Heapfile        clusteredhash = null; //heapfile that stores all the tuples 
            clusteredhash = new Heapfile("clusteredhash"+tableName+key+hash);
            Scan scanch = new Scan(clusteredhash);
            Tuple temptuplech = new Tuple();
            RID ridch = new RID();
            boolean foundtuple = false;
            //if it is already in the heapfile then get it else insert the key
            while((temptuplech=scanch.getNext(ridch))!=null)
            {
                try {
                    temptuplech.setHdr((short) num_cols, lastlevelattrs, stringsize);
                } catch (Exception e) {
                    System.out.println(e);
                }
                //temptuplech.print(lastlevelattrs);
                try {
                    temptuple.setHdr((short) num_cols3, attrs3, stringsize);
                } catch (Exception e) {
                    System.out.println(e);
                }
                //temptuple.print(attrs3);
                int ans=43;
                if(attrs3[key-1].attrType==AttrType.attrString)
                {
                    String a = temptuple.getStrFld(key);
                    String b = temptuplech.getStrFld(1);
                     ans = a.compareTo(b);
                }else if(attrs3[key-1].attrType==AttrType.attrInteger)
                {
                    int x = temptuple.getIntFld(key);
                    int y = temptuplech.getIntFld(1);
                    if(x==y)
                        ans=0;
                }
                
                if(ans == 0)
                {
                    //temptuple.print(attrs3);
                    // temptuplech.print(attrs);
                    Page page = new Page();
                    foundtuple=true;
                    Heapfile lasthf = null;
                    String name = temptuplech.getStrFld(2);
                    lasthf = new Heapfile(name);
                    Scan scan3 = new Scan(lasthf);
                    Tuple tuple3 = new Tuple();
                    RID rid3 = new RID();
                    while((tuple3=scan3.getNext(rid3))!=null)
                    {
                        try {
                            tuple3.setHdr((short) num_cols, lastattr, stringsize);
                        } catch (Exception e) {
                            System.out.println(e);
                        }
                    int temppp = tuple3.getIntFld(2);
                    PageId pageset = new PageId(temppp);
                    SystemDefs.JavabaseBM.pinPage(pageset, page, false);
                    HFPage hfpage = new HFPage(page);

                    // System.out.println(temptuple.returnTupleByteArray().length);
                    if(temptuple.returnTupleByteArray().length<hfpage.available_space())
                    {
                        datafile.insertRecordAtPage(new Tuple(temptuple).returnTupleByteArray(), new PageId(tuple3.getIntFld(2)));
                        foundpageid = true;
                        break;
                    }

                    }
                    if(!foundpageid)
                    {
                        Tuple insertlasttuplepid = new Tuple();
                        try {
                            insertlasttuplepid.setHdr((short) num_cols, lastattr, Psizes);
                        } catch (Exception e) {
                            System.out.println(e);
                        }

                        Page pagelastinsert = new Page();
                        PageId pageidlast = new PageId();
                        pageidlast = SystemDefs.JavabaseBM.newPage(pagelastinsert, 1);
                        temptuple.tupleCopy(insertlasttuplepid);
                        //insertlasttuplepid.print(attrs3);
                        // insertlasttuplepid.setIntFld(1, temptuple.getIntFld(1));
                        // insertlasttuplepid.setIntFld(2, pageidlast.pid);
                        datafile.insertRecordAtPage(new Tuple(insertlasttuplepid).getTupleByteArray(), pageidlast);


                        
                    }
                    //print data file
                    Heapfile        df = null; 
                    df = new Heapfile(datafilename);
                    Scan scandf = new Scan(df);
                    Tuple tempdf = new Tuple();
                    RID riddf = new RID();
                    while((tempdf=scandf.getNext(riddf))!=null)
                    {
                        try {
                            tempdf.setHdr((short) num_cols3, attrs3, stringsize);
                        } catch (Exception e) {
                            System.out.println(e);
                        }
                        //tempdf.print(attrs3);
                    }
                }
            }

            if(!foundtuple)
            {
                Tuple tempp = new Tuple();
                try {
                    tempp.setHdr((short) num_cols, lastlevelattrs, stringsize);
                } catch (Exception e) {
                    System.out.println(e);
                }
                if(attrs3[key-1].attrType==AttrType.attrString)
                {
                    tempp.setStrFld(1, temptuple.getStrFld(key)); 
                }
                else if(attrs3[key-1].attrType==AttrType.attrInteger)
                {
                    tempp.setIntFld(1, temptuple.getIntFld(key)); 
                }
                String lasthfname = "";
                if(attrs3[key-1].attrType==AttrType.attrString)
                 lasthfname = "clusteredhash"+tableName+key+"key"+"_"+String.valueOf(temptuple.getStrFld(key));
                else if(attrs3[key].attrType==AttrType.attrInteger)
                 lasthfname = "clusteredhash"+tableName+key+"key"+"_"+String.valueOf(temptuple.getIntFld(key));

                tempp.setStrFld(2, lasthfname);
                try {
                    tempp.setHdr((short) num_cols, lastlevelattrs, stringsize);
                } catch (Exception e) {
                    System.out.println(e);
                }
                // if(attrs3[key-1].attrType==AttrType.attrString)
                //     System.out.println("Inserting :" + tempp.getStrFld(1) +"-" +tempp.getStrFld(2));
                // else if(attrs3[key].attrType==AttrType.attrInteger)
                //     System.out.println("Inserting :" + tempp.getIntFld(1) +"-" +tempp.getStrFld(2));
                try {
                    tempp.setHdr((short) num_cols, lastlevelattrs, stringsize);
                } catch (Exception e) {
                    System.out.println(e);
                }
                //tempp.print(lastlevelattrs);
                clusteredhash.insertRecord(new Tuple(tempp).getTupleByteArray());
                System.out.println(clusteredhash.getRecCnt());

                //open the last level heapfile
                Heapfile        lasthf = null; 
                if(attrs3[key-1].attrType==AttrType.attrString)
                lasthf = new Heapfile("clusteredhash"+tableName+key+"key"+"_"+String.valueOf(temptuple.getStrFld(key)));
                else if(attrs3[key].attrType==AttrType.attrInteger)
                lasthf = new Heapfile("clusteredhash"+tableName+key+"key"+"_"+String.valueOf(temptuple.getIntFld(key)));
                Tuple lasttuple = new Tuple();
                RID lastrid = new RID();

                Tuple insertlasttuple = new Tuple();
                try {
                    insertlasttuple.setHdr((short) num_cols, lastattr, stringsize);
                } catch (Exception e) {
                    System.out.println(e);
                }

                Page pagelast = new Page();
                PageId pageidlast = new PageId();
                pageidlast = SystemDefs.JavabaseBM.newPage(pagelast, 1);
                try {
                    temptuple.setHdr((short) num_cols3, attrs3, stringsize);
                } catch (Exception e) {
                    System.out.println(e);
                }

                if(attrs3[key-1].attrType==AttrType.attrString)
                    insertlasttuple.setStrFld(1, temptuple.getStrFld(key));
                else if(attrs3[key-1].attrType==AttrType.attrInteger)
                    insertlasttuple.setIntFld(1, temptuple.getIntFld(key));

                insertlasttuple.setIntFld(2, pageidlast.pid);
                try {
                    insertlasttuple.setHdr((short) num_cols, lastattr, stringsize);
                } catch (Exception e) {
                    System.out.println(e);
                }
                try {
                    temptuple.setHdr((short) num_cols3, attrs3, stringsize);
                } catch (Exception e) {
                    System.out.println(e);
                }
                //temptuple.print(attrs3);
                //insertlasttuple.print(lastattr);
                RID riddd = lasthf.insertRecord(new Tuple(insertlasttuple).getTupleByteArray());
                Scan lastscan = new Scan(lasthf);
                Tuple insertdf = new Tuple();
                         


                //print last heap file in structure
                while((lasttuple=lastscan.getNext(lastrid))!=null)
                {
                    try {
                        lasttuple.setHdr((short) num_cols, lastattr, stringsize);
                    } catch (Exception e) {
                        System.out.println(e);
                    }
                    //lasttuple.print(lastattr);
                }
                try {
                    insertdf.setHdr((short) num_cols3, attrs3, stringsize);
                } catch (Exception e) {
                    System.out.println(e);
                }
                insertdf.setStrFld(1, temptuple.getStrFld(1));
                insertdf.setIntFld(2, temptuple.getIntFld(2));         
                insertdf.setIntFld(3, temptuple.getIntFld(3));       

                //insertdf.print(attrs3);
                //insert in the data file
                datafile.insertRecordAtPage(new Tuple(insertdf).getTupleByteArray(), pageidlast);
                Heapfile        datafilehf = null; //heapfile that stores all the tuples 
                datafilehf = new Heapfile(datafilename);
                Tuple dftuple = new Tuple();
                RID dfrid = new RID();
                Scan dfscan = new Scan(datafilehf);
                
                //print data file
                System.out.println("The data file is as follows:");
                Heapfile        df = null; 
                df = new Heapfile(datafilename);
                Scan scandf = new Scan(df);
                Tuple tempdf = new Tuple();
                RID riddf = new RID();
                while((tempdf=scandf.getNext(riddf))!=null)
                {
                    try {
                        tempdf.setHdr((short) num_cols3, attrs3, stringsize);
                    } catch (Exception e) {
                        System.out.println(e);
                    }
                    tempdf.print(attrs3);
                }
                System.out.println("datafile count "+df.getRecCnt());
            }
        }
        System.out.println("Clustered Hash Inserted successfully!");
  }

    public void Delete(Tuple toDeletetuple, String tableName, int key, AttrType[] attrType3, String datafilename) throws Exception
    {
        try {
            toDeletetuple.setHdr((short) num_cols3, attrType3, stringsize);
        } catch (Exception e) {
            System.out.println(e);
        }
        toDeletetuple.print(attrType3);
        int temp = 0;
        String tempstring="";
        if(attrType3[key-1].attrType == AttrType.attrInteger)
         temp = toDeletetuple.getIntFld(key);
         else if(attrType3[key-1].attrType == AttrType.attrString)
         tempstring = toDeletetuple.getStrFld(key);

         Heapfile lasthf = null;

         if(attrType3[key-1].attrType == AttrType.attrInteger)
         lasthf = new Heapfile("clusteredhash"+tableName+key+"key"+"_"+temp);
         else if(attrType3[key-1].attrType == AttrType.attrString)
         lasthf = new Heapfile("clusteredhash"+tableName+key+"key"+"_"+tempstring);

        Tuple lasthftuple = new Tuple();
        RID lastrid = new RID();
        try {
            lasthftuple.setHdr((short) num_cols, lastattr, stringsize);
        } catch (Exception e) {
            System.out.println(e);
        }
        Scan lastscan = new Scan(lasthf);
        System.out.println(lasthf.getRecCnt());
        RID[] arr = new RID[lasthf.getRecCnt()+2];
        lasthftuple=lastscan.getNext(lastrid);
        RID[] ridforlasthf = new RID[lasthf.getRecCnt()];
        int inc = 0;
        int countt =1;

                //each tuple will be <key, pageid> pair
                while(countt <= lasthf.getRecCnt())
                {
                    try {
                        lasthftuple.setHdr((short) num_cols, lastattr, stringsize);
                    } catch (Exception e) {
                        System.out.println(e);
                    }

                    int pageid = lasthftuple.getIntFld(2);
                    Page page = new Page();
                    SystemDefs.JavabaseBM.pinPage(new PageId(pageid), page, false);
                    HFPage hfpage = new HFPage(page);
                    RID firstrid = hfpage.firstRecord();
                    int tempcount = 0;
                    int count = 0;

                    while(firstrid!=null)
                    {
                        //delete only if they are same tuple.
                        Tuple tuple = hfpage.getRecord(firstrid);
                        try {
                            tuple.setHdr((short) num_cols3, attrType3, stringsize);
                        } catch (Exception e) {
                            System.out.println(e);
                        }
                        tuple.print(attrType3);
                        boolean compare = TupleUtils.Equal(tuple, toDeletetuple, attrType3, 3);

                        //arr will store all the rids to be deleted
                        if(compare)
                            arr[count++]=firstrid;

                        firstrid = hfpage.nextRecord(firstrid);
                        tempcount++;
                        
                    }
                    SystemDefs.JavabaseBM.unpinPage(new PageId(pageid), false);
                    Heapfile datafileclustered = new Heapfile(datafilename);
                    for(int i=0; i<arr.length;i++)
                    {
                        System.out.println(arr[i]);
                        if(arr[i]!=null)
                        datafileclustered.deleteRecord(arr[i]);
                    }

                    if(tempcount==count)
                    {
                        ridforlasthf[inc++]=lastrid;
                    }
                    lasthftuple=lastscan.getNext(lastrid);
                    countt++;

                    //TODO: remove the heapfile from second and first level if they are empty
                    //TODO: perform merging 

                    //TODO: call function to check that(talk to nithya)
                }
                for(int i=0; i<ridforlasthf.length; i++)
                {
                    System.out.println(ridforlasthf[i]);
                    if(ridforlasthf[i]==null)
                    {
                        continue;
                    }
                    else{
                    lasthf.deleteRecord(ridforlasthf[i]);
                    }
                }

                if(lasthf.getRecCnt() == 0)
                {
                    //delete the last level heapfie
                    lasthf.deleteFile();
                }





                //if unclustered exists (delete from it's index file)
                Heapfile lasthfuc = null;

                if(unclusterexists)
                {

                    lasthfuc = new Heapfile("unclusteredhash"+tableName+key+"key"+"_"+String.valueOf(toDeletetuple.getIntFld(key)));
                    Tuple lasthftup = new Tuple();
                    RID lasthfrid = new RID();
                    RID todeltup = new RID();
                    Scan lasthfucscan = new Scan(lasthfuc);

                    RID[] ridforlasthfuc = new RID[lasthfuc.getRecCnt()];
                    int incuc = 0;
                    
                    while((lasthftup=lasthfucscan.getNext(lasthfrid))!=null)
                    {
                        try {
                            lasthftup.setHdr((short) num_cols, attruc2, Psizes);
                        } catch (Exception e) {
                            System.out.println(e);
                        }
                        lasthftup.print(attruc2);

                        Page page2 = new Page();
                        SystemDefs.JavabaseBM.pinPage(new PageId(lasthftup.getIntFld(2)), page2, false);
                        HFPage hfpage2 = new HFPage(page2);

                        todeltup.pageNo.pid = lasthftup.getIntFld(2);
                        todeltup.slotNo = lasthftup.getIntFld(1);

                        boolean compare = TupleUtils.Equal(hfpage2.getRecord(todeltup), toDeletetuple, attrType3, 3);
                        if(compare)
                        {
                            ridforlasthfuc[incuc++]=lasthfrid;
                        }
                    }

                    for(int i=0; i<ridforlasthfuc.length; i++)
                    {
                        System.out.println(ridforlasthfuc[i]);
                        if(ridforlasthfuc[i]==null)
                        {
                            continue;
                        }
                        else{
                            lasthfuc.deleteRecord(ridforlasthfuc[i]);
                        }
                    }                
                }
    }

    public int HashFunction(AttrType[] attrs3, int key, Tuple temptuple) throws FieldNumberOutOfBoundException, IOException{
        if(attrs3[key-1].attrType==AttrType.attrString)
            {
                hash = 7;
                for (int i = 0; i < (temptuple.getStrFld(key)).length(); i++) {
                    hash = hash * 31 + temptuple.getStrFld(key).charAt(i);
                }
                hash = hash%N;
            }
            else if(attrs3[key-1].attrType==AttrType.attrInteger)
            {
                hash = temptuple.getIntFld(key)%N;
            }
            else if(attrs3[key].attrType==AttrType.attrReal)
            {
                hash = (int) ((temptuple.getFloFld(key)*100)%N);
            }
            return hash;
    }

    public int ReHashFunction(AttrType[] attrs3, int key, Tuple temptuple) throws FieldNumberOutOfBoundException, IOException{
        if(attrs3[key-1].attrType==AttrType.attrString)
            {
                hash = 7;
                for (int i = 0; i < (temptuple.getStrFld(1)).length(); i++) {
                    hash = hash * 31 + temptuple.getStrFld(1).charAt(i);
                }
                hash = hash%(2*N);
            }
            else if(attrs3[key-1].attrType==AttrType.attrInteger)
            {
                hash = temptuple.getIntFld(1)%(2*N);
            }
            else if(attrs3[key].attrType==AttrType.attrReal)
            {
                hash = (int) ((temptuple.getFloFld(1)*100)%(2*N));
            }
            return hash;
    }

   
}
