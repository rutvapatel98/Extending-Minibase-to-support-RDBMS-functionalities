package HashIndex;

import java.io.File;
import global.AttrType;
import heap.Tuple;
import java.util.ArrayList;
import java.util.Scanner;

import org.w3c.dom.Attr;

import diskmgr.Page;
import global.RID;
import global.SystemDefs;
import heap.HFPage;
import heap.Heapfile;
import heap.Scan;
import iterator.Iterator;
import iterator.TupleUtils;
import jdk.swing.interop.DragSourceContextWrapper;

public class UnclusteredHashIndex {

    private static final int NUMBUF = 1000;
    String _fileName;
    int _key;
    AttrType _keyType;
    float _targetUtilization;
    // String _insertRecordFilename;
    Iterator _am1;
    short[] Psizes = {};
    short[] stringsize = new short[2];
    int _noOfRecords;
    int N;
    int splitPointer = 0;
    int temp; // number of tuples that are allowed in 1 heapfile
    int num_cols = 2;
    int num_cols3 = 3;
    int num_cols1 = 1;
    AttrType[] attrType_lasthf;
    AttrType[] attrType2;
    AttrType[] attrType3;
    AttrType[] attrType_midhf;

    // static void create_heapfile(String input_filepath, AttrType[] attr, int
    // num_cols, short[] str_sizes,

    // String output_heapfile) {
    // String nameRoot = "task2";
    // String dbpath = "/tmp/" + nameRoot + System.getProperty("user.name") +
    // ".minibase-db";
    // System.out.println(dbpath);
    // SystemDefs sysdef = new SystemDefs(dbpath, 10000, NUMBUF, "Clock");

    // // before_creating_heapfile();
    // File file = new File(input_filepath);
    // ArrayList<Tuple> outerAL = new ArrayList();

    // Tuple tup_temp = new Tuple();
    // try {
    // tup_temp.setHdr((short) num_cols, attr, str_sizes);
    // } catch (Exception e) {
    // System.out.println(e);
    // }
    // int size = tup_temp.size();
    // tup_temp = new Tuple(size);
    // try {
    // tup_temp.setHdr((short) num_cols, attr, str_sizes);
    // } catch (Exception e) {
    // System.out.println(e);
    // }

    // try {
    // Scanner sc = new Scanner(file);
    // String gb = sc.nextLine();
    // while (sc.hasNextLine()) {
    // // count++;
    // String line = sc.nextLine();
    // String[] tokens = line.split(",");
    // int k =0;
    // for (int i = 0; i < tokens.length; i++) {
    // if(tokens[i].equals("")){
    // continue;
    // }
    // if (attr[k].attrType == AttrType.attrInteger) {
    // tup_temp.setIntFld(i + 1, Integer.parseInt(tokens[i]));
    // }
    // if (attr[k].attrType == AttrType.attrReal) {
    // tup_temp.setFloFld(k+ 1, Float.parseFloat(tokens[i]));
    // }
    // if (attr[k].attrType == AttrType.attrString) {
    // tup_temp.setStrFld(i + 1, tokens[i]);
    // }
    // if (attr[k].attrType == AttrType.attrSymbol) {
    // tup_temp.setStrFld(i + 1, tokens[i]);
    // }
    // if (attr[k].attrType == AttrType.attrNull) {
    // tup_temp.setStrFld(i + 1, tokens[i]);
    // }
    // k++;
    // }
    // outerAL.add(tup_temp);
    // tup_temp = new Tuple(size);
    // try {
    // tup_temp.setHdr((short) num_cols, attr, str_sizes);
    // } catch (Exception e) {
    // System.out.println(e);
    // }
    // }
    // sc.close();
    // } catch (Exception e) {
    // e.printStackTrace();
    // }

    // Heapfile hf = null;
    // RID rid;
    // try {
    // hf = new Heapfile(output_heapfile);
    // } catch (Exception e) {
    // e.printStackTrace();
    // }

    // // Tuple tf;
    // for (Tuple t : outerAL) {
    // try {
    // rid = hf.insertRecord(new Tuple(t).returnTupleByteArray());
    // t.print(attr);
    // } catch (Exception e) {
    // e.printStackTrace();
    // }
    // }

    // }

    public UnclusteredHashIndex(String fileName, Tuple inserttuple, int key, AttrType[] keyType,
            Float targetUtilization, Iterator am1, String tableName, String datafile) throws Exception {
        // System.out.println("unclustered hash index");
        _fileName = fileName;
        _key = key;
        _keyType = keyType[key - 1];
        _targetUtilization = targetUtilization;
        _am1 = am1;
        stringsize[0] = 32;
        stringsize[1] = 64;

        attrType3 = new AttrType[3];
        attrType3[0] = keyType[key - 1];
        attrType3[1] = new AttrType(AttrType.attrInteger);
        attrType3[2] = new AttrType(AttrType.attrInteger);

        attrType2 = new AttrType[2];
        attrType2[0] = keyType[key - 1];
        attrType2[1] = new AttrType(AttrType.attrString);

        attrType_lasthf = new AttrType[2];
        attrType_lasthf[0] = new AttrType(AttrType.attrInteger);
        attrType_lasthf[1] = new AttrType(AttrType.attrInteger);

        attrType_midhf = new AttrType[2];
        attrType_midhf[0] = new AttrType(AttrType.attrInteger);
        attrType_midhf[1] = new AttrType(AttrType.attrString);

        short[] Psizes = {};
        int[] insertRecordsArray = new int[20];

        // create_heapfile(_fileName,attrType3 , attrType3.length, stringsize,
        // datafile);

        Heapfile hf = new Heapfile(datafile);

        _noOfRecords = hf.getRecCnt();
        // System.out.print(_noOfRecords);
        // temp is the number of tuples in a heap file such that 75% of the file is
        // utilized

        Tuple t = new Tuple();
        int num_cols = 2;
        try {
            t.setHdr((short) num_cols, attrType2, stringsize);
        } catch (Exception e) {
            System.out.println(e);
        }

        temp = (HFPage.MAX_SPACE - HFPage.DPFIXED) / (t.size() + HFPage.SIZE_OF_SLOT);
        N = Math.round((_noOfRecords) / (temp * _targetUtilization / 100)) + 1;
        // System.out.println("Insert records using static hashing");
        Insert(attrType3, attrType2, attrType_lasthf, tableName, key, datafile);

        // print the hash structure formed
        for (int i = 0; i < N; i++) {
            Heapfile printhf = new Heapfile("unclusteredhash" + tableName + key + String.valueOf(i));
            // System.out.print("Hash Bucket "+i+ "->");
            Tuple printtuple = new Tuple();
            Scan printscan = new Scan(printhf);
            RID printrid = new RID();

            while ((printtuple = printscan.getNext(printrid)) != null) {
                try {
                    printtuple.setHdr((short) num_cols, attrType2, stringsize);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                // printtuple.print(attrType2);

                // open last level file
                Heapfile hflastlevel = new Heapfile(printtuple.getStrFld(2));
                Tuple tuplelastlevel = new Tuple();
                Scan sclastlevel = new Scan(hflastlevel);
                RID ridlastlevel = new RID();
                // System.out.println("last level heapfile");
                while ((tuplelastlevel = sclastlevel.getNext(ridlastlevel)) != null) {
                    try {
                        tuplelastlevel.setHdr((short) num_cols, attrType_lasthf, stringsize);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    // tuplelastlevel.print(attrType_lasthf);
                }

            }
            // System.out.println();
        }

        // System.out.println("Insert the records");
        // InsertRecord(attrType3, attrType2, inserttuple, attrType_lasthf);

    }

    public void Insert(AttrType[] attrs3, AttrType[] attrs, AttrType[] attrs_lasthf, String tableName, int key,
            String datafile) throws Exception {
        Tuple t = new Tuple();
        int num_cols = 2;
        try {
            t.setHdr((short) num_cols, attrs, stringsize);
        } catch (Exception e) {
            System.out.println(e);
        }

        temp = (HFPage.MAX_SPACE - HFPage.DPFIXED) / (t.size() + HFPage.SIZE_OF_SLOT);
        N = Math.round((_noOfRecords) / (temp * _targetUtilization / 100)) + 1;

        Heapfile maindirectory = null; // heapfile that stores all the tuples
        maindirectory = new Heapfile(datafile);
        Scan scan = new Scan(maindirectory);
        Tuple temptuple = new Tuple();
        RID ridmd = new RID();
        int hash;
        int noOfRecords = 0;
        while ((temptuple = scan.getNext(ridmd)) != null) {
            RID temprid = scan.getRID();
            boolean foundpageid = false;
            try {
                temptuple.setHdr((short) num_cols3, attrs3, stringsize);
            } catch (Exception e) {
                System.out.println(e);
            }
            // temptuple.print(attrs3);
            ++noOfRecords;

            hash = 0;
            if (attrs3[key - 1].attrType == AttrType.attrString) {
                hash = 7;
                for (int i = 0; i < (temptuple.getStrFld(key)).length(); i++) {
                    hash = hash * 31 + temptuple.getStrFld(key).charAt(i);
                }
                hash = hash % N;
            } else if (attrs3[key - 1].attrType == AttrType.attrInteger) {
                hash = temptuple.getIntFld(key) % N;
            } else if (attrs3[key].attrType == AttrType.attrReal) {
                hash = (int) ((temptuple.getFloFld(key) * 100) % N);
            }

            // creating the direcotry storing <hash, heapfile name>

            Heapfile directory = new Heapfile("unclusteredhash" + tableName + key);
            Tuple directorytuple = new Tuple();
            Scan scandir = new Scan(directory);
            Tuple dirscann = new Tuple();
            RID scanrid = new RID();
            Boolean founddirtup = false;
            while ((dirscann = scandir.getNext(scanrid)) != null) {
                try {
                    dirscann.setHdr((short) num_cols, attrs, stringsize);
                } catch (Exception e) {
                    System.out.println(e);
                }
                if (dirscann.getIntFld(1) == hash) {
                    founddirtup = true;
                    break;
                }
            }
            if (!founddirtup) {
                try {
                    directorytuple.setHdr((short) num_cols, attrType_midhf, stringsize);
                } catch (Exception e) {
                    System.out.println(e);
                }
                directorytuple.setIntFld(1, hash);
                directorytuple.setStrFld(2, "unclusteredhash" + tableName + key + hash);
                directory.insertRecord(new Tuple(directorytuple).getTupleByteArray());
                // directorytuple.print(attrType_midhf);
            }

            // open the heapfile

            Heapfile unclusteredhash = null; // heapfile that stores all the tuples
            unclusteredhash = new Heapfile("unclusteredhash" + tableName + key + hash);
            Scan scanch = new Scan(unclusteredhash);
            Tuple temptuplech = new Tuple();
            RID ridch = new RID();
            boolean foundtuple = false;
            // if it is already in the heapfile then get it else insert the key
            while ((temptuplech = scanch.getNext(ridch)) != null) {
                try {
                    temptuplech.setHdr((short) num_cols, attrs, stringsize);
                } catch (Exception e) {
                    System.out.println(e);
                }

                // if(temptuplech.getIntFld(1)==temptuple.getIntFld(1))
                // {
                String a = temptuple.getStrFld(1);
                String b = temptuplech.getStrFld(1);
                if (a.compareTo(b) == 0) {
                    foundtuple = true;
                    // temptuple.print(attrs3);
                    // temptuplech.print(attrs);
                    Page page = new Page();
                    foundtuple = true;
                    Heapfile lasthfn = null;
                    String name = temptuplech.getStrFld(2);
                    lasthfn = new Heapfile(name);
                    Tuple tempinserttuple = new Tuple();
                    try {
                        tempinserttuple.setHdr((short) num_cols, attrs_lasthf, stringsize);
                    } catch (Exception e) {
                        System.out.println(e);
                    }

                    tempinserttuple.setIntFld(1, temprid.slotNo);
                    tempinserttuple.setIntFld(2, temprid.pageNo.pid);
                    lasthfn.insertRecord(new Tuple(tempinserttuple).getTupleByteArray());
                    Scan scan3 = new Scan(lasthfn);
                    Tuple tuple3 = new Tuple();
                    RID rid3 = new RID();

                    // System.out.println(lasthfn.getRecCnt());
                    // check the final heapfile
                    while ((tuple3 = scan3.getNext(rid3)) != null) {
                        try {
                            tuple3.setHdr((short) num_cols, attrs_lasthf, stringsize);
                        } catch (Exception e) {
                            System.out.println(e);
                        }
                        //tuple3.print(attrs_lasthf);
                    }
                }
            }

            if (!foundtuple) {
                Tuple tempp = new Tuple();
                try {
                    tempp.setHdr((short) num_cols, attrs, stringsize);
                } catch (Exception e) {
                    System.out.println(e);
                }

                if (attrs3[key - 1].attrType == AttrType.attrString) {
                    tempp.setStrFld(1, temptuple.getStrFld(key));
                } else if (attrs3[key - 1].attrType == AttrType.attrInteger) {
                    tempp.setIntFld(1, temptuple.getIntFld(key));
                }

                // tempp.setIntFld(1, temptuple.getIntFld(1));
                String lasthfname = "";

                if (attrs3[key - 1].attrType == AttrType.attrInteger)
                    lasthfname = "unclusteredhash" + tableName + key + "key" + "_"
                            + String.valueOf(temptuple.getIntFld(key));
                else if (attrs3[key - 1].attrType == AttrType.attrString)
                    lasthfname = "unclusteredhash" + tableName + key + "key" + "_"
                            + String.valueOf(temptuple.getStrFld(key));

                tempp.setStrFld(2, lasthfname);
                // System.out.println("Inserting :" + tempp.getStrFld(1) +"-"
                // +tempp.getStrFld(2));
                //tempp.print(attrs);
                unclusteredhash.insertRecord(new Tuple(tempp).getTupleByteArray());

                // open the last level heapfile
                Heapfile lasthf = null; // heapfile that stores all the tuples
                if (attrs3[key - 1].attrType == AttrType.attrInteger)
                    lasthf = new Heapfile("unclusteredhash" + tableName + key + "key" + "_"
                            + String.valueOf(temptuple.getIntFld(key)));
                else if (attrs3[key - 1].attrType == AttrType.attrString)
                    lasthf = new Heapfile("unclusteredhash" + tableName + key + "key" + "_"
                            + String.valueOf(temptuple.getStrFld(key)));

                Tuple lasttuple = new Tuple();
                RID lastrid = new RID();

                Tuple lasttup = new Tuple();
                try {
                    lasttup.setHdr((short) num_cols, attrs_lasthf, stringsize);
                } catch (Exception e) {
                    System.out.println(e);
                }

                lasttup.setIntFld(1, temprid.slotNo);
                lasttup.setIntFld(2, temprid.pageNo.pid);

                lasthf.insertRecord(new Tuple(lasttup).getTupleByteArray());

                // check last hf
                Scan scanll = new Scan(lasthf);
                Tuple tuplell = new Tuple();
                RID ridll = new RID();

                // System.out.println(lasthf.getRecCnt());

                // check the final heapfile
                while ((tuplell = scanll.getNext(ridll)) != null) {
                    try {
                        tuplell.setHdr((short) num_cols, attrs_lasthf, stringsize);
                    } catch (Exception e) {
                        System.out.println(e);
                    }
                    //tuplell.print(attrs_lasthf);
                }
            }
        }

    }

    public void InsertRecord(AttrType[] attrs3, AttrType[] attrs, Tuple temptuple, AttrType[] attrs_lasthf)
            throws Exception {
        Tuple t = new Tuple();
        int num_cols = 2;
        try {
            t.setHdr((short) num_cols, attrs, stringsize);
        } catch (Exception e) {
            System.out.println(e);
        }

        temp = (HFPage.MAX_SPACE - HFPage.DPFIXED) / (t.size() + HFPage.SIZE_OF_SLOT);
        N = Math.round((_noOfRecords) / (temp * _targetUtilization / 100)) + 1;

        Heapfile maindirectory = null; // heapfile that stores all the tuples
        maindirectory = new Heapfile("unclusteredhashindexx");
        Scan scan = new Scan(maindirectory);
        // Tuple temptuple = new Tuple();
        RID ridmd = new RID();
        int hash;
        int noOfRecords = 0;
        // while((temptuple=scan.getNext(ridmd))!=null)
        // {

        boolean foundpageid = false;
        try {
            temptuple.setHdr((short) num_cols3, attrs3, stringsize);
        } catch (Exception e) {
            System.out.println(e);
        }
        //temptuple.print(attrs3);
        ++noOfRecords;

        if ((_targetUtilization / 100) < _noOfRecords / (temp * (N + splitPointer))) {
            // split pointer logic aka perform linear hashing
            splitPointer++;

            // add a new element in the directory and increment N
            Heapfile directory = null;
            directory = new Heapfile("unclusteredhash" + String.valueOf((N + splitPointer)));
            Tuple tmd = new Tuple();
            try {
                tmd.setHdr((short) num_cols, attrs, stringsize);
            } catch (Exception e) {
                System.out.println(e);
            }
            tmd.setIntFld(1, N + splitPointer);
            tmd.setStrFld(2, "unclusteredhash" + String.valueOf(N + splitPointer) + "_" + temptuple.getIntFld(1));
            // System.out.println("Inserting :" + tmd.getIntFld(1) +"-" +tmd.getStrFld(2));
            directory.insertRecord(new Tuple(tmd).returnTupleByteArray());

            if (splitPointer == N) {
                splitPointer = 0;
                N = 2 * N;
            }
            if (temptuple.getIntFld(1) % N > splitPointer) {
                // keep in the same bucket
            } else {
                // rehash to the new bucket added (delete from current bucket and rehash to new
                // bucket)
                hash = temptuple.getIntFld(1) % (2 * N);

                // delete from the previous bucket
                Scan sctoaddnew = new Scan(directory);
                Tuple tp = new Tuple();
                RID rid22 = new RID();
                while ((tp = scan.getNext(rid22)) != null) {
                    try {
                        tp.setHdr((short) num_cols, attrs, stringsize);
                    } catch (Exception e) {
                        System.out.println(e);
                    }
                    if (TupleUtils.Equal(tp, temptuple, attrs3, attrs3.length)) {
                        directory.deleteRecord(rid22);
                    }
                }
                // add to the new bucket
                Heapfile heapfiletoadd = null;
                heapfiletoadd = new Heapfile("unclusteredhash" + String.valueOf(N + splitPointer));
                heapfiletoadd.insertRecord(new Tuple(temptuple).returnTupleByteArray());
            }

            // check all the elements from the bucket no splitPointer-1

            Heapfile rehashhf = new Heapfile("unclusteredhash" + String.valueOf(splitPointer - 1));
            Scan rehashscan = new Scan(rehashhf);
            RID rehashrid = new RID();
            Tuple rehashtuple = new Tuple();

            while ((rehashtuple = rehashscan.getNext(rehashrid)) != null) {
                try {
                    rehashtuple.setHdr((short) num_cols3, attrs3, stringsize);
                } catch (Exception e) {
                    System.out.println(e);
                }
                //rehashtuple.print(attrs3);

                if (rehashtuple.getIntFld(1) % N > splitPointer) {
                    // keep in the same bucket
                } else {
                    // rehash to the new bucket added (delete from current bucket and rehash to new
                    // bucket)
                    hash = rehashtuple.getIntFld(1) % (2 * N);

                    // delete from the previous bucket
                    Scan sctoaddnew = new Scan(rehashhf);
                    Tuple tp = new Tuple();
                    RID rid22 = new RID();
                    while ((tp = sctoaddnew.getNext(rid22)) != null) {
                        try {
                            tp.setHdr((short) num_cols, attrs, stringsize);
                        } catch (Exception e) {
                            System.out.println(e);
                        }
                        if (TupleUtils.Equal(tp, rehashtuple, attrs3, attrs3.length)) {
                            directory.deleteRecord(rid22);
                        }
                    }
                    // add to the new bucket
                    Heapfile heapfiletoadd = null;
                    heapfiletoadd = new Heapfile("unclusteredhash" + String.valueOf(N + splitPointer));
                    heapfiletoadd.insertRecord(new Tuple(rehashtuple).returnTupleByteArray());
                }
            }
        }

        hash = temptuple.getIntFld(1) % N;

        // open the heapfile

        Heapfile unclusteredhash = null;
        unclusteredhash = new Heapfile("unclusteredhash" + hash);
        // System.out.println(unclusteredhash.getRecCnt());
        Scan scanch = new Scan(unclusteredhash);
        Tuple temptuplech = new Tuple();
        RID ridch = new RID();
        boolean foundtuple = false;
        // if it is already in the heapfile then get it else insert the key
        while ((temptuplech = scanch.getNext(ridch)) != null) {
            try {
                temptuplech.setHdr((short) num_cols, attrs, stringsize);
            } catch (Exception e) {
                System.out.println(e);
            }

            if (temptuplech.getIntFld(1) == temptuple.getIntFld(1)) {
                foundtuple = true;
                //temptuple.print(attrs3);
                //temptuplech.print(attrs);
                Page page = new Page();
                foundtuple = true;
                Heapfile lasthfn = null;
                String name = temptuplech.getStrFld(2);
                lasthfn = new Heapfile(name);

                // insert the new tuple in the datafile
                Heapfile datafilehf = new Heapfile("unclusteredhashindex");
                RID dfhfrid = datafilehf.insertRecord(new Tuple(temptuple).getTupleByteArray());

                Tuple tp_for_lastlevelhf_ = new Tuple();
                try {
                    tp_for_lastlevelhf_.setHdr((short) num_cols, attrs_lasthf, stringsize);
                } catch (Exception e) {
                    System.out.println(e);
                }
                tp_for_lastlevelhf_.setIntFld(1, dfhfrid.slotNo);
                tp_for_lastlevelhf_.setIntFld(2, dfhfrid.pageNo.pid);

                lasthfn.insertRecord(new Tuple(tp_for_lastlevelhf_).getTupleByteArray());
                Scan scan3 = new Scan(lasthfn);
                Tuple tuple3 = new Tuple();
                RID rid3 = new RID();

                // System.out.println(lasthfn.getRecCnt());
                // check the final heapfile
                while ((tuple3 = scan3.getNext(rid3)) != null) {
                    try {
                        tuple3.setHdr((short) num_cols3, attrs3, stringsize);
                    } catch (Exception e) {
                        System.out.println(e);
                    }
                    //tuple3.print(attrs3);
                }
            }
        }

        if (!foundtuple) {
            Tuple tempp = new Tuple();
            try {
                tempp.setHdr((short) num_cols, attrs, stringsize);
            } catch (Exception e) {
                System.out.println(e);
            }
            tempp.setIntFld(1, temptuple.getIntFld(1));
            String lasthfname = "unclusteredhash" + String.valueOf(hash) + "_" + String.valueOf(temptuple.getIntFld(1));
            tempp.setStrFld(2, lasthfname);
            // System.out.println("Inserting :" + tempp.getIntFld(1) +"-"
            // +tempp.getStrFld(2));
            //tempp.print(attrs);
            unclusteredhash.insertRecord(new Tuple(tempp).getTupleByteArray());

            // insert the new tuple in the datafile
            Heapfile datafilehf = new Heapfile("unclusteredhashindex");
            RID dfhfrid = datafilehf.insertRecord(new Tuple(temptuple).getTupleByteArray());

            Tuple tp_for_lastlevelhf = new Tuple();
            try {
                tp_for_lastlevelhf.setHdr((short) num_cols, attrs_lasthf, stringsize);
            } catch (Exception e) {
                System.out.println(e);
            }
            tp_for_lastlevelhf.setIntFld(1, dfhfrid.slotNo);
            tp_for_lastlevelhf.setIntFld(2, dfhfrid.pageNo.pid);

            // open the last level heapfile
            Heapfile lasthf = null; // heapfile that stores all the tuples
            lasthf = new Heapfile(
                    "unclusteredhash" + String.valueOf(hash) + "_" + String.valueOf(temptuple.getIntFld(1)));
            Tuple lasttuple = new Tuple();
            RID lastrid = new RID();

            lasthf.insertRecord(new Tuple(tp_for_lastlevelhf).getTupleByteArray());

            // check last hf
            Scan scanll = new Scan(lasthf);
            Tuple tuplell = new Tuple();
            RID ridll = new RID();

            // System.out.println(lasthf.getRecCnt());

            // check the final heapfile
            while ((tuplell = scanll.getNext(ridll)) != null) {
                try {
                    tuplell.setHdr((short) num_cols3, attrs3, stringsize);
                } catch (Exception e) {
                    System.out.println(e);
                }
                //tuplell.print(attrs3);
            }
        }
    }
}
