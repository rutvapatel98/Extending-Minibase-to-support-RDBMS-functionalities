package iterator;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Random;

import btree.*;
import bufmgr.HashEntryNotFoundException;
import bufmgr.InvalidFrameNumberException;
import bufmgr.PageUnpinnedException;
import bufmgr.ReplacerException;
import global.*;
import heap.FieldNumberOutOfBoundException;
import heap.FileAlreadyDeletedException;
import heap.HFBufMgrException;
import heap.HFDiskMgrException;
import heap.HFException;
import heap.Heapfile;
import heap.InvalidSlotNumberException;
import heap.InvalidTupleSizeException;
import heap.Scan;
import heap.SpaceNotAvailableException;
import heap.Tuple;
import index.IndexUtils;
import iterator.FileScan;
import iterator.FldSpec;
import iterator.RelSpec;
import iterator.Sort;
import iterator.SortException;
import iterator.TupleUtils;


public class BTreeFileClustered {

    private AttrType[] attrType_;
 
    //private ArrayList<Integer> max_al;

    //private HashMap<Integer, Integer> myMap;

  
    private int len_in1_;
    private int n_pages_;
    private int index_fld_;
    private int files_size_;
    private int present_heap_;
    private BTreeClusteredFile btf;
    private BTCFileScan bt_scan;
    private boolean initialization;
    private AttrType key_type_;
    private short[] t1_str_sizes_;
    private IndexFileScan get_next_scan_;
    private Scan get_next_heap_scan_;
    private RID get_next_Rid;

    private int get_next_count_;
    private boolean get_next_heap_;

    private KeyDataEntry get_next_btree_root_;
    private boolean get_next_initialization;
    
    // int[] data_1 = new int[1000];
    // int[] data_2 = new int [1000];

    public BTreeFileClustered(String filename, int indexField, int len_in1, AttrType[] in1, AttrType key_type,  short[] t1_str_sizes) {

        len_in1_ = len_in1;
        index_fld_ = indexField;
        attrType_ = in1;
        key_type_ = key_type;
        t1_str_sizes_ = t1_str_sizes;
        get_next_count_ = 0;
        get_next_scan_ = null;
        get_next_heap_scan_ = null;
        get_next_heap_ = true;
        get_next_btree_root_ = null;
        get_next_initialization = true;
        n_pages_= 20;

        RID             rid;
        
        Tuple t = new Tuple();
        try {
          t.setHdr((short) len_in1_, attrType_ , t1_str_sizes);
        }
        catch (Exception e) {
          
          e.printStackTrace();
        }
    
        int size = t.size();

        
        //n_pages_ = n_pages;
        files_size_ = GlobalConst.MINIBASE_PAGESIZE/size;
        files_size_ = 2;
        present_heap_ = 0;
        initialization = true;
        
        // max_al = new ArrayList<Integer>();
       
        // myMap = new HashMap<Integer, Integer>();
        int key_size = 0;

        try {
            Integer[] al = new Integer[t1_str_sizes.length];
            for(int i = 0; i < t1_str_sizes.length; i++)
            {
                al[i] = (int)t1_str_sizes[i];
            }
            if(key_type.attrType == 0)
            {
                key_size = Collections.max(Arrays.asList(al));
            }
        } catch (Exception e) {
            //TODO: handle exception
        }

        if(key_type.attrType == 1)
        {
            // for integers
            key_size = 4;
        }
        else if(key_type.attrType == 2)
        {
            // for real numbers
            key_size = 8;
        }
     

        try {
            btf = new BTreeClusteredFile("BTIndex", key_type.attrType, key_size, 1/*delete*/); 
        }
        catch (Exception e) {
            e.printStackTrace();
        }

        BulkLoad(filename);
        
    }

    public static void main(String argv[]){
        String nameRoot = "Task1";
        String dbpath = "/tmp/"+nameRoot+System.getProperty("user.name")+".minibase-db";
        SystemDefs sysdef = new SystemDefs(dbpath,10000,1000,"Clock");
        
        Heapfile temp_h = null;

        AttrType[] attrType;

        int[] data_1 = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11 };
        int[] data_2 = {11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1 };
        String[] data_3 = {"aa", "ab", "ac", "ad", "az", "za", "da", "yu", "uii", "ttt", "uot"};
        short[] str_sizes = {(short)5};

        attrType = new AttrType[2];
        attrType[0] = new AttrType(AttrType.attrString);
        attrType[1] = new AttrType(AttrType.attrInteger);
       
        try {
            temp_h = new Heapfile("unsorted_data");
        } catch (Exception e) {
            e.printStackTrace();
        }

        Tuple t = new Tuple();
        try {
          t.setHdr((short) 2, attrType, str_sizes);
        }
        catch (Exception e) {
          
          e.printStackTrace();
        }

        int size = t.size();

        t = new Tuple(size);
        try {
        t.setHdr((short) 2, attrType, str_sizes);
        }
        catch (Exception e) {
        
        e.printStackTrace();
        }

        Tuple t2 = new Tuple(size);
        try {
        t.setHdr((short) 2, attrType, str_sizes);
        }
        catch (Exception e) {
        
        e.printStackTrace();
        }

        for (int i=0; i<data_1.length; i++) {
            try {
                t.setStrFld(1, data_3[i]);
                t.setIntFld(2, data_2[i]);
            }
            catch (Exception e) {
               
                e.printStackTrace();
            }
            
            try {
                temp_h.insertRecord(t.getTupleByteArray());
                
                    //btf.new
            }
            catch (Exception e) {
                
                e.printStackTrace();
            }
        }
        System.out.println(temp_h);

        BTreeFileClustered ob = new BTreeFileClustered("unsorted_data", 1, 2, attrType, attrType[0], str_sizes);

        ob.PrintBTreeClustered();

        RID rid = new RID();
        t = ob.get_next(rid);
        
        while(t!= null)
        {
            t2 = ob.getRecord(rid);
            if(ob.key_type_.attrType == 0)
            {
                // for strings
                try {
                    System.out.println( t.getStrFld(1) + " " +  t.getStrFld(2));
                    System.out.println( t2.getStrFld(1) + " " +  t2.getStrFld(2));
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            else if(ob.key_type_.attrType == 1)
            {
                // for integers
                try {
                    System.out.println( t.getIntFld(1) + " " +  t.getIntFld(2));
                    System.out.println( t2.getIntFld(1) + " " +  t2.getIntFld(2));
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            else if(ob.key_type_.attrType == 2)
            {
                // for real numbers
                // TO do 
                // try {
                //     System.out.println( t.getIntFld(1) + " " +  t.getIntFld(2));
                // } catch (Exception e) {
                //     e.printStackTrace();
                // }
            }
            t = ob.get_next(rid);
        }

    

        // t = new Tuple();
        // try {
        //   t.setHdr((short) 2, attrType, str_sizes);
        // }
        // catch (Exception e) {
          
        //   e.printStackTrace();
        // }

        // size = t.size();

        // t = new Tuple(size);
        // try {
        // t.setHdr((short) 2, attrType, str_sizes);
        // }
        // catch (Exception e) {
        
        // e.printStackTrace();
        // }

        // try {
        //     t.setStrFld(1, data_3[10]);
        //     t.setIntFld(2, data_2[10]);
        // }
        // catch (Exception e) {
           
        //     e.printStackTrace();
        // }

        // ob.Delete(t);

        // ob.PrintBTreeClustered();

    }
    
    public void Insert(Tuple tuple_to_insert)
    {
        
        // determine which bucket to choose

        // if there are no buckets create the initial bucket
        Heapfile present_heap_file = null;
        int bucket_slot = 0;
        // old way
        //int value_of_interest = 0;

        // new case of hadling attr types
        int value_of_interest_int = 0;
        float value_of_interest_float = 0;
        String value_of_interest_string = "";
       
        
       
        // old way
        // try {
        //     value_of_interest = tuple_to_insert.getIntFld(index_fld_);
        // } catch (FieldNumberOutOfBoundException | IOException e) {
        //     // TODO Auto-generated catch block
        //     e.printStackTrace();
        // }
        
        // new case of hadling attr types
        try {
            if(key_type_.attrType == 0)
            {
                // for strings
                value_of_interest_string = tuple_to_insert.getStrFld(index_fld_);
            }
            else if(key_type_.attrType == 1)
            {
                // for integers
                value_of_interest_int = tuple_to_insert.getIntFld(index_fld_);
            }
            else if(key_type_.attrType == 2)
            {
                // for real numbers
                value_of_interest_float = tuple_to_insert.getFloFld(index_fld_);
            }
        } catch (FieldNumberOutOfBoundException | IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        

        if(initialization)
        {
            present_heap_file = CreateHeap(0);
            initialization = false;
           
        }
        else
        {
            
            // int in = 0;

            // for( in = 0; in < max_al.size(); in++ )
            // {
            //     if(value_of_interest < max_al.get(in))
            //     {
            //         break;
            //     }
            // }

            // if(in == max_al.size())
            // {
            //     bucket_slot =  myMap.get(max_al.get(in-1));
                
            //     present_heap_file = CreateHeap(bucket_slot);
            // }
            // else
            // {
            //     bucket_slot =  myMap.get(max_al.get(in));
            //     present_heap_file = CreateHeap(bucket_slot);
            // }

            bucket_slot = findSlot(tuple_to_insert);
            present_heap_file = CreateHeap(bucket_slot);
        }

        // insert all the elements into the present bucket

        int noRecords = 0;

        try {
            noRecords = present_heap_file.getRecCnt();
        } catch (Exception e) {
            e.printStackTrace();
        } 

        
        if (noRecords == files_size_)
        {

            Tuple t = new Tuple();
            try{
                t.setHdr((short) len_in1_, attrType_, t1_str_sizes_);
            }catch(Exception e){
                e.printStackTrace();
            }
            
            t = new Tuple(t.size());
            try{
                t.setHdr((short) len_in1_, attrType_, t1_str_sizes_);
            }catch(Exception e){
                e.printStackTrace();
            }

            t = getMaxElement(bucket_slot);

            //int old_max = 0;

            // new case of hadling attr types
            int old_max_int = 0;
            float old_max_float = 0;
            String old_max_string = "";

            // old way
            // try {
            //     old_max = t.getIntFld(index_fld_);
            // } catch (FieldNumberOutOfBoundException | IOException e1) {
            //     // TODO Auto-generated catch block
            //     e1.printStackTrace();
            // }

            // new case of hadling attr types
            try {
                if(key_type_.attrType == 0)
                {
                    // for strings
                    old_max_string = t.getStrFld(index_fld_);
                }
                else if(key_type_.attrType == 1)
                {
                    // for integers
                    old_max_int = t.getIntFld(index_fld_);
                }
                else if(key_type_.attrType == 2)
                {
                    // for real numbers
                    old_max_float = t.getFloFld(index_fld_);
                }
            } catch (FieldNumberOutOfBoundException | IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

            if(key_type_.attrType == 0)
            {
                // for strings
                if(value_of_interest_string.compareTo(old_max_string) >= 0)
                {
                    // open new heap file and insert this tuple
    
                    
                    Random rand = new Random();
                    int bucket_random = rand.nextInt();
    
                    Heapfile new_heapfile = CreateHeap(bucket_random);
                    try {
                        new_heapfile.insertRecord(tuple_to_insert.getTupleByteArray());
                    } catch (InvalidSlotNumberException | InvalidTupleSizeException | SpaceNotAvailableException | HFException
                            | HFBufMgrException | HFDiskMgrException | IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                   
                    RID rid = new RID();
                    rid.slotNo = bucket_random;
                    // add this new max
                    // myMap.put(value_of_interest, bucket_random);
                    try {
                        btf.insert(new StringKey(value_of_interest_string), rid);
                    } catch (KeyTooLongException | KeyNotMatchException | LeafInsertRecException | IndexInsertRecException
                            | ConstructPageException | UnpinPageException | PinPageException | NodeNotMatchException
                            | ConvertException | DeleteRecException | IndexSearchException | IteratorException
                            | LeafDeleteException | InsertException | IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                    // max_al.add(value_of_interest);
                    // Collections.sort(max_al);
    
                }
    
                else
    
                {
                    // insert this tuple in this heap file and move the max to the next heap file
    
                    // first delete the max element
                    deleteTuple(bucket_slot, t);
    
                    Tuple t2 = new Tuple();
                    try{
                        t2.setHdr((short) len_in1_, attrType_, t1_str_sizes_);
                    }catch(Exception e){
                        e.printStackTrace();
                    }
                    
                    t2 = new Tuple(t.size());
                    try{
                        t2.setHdr((short) len_in1_, attrType_, t1_str_sizes_);
                    }catch(Exception e){
                        e.printStackTrace();
                    }
    
                    try {
                        present_heap_file.insertRecord(tuple_to_insert.getTupleByteArray());
                    } catch (InvalidSlotNumberException | InvalidTupleSizeException | SpaceNotAvailableException | HFException
                            | HFBufMgrException | HFDiskMgrException | IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                
                    t2 = getMaxElement(bucket_slot);
    
                    String new_max = "";
                    try {
                        new_max = t2.getStrFld(index_fld_);
                    } catch (FieldNumberOutOfBoundException | IOException e1) {
                        // TODO Auto-generated catch block
                        e1.printStackTrace();
                    }
    
                    // remove the old max from btree
                    RID rid = new RID();
                    rid.slotNo = bucket_slot;
                    
                    try {
                        btf.Delete(new StringKey(old_max_string), rid);
                    } catch (DeleteFashionException | LeafRedistributeException | RedistributeException | InsertRecException
                            | KeyNotMatchException | UnpinPageException | IndexInsertRecException | FreePageException
                            | RecordNotFoundException | PinPageException | IndexFullDeleteException | LeafDeleteException
                            | IteratorException | ConstructPageException | DeleteRecException | IndexSearchException
                            | IOException e1) {
                        // TODO Auto-generated catch block
                        e1.printStackTrace();
                    }
                    // max_al.remove(Integer.valueOf(old_max));
                    // max_al.add(new_max);
                    // Collections.sort(max_al);
                    // myMap.remove(old_max);
                    // myMap.put(new_max, bucket_slot);
    
                    rid = new RID();
                    rid.slotNo = bucket_slot;
                    try {
                        btf.insert(new StringKey(new_max), rid);
                    } catch (KeyTooLongException | KeyNotMatchException | LeafInsertRecException | IndexInsertRecException
                            | ConstructPageException | UnpinPageException | PinPageException | NodeNotMatchException
                            | ConvertException | DeleteRecException | IndexSearchException | IteratorException
                            | LeafDeleteException | InsertException | IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                    // recurse
                    Insert(t);
                    return;
                }
    
    
                return;
            }

            else if(key_type_.attrType == 1)
            {
                // for integers
                if(value_of_interest_int >= old_max_int)
                {
                    // open new heap file and insert this tuple

                    
                    Random rand = new Random();
                    int bucket_random = rand.nextInt();

                    Heapfile new_heapfile = CreateHeap(bucket_random);
                    try {
                        new_heapfile.insertRecord(tuple_to_insert.getTupleByteArray());
                    } catch (InvalidSlotNumberException | InvalidTupleSizeException | SpaceNotAvailableException | HFException
                            | HFBufMgrException | HFDiskMgrException | IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                
                    RID rid = new RID();
                    rid.slotNo = bucket_random;
                    // add this new max
                    // myMap.put(value_of_interest, bucket_random);
                    try {
                        btf.insert(new IntegerKey(value_of_interest_int), rid);
                    } catch (KeyTooLongException | KeyNotMatchException | LeafInsertRecException | IndexInsertRecException
                            | ConstructPageException | UnpinPageException | PinPageException | NodeNotMatchException
                            | ConvertException | DeleteRecException | IndexSearchException | IteratorException
                            | LeafDeleteException | InsertException | IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                    // max_al.add(value_of_interest);
                    // Collections.sort(max_al);

                }

                else

                {
                    // insert this tuple in this heap file and move the max to the next heap file

                    // first delete the max element
                    deleteTuple(bucket_slot, t);

                    Tuple t2 = new Tuple();
                    try{
                        t2.setHdr((short) len_in1_, attrType_, null);
                    }catch(Exception e){
                        e.printStackTrace();
                    }
                    
                    t2 = new Tuple(t.size());
                    try{
                        t2.setHdr((short) len_in1_, attrType_, null);
                    }catch(Exception e){
                        e.printStackTrace();
                    }

                    try {
                        present_heap_file.insertRecord(tuple_to_insert.getTupleByteArray());
                    } catch (InvalidSlotNumberException | InvalidTupleSizeException | SpaceNotAvailableException | HFException
                            | HFBufMgrException | HFDiskMgrException | IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                
                    t2 = getMaxElement(bucket_slot);

                    int new_max = 0;
                    try {
                        new_max = t2.getIntFld(index_fld_);
                    } catch (FieldNumberOutOfBoundException | IOException e1) {
                        // TODO Auto-generated catch block
                        e1.printStackTrace();
                    }

                    // remove the old max from btree
                    RID rid = new RID();
                    rid.slotNo = bucket_slot;
                    
                    try {
                        btf.Delete(new IntegerKey(old_max_int), rid);
                    } catch (DeleteFashionException | LeafRedistributeException | RedistributeException | InsertRecException
                            | KeyNotMatchException | UnpinPageException | IndexInsertRecException | FreePageException
                            | RecordNotFoundException | PinPageException | IndexFullDeleteException | LeafDeleteException
                            | IteratorException | ConstructPageException | DeleteRecException | IndexSearchException
                            | IOException e1) {
                        // TODO Auto-generated catch block
                        e1.printStackTrace();
                    }
                    // max_al.remove(Integer.valueOf(old_max));
                    // max_al.add(new_max);
                    // Collections.sort(max_al);
                    // myMap.remove(old_max);
                    // myMap.put(new_max, bucket_slot);

                    rid = new RID();
                    rid.slotNo = bucket_slot;
                    try {
                        btf.insert(new IntegerKey(new_max), rid);
                    } catch (KeyTooLongException | KeyNotMatchException | LeafInsertRecException | IndexInsertRecException
                            | ConstructPageException | UnpinPageException | PinPageException | NodeNotMatchException
                            | ConvertException | DeleteRecException | IndexSearchException | IteratorException
                            | LeafDeleteException | InsertException | IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                    // recurse
                    Insert(t);
                    return;
                }


                return;
            }

            else if(key_type_.attrType == 2)
            {
                // for floats
                // To DO
            }
            
        }

        if(noRecords == 0)
        {
            try {
                present_heap_file.insertRecord(tuple_to_insert.getTupleByteArray());
            } catch (InvalidSlotNumberException | InvalidTupleSizeException | SpaceNotAvailableException | HFException
                    | HFBufMgrException | HFDiskMgrException | IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

            // old way
            // int new_max = 0;
            // try {
            //     new_max = tuple_to_insert.getIntFld(index_fld_);
            // } catch (FieldNumberOutOfBoundException | IOException e1) {
            //     // TODO Auto-generated catch block
            //     e1.printStackTrace();
            // }

            // new case of hadling attr types
            int new_max_int = 0;
            float new_max_float = 0;
            String new_max_string = "";


            // new case of hadling attr types
            try {
                if(key_type_.attrType == 0)
                {
                    // for strings
                    new_max_string = tuple_to_insert.getStrFld(index_fld_);
                }
                else if(key_type_.attrType == 1)
                {
                    // for integers
                    new_max_int = tuple_to_insert.getIntFld(index_fld_);
                }
                else if(key_type_.attrType == 2)
                {
                    // for real numbers
                    new_max_float = tuple_to_insert.getFloFld(index_fld_);
                }
            } catch (FieldNumberOutOfBoundException | IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
    
            // update the key
            RID rid = new RID();
            rid.slotNo = bucket_slot;

            // old way
            // try {
            //     btf.insert(new IntegerKey(new_max), rid);
            // } catch (KeyTooLongException | KeyNotMatchException | LeafInsertRecException | IndexInsertRecException
            //         | ConstructPageException | UnpinPageException | PinPageException | NodeNotMatchException
            //         | ConvertException | DeleteRecException | IndexSearchException | IteratorException
            //         | LeafDeleteException | InsertException | IOException e) {
            //     // TODO Auto-generated catch block
            //     e.printStackTrace();
            // }

            if(key_type_.attrType == 0)
            {
                // for strings
                try {
                    btf.insert(new StringKey(new_max_string), rid);
                } catch (KeyTooLongException | KeyNotMatchException | LeafInsertRecException | IndexInsertRecException
                        | ConstructPageException | UnpinPageException | PinPageException | NodeNotMatchException
                        | ConvertException | DeleteRecException | IndexSearchException | IteratorException
                        | LeafDeleteException | InsertException | IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
            else if(key_type_.attrType == 1)
            {
                // for integers
                try {
                    btf.insert(new IntegerKey(new_max_int), rid);
                } catch (KeyTooLongException | KeyNotMatchException | LeafInsertRecException | IndexInsertRecException
                        | ConstructPageException | UnpinPageException | PinPageException | NodeNotMatchException
                        | ConvertException | DeleteRecException | IndexSearchException | IteratorException
                        | LeafDeleteException | InsertException | IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
            else if(key_type_.attrType == 2)
            {
                // for real numbers
                // To do
            }
            // myMap.put(new_max, bucket_slot);
            // max_al.add(new_max);
            // Collections.sort(max_al);

            return;
        }

        Tuple t = new Tuple();
        try{
            t.setHdr((short) len_in1_, attrType_, t1_str_sizes_);
        }catch(Exception e){
            e.printStackTrace();
        }
        
        t = new Tuple(t.size());
        try{
            t.setHdr((short) len_in1_, attrType_, t1_str_sizes_);
        }catch(Exception e){
            e.printStackTrace();
        }

        t = getMaxElement(bucket_slot);

        // old way
        // int old_max = 0;
        // try {
        //     old_max = t.getIntFld(index_fld_);
        // } catch (FieldNumberOutOfBoundException | IOException e1) {
        //     // TODO Auto-generated catch block
        //     e1.printStackTrace();
        // }

        // new case of hadling attr types
        int old_max_int = 0;
        float old_max_float = 0;
        String old_max_string = "";

        // new case of hadling attr types
        try {
            if(key_type_.attrType == 0)
            {
                // for strings
                old_max_string = t.getStrFld(index_fld_);
            }
            else if(key_type_.attrType == 1)
            {
                // for integers
                old_max_int = t.getIntFld(index_fld_);
            }
            else if(key_type_.attrType == 2)
            {
                // for real numbers
                old_max_float = t.getFloFld(index_fld_);
            }
        } catch (FieldNumberOutOfBoundException | IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        try {
            present_heap_file.insertRecord(tuple_to_insert.getTupleByteArray());
        } catch (InvalidSlotNumberException | InvalidTupleSizeException | SpaceNotAvailableException | HFException
                | HFBufMgrException | HFDiskMgrException | IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        try{
            t.setHdr((short) len_in1_, attrType_, t1_str_sizes_);
        }catch(Exception e){
            e.printStackTrace();
        }
        
        t = new Tuple(t.size());
        try{
            t.setHdr((short) len_in1_, attrType_, t1_str_sizes_);
        }catch(Exception e){
            e.printStackTrace();
        }

        t = getMaxElement(bucket_slot);

        // old way
        // int new_max = 0;
        // try {
        //     new_max = t.getIntFld(index_fld_);
        // } catch (FieldNumberOutOfBoundException | IOException e1) {
        //     // TODO Auto-generated catch block
        //     e1.printStackTrace();
        // }

        // new case of hadling attr types
        int new_max_int = 0;
        float new_max_float = 0;
        String new_max_string = "";

        try {
            if(key_type_.attrType == 0)
            {
                // for strings
                new_max_string = t.getStrFld(index_fld_);
            }
            else if(key_type_.attrType == 1)
            {
                // for integers
                new_max_int = t.getIntFld(index_fld_);
            }
            else if(key_type_.attrType == 2)
            {
                // for real numbers
                new_max_float = t.getFloFld(index_fld_);
            }
        } catch (FieldNumberOutOfBoundException | IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        if(key_type_.attrType == 0)
        {
            // for strings
            if(new_max_string.compareTo(old_max_string) > 0)
            {
                RID rid = new RID();
                rid.slotNo = bucket_slot;
                
                try {
                    btf.Delete(new StringKey(old_max_string), rid);
                } catch (DeleteFashionException | LeafRedistributeException | RedistributeException | InsertRecException
                        | KeyNotMatchException | UnpinPageException | IndexInsertRecException | FreePageException
                        | RecordNotFoundException | PinPageException | IndexFullDeleteException | LeafDeleteException
                        | IteratorException | ConstructPageException | DeleteRecException | IndexSearchException
                        | IOException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
    
                // myMap.remove(old_max);
    
                // update the key
                rid = new RID();
                rid.slotNo = bucket_slot;
                try {
                    btf.insert(new StringKey(new_max_string), rid);
                } catch (KeyTooLongException | KeyNotMatchException | LeafInsertRecException | IndexInsertRecException
                         | ConstructPageException | UnpinPageException | PinPageException | NodeNotMatchException
                         | ConvertException | DeleteRecException | IndexSearchException | IteratorException
                         | LeafDeleteException | InsertException | IOException e) {
                     // TODO Auto-generated catch block
                     e.printStackTrace();
                }
    
                // update the key
                // myMap.put(new_max, bucket_slot);
    
                // max_al.remove(Integer.valueOf(old_max));
    
                // max_al.add(new_max);
                // Collections.sort(max_al);
    
            }
        }
        else if(key_type_.attrType == 1)
        {
            // for integers
            if(new_max_int > old_max_int)
            {
                RID rid = new RID();
                rid.slotNo = bucket_slot;
                
                try {
                    btf.Delete(new IntegerKey(old_max_int), rid);
                } catch (DeleteFashionException | LeafRedistributeException | RedistributeException | InsertRecException
                        | KeyNotMatchException | UnpinPageException | IndexInsertRecException | FreePageException
                        | RecordNotFoundException | PinPageException | IndexFullDeleteException | LeafDeleteException
                        | IteratorException | ConstructPageException | DeleteRecException | IndexSearchException
                        | IOException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
    
                // myMap.remove(old_max);
    
                // update the key
                rid = new RID();
                rid.slotNo = bucket_slot;
                try {
                    btf.insert(new IntegerKey(new_max_int), rid);
                } catch (KeyTooLongException | KeyNotMatchException | LeafInsertRecException | IndexInsertRecException
                         | ConstructPageException | UnpinPageException | PinPageException | NodeNotMatchException
                         | ConvertException | DeleteRecException | IndexSearchException | IteratorException
                         | LeafDeleteException | InsertException | IOException e) {
                     // TODO Auto-generated catch block
                     e.printStackTrace();
                }
    
                // update the key
                // myMap.put(new_max, bucket_slot);
    
                // max_al.remove(Integer.valueOf(old_max));
    
                // max_al.add(new_max);
                // Collections.sort(max_al);
    
            }
            
        }
        else if(key_type_.attrType == 2)
        {
            // for real numbers
            // To do 
        }

        

        


    }

    public void Delete(Tuple tuple_to_delete)
    {
        ArrayList<Integer> slot_nos = findTuple(tuple_to_delete);

        // old way
        // int value_of_interest = 0;
    
        // try {
        //     value_of_interest = tuple_to_delete.getIntFld(index_fld_);
        // } catch (FieldNumberOutOfBoundException | IOException e) {
        //     // TODO Auto-generated catch block
        //     e.printStackTrace();
        // }

        // new case of hadling attr types
        int value_of_interest_int = 0;
        float value_of_interest_float = 0;
        String value_of_interest_string = "";
        
        try {
            if(key_type_.attrType == 0)
            {
                // for strings
                value_of_interest_string = tuple_to_delete.getStrFld(index_fld_);
            }
            else if(key_type_.attrType == 1)
            {
                // for integers
                value_of_interest_int = tuple_to_delete.getIntFld(index_fld_);
            }
            else if(key_type_.attrType == 2)
            {
                // for real numbers
                value_of_interest_float = tuple_to_delete.getFloFld(index_fld_);
            }
        } catch (FieldNumberOutOfBoundException | IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        Tuple t = new Tuple();
        try{
            t.setHdr((short) len_in1_, attrType_, t1_str_sizes_);
        }catch(Exception e){
            e.printStackTrace();
        }
        
        t = new Tuple(t.size());
        try{
            t.setHdr((short) len_in1_, attrType_, t1_str_sizes_);
        }catch(Exception e){
            e.printStackTrace();
        }

        int slot_no;
        try {
            slot_no = deleteTuple(slot_nos, tuple_to_delete);
        } catch (Exception e3) {
            // TODO Auto-generated catch block
           return;
        }

        t = getMaxElement(slot_no);
        
        if(t == null) t= tuple_to_delete;

        
        // old way
        // int old_max = 0;
        // try {
        //     old_max = t.getIntFld(index_fld_);
        // } catch (FieldNumberOutOfBoundException | IOException e1) {
        //     // TODO Auto-generated catch block
        //     e1.printStackTrace();
        // }

        
        // new case of hadling attr types
        int old_max_int = 0;
        float old_max_float = 0;
        String old_max_string = "";

        try {
            if(key_type_.attrType == 0)
            {
                // for strings
                old_max_string = t.getStrFld(index_fld_);
            }
            else if(key_type_.attrType == 1)
            {
                // for integers
                old_max_int = t.getIntFld(index_fld_);
            }
            else if(key_type_.attrType == 2)
            {
                // for real numbers
                old_max_float = t.getFloFld(index_fld_);
            }
        } catch (FieldNumberOutOfBoundException | IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        if(key_type_.attrType == 0)
        {
            // for strings
            if(value_of_interest_string.compareTo(old_max_string) > 0) old_max_string = value_of_interest_string;
        }
        else if(key_type_.attrType == 1)
        {
            // for integers
            if(value_of_interest_int>old_max_int) old_max_int = value_of_interest_int;
        }
        else if(key_type_.attrType == 2)
        {
            // for real numbers
            // To do
            
        }
        

        Heapfile temp_h = null;
        try {
            temp_h = new Heapfile("BTC" + String.valueOf(slot_no));
        } catch (Exception e) {
            e.printStackTrace();
        }

        RID rid = new RID();

        rid.slotNo = slot_no;
        try {
            if(temp_h.getRecCnt() == 0)
            {
                // max_al.remove(Integer.valueOf(old_max));
                // Collections.sort(max_al);
                // myMap.remove(old_max);
               try {
                temp_h.deleteFile();
                } catch (FileAlreadyDeletedException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }

        

                try {

                   
                    if(key_type_.attrType == 0)
                    {
                        // for strings
                        btf.Delete(new StringKey(old_max_string), rid);
                    }
                    else if(key_type_.attrType == 1)
                    {
                        // for integers
                        btf.Delete(new IntegerKey(old_max_int), rid);
                    }
                    else if(key_type_.attrType == 2)
                    {
                        // for real numbers
                        // To do
                        
                    }
                } catch (DeleteFashionException | LeafRedistributeException | RedistributeException | InsertRecException
                        | KeyNotMatchException | UnpinPageException | IndexInsertRecException | FreePageException
                        | RecordNotFoundException | PinPageException | IndexFullDeleteException | LeafDeleteException
                        | IteratorException | ConstructPageException | DeleteRecException | IndexSearchException
                        | IOException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }

                return;
            }
        } catch (InvalidSlotNumberException | InvalidTupleSizeException | HFDiskMgrException | HFBufMgrException
                | IOException e2) {
            // TODO Auto-generated catch block
            e2.printStackTrace();
        }


        t = new Tuple(t.size());
        try{
            t.setHdr((short) len_in1_, attrType_, t1_str_sizes_);
        }catch(Exception e){
            e.printStackTrace();
        }

        t = getMaxElement(slot_no);
      
        // old way
        // int new_max = 0;

        // try {
        //     new_max = t.getIntFld(index_fld_);
        // } catch (FieldNumberOutOfBoundException | IOException e1) {
        //     e1.printStackTrace();
        // }

        // new case of hadling attr types
        int new_max_int = 0;
        float new_max_float = 0;
        String new_max_string = "";

        try {
            if(key_type_.attrType == 0)
            {
                // for strings
                new_max_string = t.getStrFld(index_fld_);
            }
            else if(key_type_.attrType == 1)
            {
                // for integers
                new_max_int = t.getIntFld(index_fld_);
            }
            else if(key_type_.attrType == 2)
            {
                // for real numbers
                new_max_float = t.getFloFld(index_fld_);
            }
        } catch (FieldNumberOutOfBoundException | IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        

        if(key_type_.attrType == 0)
        {
            // for strings
            if(new_max_string.compareTo(old_max_string) != 0)
            {
                // max_al.remove(Integer.valueOf(old_max));
                // max_al.add(Integer.valueOf(new_max));
                // Collections.sort(max_al);
                // myMap.remove(old_max);
                // myMap.put(new_max, slot_no);
    
                try {
                    btf.Delete(new StringKey(old_max_string), rid);
                } catch (DeleteFashionException | LeafRedistributeException | RedistributeException | InsertRecException
                        | KeyNotMatchException | UnpinPageException | IndexInsertRecException | FreePageException
                        | RecordNotFoundException | PinPageException | IndexFullDeleteException | LeafDeleteException
                        | IteratorException | ConstructPageException | DeleteRecException | IndexSearchException
                        | IOException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
                try {
                    btf.insert(new StringKey(new_max_string), rid);
                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        }

        else if(key_type_.attrType == 1)
        {
            // for integers
            if(new_max_int != old_max_int)
            {
                // max_al.remove(Integer.valueOf(old_max));
                // max_al.add(Integer.valueOf(new_max));
                // Collections.sort(max_al);
                // myMap.remove(old_max);
                // myMap.put(new_max, slot_no);
    
                try {
                    btf.Delete(new IntegerKey(old_max_int), rid);
                } catch (DeleteFashionException | LeafRedistributeException | RedistributeException | InsertRecException
                        | KeyNotMatchException | UnpinPageException | IndexInsertRecException | FreePageException
                        | RecordNotFoundException | PinPageException | IndexFullDeleteException | LeafDeleteException
                        | IteratorException | ConstructPageException | DeleteRecException | IndexSearchException
                        | IOException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
                try {
                    btf.insert(new IntegerKey(new_max_int), rid);
                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        }
        else if(key_type_.attrType == 2)
        {
            // for real numbers
            // To do 
        }

    }

    public ArrayList<Integer> findTuple(Tuple tuple_to_find)
    {
        ArrayList<Integer> bucket_slots = new ArrayList<Integer>();

        // old way
        // int value_of_interest = 0;

        // try {
        //     value_of_interest = tuple_to_find.getIntFld(index_fld_);
        // } catch (FieldNumberOutOfBoundException | IOException e) {
        //     // TODO Auto-generated catch block
        //     e.printStackTrace();
        // }

        // new case of hadling attr types
        int value_of_interest_int = 0;
        float value_of_interest_float = 0;
        String value_of_interest_string = "";
       
        try {
            if(key_type_.attrType == 0)
            {
                // for strings
                value_of_interest_string = tuple_to_find.getStrFld(index_fld_);
            }
            else if(key_type_.attrType == 1)
            {
                // for integers
                value_of_interest_int = tuple_to_find.getIntFld(index_fld_);
            }
            else if(key_type_.attrType == 2)
            {
                // for real numbers
                value_of_interest_float = tuple_to_find.getFloFld(index_fld_);
            }
        } catch (FieldNumberOutOfBoundException | IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }


        int high_key = Integer.MAX_VALUE;

        int high_key_int = Integer.MAX_VALUE;
        float high_key_float = Float.MAX_VALUE;
        String high_key_string = "zzzzzzzzzzzzzzzz";


        
        
        bt_scan = null;

        if(key_type_.attrType == 0)
        {
            // for strings
            try {
                bt_scan = btf.new_scan( new StringKey(value_of_interest_string),  new StringKey(high_key_string));
            } catch (KeyNotMatchException | IteratorException | ConstructPageException | PinPageException
                    | UnpinPageException | IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        else if(key_type_.attrType == 1)
        {
            // for integers
            try {
                bt_scan = btf.new_scan( new IntegerKey(value_of_interest_int),  new IntegerKey(high_key_int));
            } catch (KeyNotMatchException | IteratorException | ConstructPageException | PinPageException
                    | UnpinPageException | IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        else if(key_type_.attrType == 2)
        {
            // for real numbers
            // To do
        }


        KeyDataEntry entry = null;

        DataClass data;
        
        LeafData leaf_data;
        RID present_rid;
        int slot_no;

        try {
            entry=bt_scan.get_next();
        } catch (ScanIteratorException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
      

        while(entry != null)
        {
            data = entry.data;
           
            leaf_data = (LeafData)data;
            present_rid = leaf_data.getData();

            slot_no = present_rid.slotNo;
            bucket_slots.add(slot_no);

            if(key_type_.attrType == 0)
            {
                // for strings
                StringKey key;
                key = (StringKey)entry.key;
                if(key.getKey() != value_of_interest_string)
                {
                    break;
                }
                
            }

            else if(key_type_.attrType == 1)
            {
                // for integers
                IntegerKey key;
                key = (IntegerKey)entry.key;
                if(key.getKey() != value_of_interest_int)
                {
                    break;
                }
            }

            else if(key_type_.attrType == 2)
            {
                // for real numbers
                // To do
            }

           
            try {
                entry=bt_scan.get_next();
            } catch (ScanIteratorException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }

        return bucket_slots;
    }

    public int findSlot(Tuple tuple_to_insert)
    {
        // old way
        // int value_of_interest = 0;
        
        // try {
        //     value_of_interest = tuple_to_insert.getIntFld(index_fld_);
        // } catch (FieldNumberOutOfBoundException | IOException e) {
        //     // TODO Auto-generated catch block
        //     e.printStackTrace();
        // }


        // new case of hadling attr types
        int value_of_interest_int = 0;
        float value_of_interest_float = 0;
        String value_of_interest_string = "";
        
        // new case of hadling attr types
        try {
            if(key_type_.attrType == 0)
            {
                // for strings
                value_of_interest_string = tuple_to_insert.getStrFld(index_fld_);
            }
            else if(key_type_.attrType == 1)
            {
                // for integers
                value_of_interest_int = tuple_to_insert.getIntFld(index_fld_);
            }
            else if(key_type_.attrType == 2)
            {
                // for real numbers
                value_of_interest_float = tuple_to_insert.getFloFld(index_fld_);
            }
        } catch (FieldNumberOutOfBoundException | IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        bt_scan = null;

        // old way
        //int high_key = Integer.MAX_VALUE;

        int high_key_int = Integer.MAX_VALUE;
        float high_key_float = Float.MAX_VALUE;
        String high_key_string = "zzzzzzzzzzzzzzzz";


        if(key_type_.attrType == 0)
        {
            // for strings
            try {
                bt_scan = btf.new_scan( new StringKey(value_of_interest_string),  new StringKey(high_key_string));
            } catch (KeyNotMatchException | IteratorException | ConstructPageException | PinPageException
                    | UnpinPageException | IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        else if(key_type_.attrType == 1)
        {
            // for integers
            try {
                bt_scan = btf.new_scan( new IntegerKey(value_of_interest_int),  new IntegerKey(high_key_int));
            } catch (KeyNotMatchException | IteratorException | ConstructPageException | PinPageException
                    | UnpinPageException | IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        else if(key_type_.attrType == 2)
        {
            // for real numbers
            // To do
        }

       

        KeyDataEntry entry = null;

        DataClass data;
        
        LeafData leaf_data;
        RID present_rid;
        int slot_no = 0;

        try {
            entry=bt_scan.get_next();
        } catch (ScanIteratorException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        if(entry == null){

            try {
                bt_scan.DestroyBTreeFileScan();
            } catch (InvalidFrameNumberException | ReplacerException | PageUnpinnedException
                    | HashEntryNotFoundException | IOException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }

            bt_scan = null;

            // old way
            // try {
            //     bt_scan = btf.new_scan( new IntegerKey(-2),  new IntegerKey(Integer.MAX_VALUE));
            // } catch (KeyNotMatchException | IteratorException | ConstructPageException | PinPageException
            //         | UnpinPageException | IOException e) {
            //     // TODO Auto-generated catch block
            //     e.printStackTrace();
            // }

            if(key_type_.attrType == 0)
            {
                // for strings
                try {
                    bt_scan = btf.new_scan( new StringKey(""),  new StringKey(high_key_string));
                } catch (KeyNotMatchException | IteratorException | ConstructPageException | PinPageException
                        | UnpinPageException | IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }

            else if(key_type_.attrType == 1)
            {
                // for integers
                try {
                    bt_scan = btf.new_scan( new IntegerKey(-2),  new IntegerKey(high_key_int));
                } catch (KeyNotMatchException | IteratorException | ConstructPageException | PinPageException
                        | UnpinPageException | IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }

            else if(key_type_.attrType == 2)
            {
                // for real numbers
                // To do
            }

            
            try {
                entry=bt_scan.get_next();
            } catch (ScanIteratorException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

            if(entry == null) 
            {
                try {
                    bt_scan.DestroyBTreeFileScan();
                } catch (InvalidFrameNumberException | ReplacerException | PageUnpinnedException
                        | HashEntryNotFoundException | IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                return 0;
            }

            while(entry != null)
            {
                data = entry.data;
    
                leaf_data = (LeafData)data;
                present_rid = leaf_data.getData();

                slot_no = present_rid.slotNo;
                
                try {
                    entry=bt_scan.get_next();
                } catch (ScanIteratorException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }

                if(entry == null)
                {
                    try {
                        bt_scan.DestroyBTreeFileScan();
                    } catch (InvalidFrameNumberException | ReplacerException | PageUnpinnedException
                            | HashEntryNotFoundException | IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }

                    return slot_no;
                }
            }

        }

        while(entry != null)
        {
            data = entry.data;
            

            leaf_data = (LeafData)data;
            present_rid = leaf_data.getData();

            slot_no = present_rid.slotNo;
           
            // old way
            // key = (IntegerKey)entry.key;

            if(key_type_.attrType == 0)
            {
                // for strings
                StringKey key;
                key = (StringKey)entry.key;
                if(key.getKey() != value_of_interest_string)
                {
                    break;
                }
                
            }

            else if(key_type_.attrType == 1)
            {
                // for integers
                IntegerKey key;
                key = (IntegerKey)entry.key;
                if(key.getKey() != value_of_interest_int)
                {
                    break;
                }
            }

            else if(key_type_.attrType == 2)
            {
                // for real numbers
                // To do
            }
            
            try {
                entry=bt_scan.get_next();
            } catch (ScanIteratorException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }

        try {
            bt_scan.DestroyBTreeFileScan();
        } catch (InvalidFrameNumberException | ReplacerException | PageUnpinnedException
                | HashEntryNotFoundException | IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return slot_no;
    }
    // create heap file
    public Heapfile CreateHeap(int i)
    {
        Heapfile temp_h = null;
       
        try {
            temp_h = new Heapfile("BTC" + String.valueOf(i));
        } catch (Exception e) {
            e.printStackTrace();
        }

        System.out.println(temp_h);

        // try {
        //     if(temp_h.getRecCnt() == 0)
        //     {
        //         al.add(temp_h);
        //     }
        // } catch (InvalidSlotNumberException | InvalidTupleSizeException | HFDiskMgrException | HFBufMgrException
        //         | IOException e) {
        //     // TODO Auto-generated catch block
        //     e.printStackTrace();
        // }
        

        return temp_h;
    }

    public void printHeap(int i)
    {
        Heapfile temp_h = null;
     
        try {
            temp_h = new Heapfile("BTC" + String.valueOf(i));
        } catch (Exception e) {
            e.printStackTrace();
        }
      
        Scan s = null;
        try {
            s = new Scan(temp_h);
        } catch (Exception e1) {
            e1.printStackTrace();
        }
        Tuple t = new Tuple();
        try{
            t.setHdr((short) len_in1_, attrType_, t1_str_sizes_);
        }catch(Exception e){
            e.printStackTrace();
        }
        
        t = new Tuple(t.size());
        try{
            t.setHdr((short) len_in1_, attrType_, t1_str_sizes_);
        }catch(Exception e){
            e.printStackTrace();
        }

        RID rid = new RID();
        try {
            for(int ii = 0 ; ii < temp_h.getRecCnt(); ii++)
            {
                try {
                    t = s.getNext(rid);
                } catch (Exception e) {
                    e.printStackTrace();
                }
    
                try{
                    t.setHdr((short) len_in1_, attrType_, t1_str_sizes_);
                }catch(Exception e){
                    e.printStackTrace();
                }

                if(key_type_.attrType == 0)
                {
                    // for strings
                    try {
                        System.out.println( t.getStrFld(1) + " " +  t.getStrFld(2));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                else if(key_type_.attrType == 1)
                {
                    // for integers
                    try {
                        System.out.println( t.getIntFld(1) + " " +  t.getIntFld(2));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                else if(key_type_.attrType == 2)
                {
                    // for real numbers
                    // TO do 
                    // try {
                    //     System.out.println( t.getIntFld(1) + " " +  t.getIntFld(2));
                    // } catch (Exception e) {
                    //     e.printStackTrace();
                    // }
                }
                
            }
        } catch (InvalidSlotNumberException | InvalidTupleSizeException | HFDiskMgrException | HFBufMgrException
                | IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        

        s.closescan();

        
    }

    // get the max element
    public Tuple getMaxElement(int i)
    {
        // create an iterator by open a file scan
        FldSpec[] projlist = new FldSpec[len_in1_];
        RelSpec rel = new RelSpec(RelSpec.outer); 
        for(int j=0; j<len_in1_; j++){
            projlist[j] = new FldSpec(rel, j+1);
        }
        
        FileScan fscan = null;
        
        try {

            fscan = new FileScan("BTC" + String.valueOf(i), attrType_, t1_str_sizes_, (short) len_in1_, len_in1_, projlist, null);

        }
        catch (Exception e) {
            e.printStackTrace();
        }

        TupleOrder[] order = new TupleOrder[2];
        order[0] = new TupleOrder(TupleOrder.Ascending);
        order[1] = new TupleOrder(TupleOrder.Descending);


        Sort sort = null;
        try {
            sort = new Sort(attrType_, (short)len_in1_, t1_str_sizes_, fscan, index_fld_, order[1], 1, n_pages_);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        
        Tuple t = new Tuple();
        try{
            t.setHdr((short) len_in1_, attrType_, t1_str_sizes_);
        }catch(Exception e){
            e.printStackTrace();
        }
        
        t = new Tuple(t.size());
        try{
            t.setHdr((short) len_in1_, attrType_, t1_str_sizes_);
        }catch(Exception e){
            e.printStackTrace();
        }

        try {
            t = sort.get_next();
        }
        catch (Exception e) {
            e.printStackTrace(); 
        }

        try {
            sort.close();
        } catch (SortException | IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        return t;
    }

    // sort the bucket 
    public void SortBucket(int i )
    {
         //sorted heapfile
         Heapfile sf = null;
         try{
             sf = new Heapfile("BTCsorted"+String.valueOf(i));
         }catch(Exception e){
             e.printStackTrace();
         }
         
        // create an iterator by open a file scan
        FldSpec[] projlist = new FldSpec[len_in1_];
        RelSpec rel = new RelSpec(RelSpec.outer); 
        for(int j=0; j<len_in1_; j++){
            projlist[j] = new FldSpec(rel, j+1);
        }
        
        FileScan fscan = null;
        
        try {
            fscan = new FileScan("BTC" + String.valueOf(i), attrType_, null, (short) len_in1_, len_in1_, projlist, null);
        }
        catch (Exception e) {
            e.printStackTrace();
        }

        TupleOrder[] order = new TupleOrder[2];
        order[0] = new TupleOrder(TupleOrder.Ascending);
        order[1] = new TupleOrder(TupleOrder.Descending);


        Sort sort = null;
        try {
            sort = new Sort(attrType_, (short)len_in1_, null, fscan, index_fld_, order[1], 1, n_pages_);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        
        Tuple t = new Tuple();
        try{
            t.setHdr((short) len_in1_, attrType_, null);
        }catch(Exception e){
            e.printStackTrace();
        }
        
        t = new Tuple(t.size());
        try{
            t.setHdr((short) len_in1_, attrType_, null);
        }catch(Exception e){
            e.printStackTrace();
        }
        try {
            t = sort.get_next();
            sf.insertRecord(t.returnTupleByteArray());
        }
        catch (Exception e) {
            e.printStackTrace(); 
        }
        
        while (t != null) {
            try {
                t = sort.get_next();
                sf.insertRecord(t.returnTupleByteArray());
            }
            catch (Exception e){
                if(t == null){
                    // clean up
                    try {
                        sort.close();
                    }
                    catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
            }
        }
    }

    // delete tuple element of the bucket
    public int deleteTuple(ArrayList<Integer> bucket_slots, Tuple max_t) throws Exception
    {
        int i;
        int bucket_slot = 0;
        boolean tuple_found = false;


        for(int j = 0; j < bucket_slots.size(); j++ )
        {
            i = bucket_slots.get(j);
            boolean break_now = false;
            Heapfile temp_h = null;
            try {
                temp_h = new Heapfile("BTC" + String.valueOf(i));
            } catch (Exception e) {
                e.printStackTrace();
            }

            try {
                System.out.println(temp_h.getRecCnt());
            } catch (InvalidSlotNumberException | InvalidTupleSizeException | HFDiskMgrException | HFBufMgrException
                    | IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

            Scan s = null;
            try {
                s = new Scan(temp_h);
            } catch (Exception e1) {
                e1.printStackTrace();
            }

            Tuple t = new Tuple();
            try{
                t.setHdr((short) len_in1_, attrType_, t1_str_sizes_);
            }catch(Exception e){
                e.printStackTrace();
            }
            
            t = new Tuple(t.size());
            try{
                t.setHdr((short) len_in1_, attrType_, t1_str_sizes_);
            }catch(Exception e){
                e.printStackTrace();
            }
            RID rid = new RID();

            try {
                t = s.getNext(rid);
            }
            catch (Exception e) {
                e.printStackTrace(); 
            }

            while (t != null) {

                try{
                    t.setHdr((short) len_in1_, attrType_, t1_str_sizes_);
                }catch(Exception e){
                    e.printStackTrace();
                }

                try {

                    if(TupleUtils.Equal(t, max_t, attrType_, len_in1_))
                    {
                        bucket_slot = i;
                        tuple_found = true;
                        break;

                    }
                    t = s.getNext(rid);
                }
                catch (Exception e){
                    e.printStackTrace();
                }
                
                if(t == null){
                    // clean up
                    try {
                        s.closescan();
                        break_now = true;
                    }
                    catch (Exception e){
                        e.printStackTrace();
                    }
                }
                
                
            }
            if(break_now) continue;

            try {
                System.out.println("deleting: " + temp_h.deleteRecord(rid));
            } catch (Exception e) {
                
                e.printStackTrace();
            }

            try {
                System.out.println(temp_h.getRecCnt());
            } catch (InvalidSlotNumberException | InvalidTupleSizeException | HFDiskMgrException | HFBufMgrException
                    | IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

            try {
                if(temp_h.getRecCnt() == 0)
                {
                    break;
                }
            } catch (InvalidSlotNumberException | InvalidTupleSizeException | HFDiskMgrException | HFBufMgrException
                    | IOException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
            try {
                s.closescan();
                break;
            }
            catch (Exception e){
                e.printStackTrace();
            }

        }

        if(!tuple_found) throw new Exception("tuple not found");

        return bucket_slot;
    }

    public void deleteTuple(Integer i, Tuple max_t) 
    {
        Heapfile temp_h = null;
        try {
            temp_h = new Heapfile("BTC" + String.valueOf(i));
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            System.out.println(temp_h.getRecCnt());
        } catch (InvalidSlotNumberException | InvalidTupleSizeException | HFDiskMgrException | HFBufMgrException
                | IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        Scan s = null;
        try {
            s = new Scan(temp_h);
        } catch (Exception e1) {
            e1.printStackTrace();
        }

        Tuple t = new Tuple();
        try{
            t.setHdr((short) len_in1_, attrType_, t1_str_sizes_);
        }catch(Exception e){
            e.printStackTrace();
        }
        
        t = new Tuple(t.size());
        try{
            t.setHdr((short) len_in1_, attrType_, t1_str_sizes_);
        }catch(Exception e){
            e.printStackTrace();
        }
        RID rid = new RID();

        try {
            t = s.getNext(rid);
        }
        catch (Exception e) {
            e.printStackTrace(); 
        }

        while (t != null) {

            try{
                t.setHdr((short) len_in1_, attrType_, t1_str_sizes_);
            }catch(Exception e){
                e.printStackTrace();
            }

            try {

                //if(TupleUtils.CompareTupleWithTuple(attrType_[index_fld_-1], t, index_fld_, max_t,index_fld_ ) == 0)
                if(TupleUtils.Equal(t, max_t, attrType_, len_in1_))
                {
                    break;
                }
                t = s.getNext(rid);
            }
            catch (Exception e){
                e.printStackTrace();
            }
            
            if(t == null){
                // clean up
                try {
                    s.closescan();
                    return;
                }
                catch (Exception e){
                    e.printStackTrace();
                }
            }
            
            
        }

        try {
            System.out.println("deleting: " + temp_h.deleteRecord(rid));
        } catch (Exception e) {
            
            e.printStackTrace();
        }

        try {
            System.out.println(temp_h.getRecCnt());
        } catch (InvalidSlotNumberException | InvalidTupleSizeException | HFDiskMgrException | HFBufMgrException
                | IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        try {
            if(temp_h.getRecCnt() == 0)
            {
                return;
            }
        } catch (InvalidSlotNumberException | InvalidTupleSizeException | HFDiskMgrException | HFBufMgrException
                | IOException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }
        try {
            s.closescan();
            return;
        }
        catch (Exception e){
            e.printStackTrace();
        }

    }

    public void PrintBTreeClustered()
    {
        IndexFileScan indScan =  null;
        System.out.println("##### printing clustered ######");
        try {
            indScan = (BTCFileScan) IndexUtils.BTreeClustered_scan(null, btf);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        KeyDataEntry temp2 = null;

        try {
            temp2 = indScan.get_next();
        } catch (Exception e) {
            e.printStackTrace();
        }

       
        DataClass data;
        LeafData leaf_data ;
        RID present_rid;
        int slot_no;
        

        while (temp2 != null)
        {
            data = temp2.data;
            leaf_data = (LeafData)data;
            present_rid = leaf_data.getData();
            System.out.println(present_rid.slotNo);
            slot_no = present_rid.slotNo;
            printHeap(slot_no);
            System.out.println("********");
            try {
                temp2 = indScan.get_next();
            } catch (Exception e) {
                e.printStackTrace();
            }
            
        }
        System.out.println("------ Done printing -------");
    }

    public void Delete_multiple(Tuple tuple_to_delete)
    {
        while(true)
        {
            try{
                Delete(tuple_to_delete);
            }
            catch(Exception e)
            {
                break;
            }
            
        }
        
    }

    public void BulkLoad(String heapfile_name)
    {
         //sorted heapfile
        // Heapfile sf = null;
        // try{
        //     sf = new Heapfile("BulkLoadsorted");
        // }catch(Exception e){
        //     e.printStackTrace();
        // }
         
        // create an iterator by open a file scan
        FldSpec[] projlist = new FldSpec[len_in1_];
        RelSpec rel = new RelSpec(RelSpec.outer); 
        for(int j=0; j<len_in1_; j++){
            projlist[j] = new FldSpec(rel, j+1);
        }
        
        FileScan fscan = null;
        
        try {
            fscan = new FileScan(heapfile_name, attrType_, t1_str_sizes_, (short) len_in1_, len_in1_, projlist, null);
        }
        catch (Exception e) {
            e.printStackTrace();
        }

        TupleOrder[] order = new TupleOrder[2];
        order[0] = new TupleOrder(TupleOrder.Ascending);
        order[1] = new TupleOrder(TupleOrder.Descending);


        Sort sort = null;
        try {
            sort = new Sort(attrType_, (short)len_in1_, t1_str_sizes_, fscan, index_fld_, order[0], 1, n_pages_);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        
        Tuple t = new Tuple();
        try{
            t.setHdr((short) len_in1_, attrType_, t1_str_sizes_);
        }catch(Exception e){
            e.printStackTrace();
        }
        
        t = new Tuple(t.size());
        try{
            t.setHdr((short) len_in1_, attrType_, t1_str_sizes_);
        }catch(Exception e){
            e.printStackTrace();
        }
        try {
            t = sort.get_next();
            //sf.insertRecord(t.returnTupleByteArray());
            Insert(t);
        }
        catch (Exception e) {
            e.printStackTrace(); 
        }
        
        while (t != null) {
            try {
                t = sort.get_next();
                //sf.insertRecord(t.returnTupleByteArray());
                Insert(t);
            }
            catch (Exception e){
                if(t == null){
                    // clean up
                    try {
                        sort.close();
                    }
                    catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
            }
        }

        // insert into the clustered b tree
    }

    public Tuple get_next(RID rid_t)
    {

        if(get_next_initialization)
        {
            try {
                get_next_scan_ = (BTCFileScan) IndexUtils.BTreeClustered_scan(null, btf);
            }
            catch (Exception e) {
                e.printStackTrace();
            }
            get_next_initialization =  false;
        }

        if(get_next_count_ == 0)
        {
            get_next_heap_ = true;
            
        }

        if(get_next_heap_ == true)
        {
            try {
                get_next_btree_root_ = get_next_scan_.get_next();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        if(get_next_btree_root_ == null) return null;

        DataClass data;
        LeafData leaf_data ;
        RID present_rid;
        int slot_no;
        
        data = get_next_btree_root_.data;
        leaf_data = (LeafData)data;
        present_rid = leaf_data.getData();
        slot_no = present_rid.slotNo;

        Heapfile temp_h = null;
        
        try {
            temp_h = new Heapfile("BTC" + String.valueOf(slot_no));
        } catch (Exception e) {
            e.printStackTrace();
        }

       
        if(get_next_heap_ == true)
        {
            try {
                get_next_heap_scan_ = new Scan(temp_h);
            } catch (Exception e1) {
                e1.printStackTrace();
            }

            try {
                get_next_count_ = temp_h.getRecCnt();
            } catch (InvalidSlotNumberException | InvalidTupleSizeException | HFDiskMgrException | HFBufMgrException
                    | IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        
        

        Tuple t = new Tuple();
        try{
            t.setHdr((short) len_in1_, attrType_, t1_str_sizes_);
        }catch(Exception e){
            e.printStackTrace();
        }
        
        t = new Tuple(t.size());
        try{
            t.setHdr((short) len_in1_, attrType_, t1_str_sizes_);
        }catch(Exception e){
            e.printStackTrace();
        }

        if(get_next_heap_)
        {
            get_next_Rid = new RID();
            get_next_heap_ = false;
        }
       
        System.out.println(rid_t.pageNo.pid);
        try {
            t = get_next_heap_scan_.getNext(get_next_Rid);
            get_next_count_--;

            if(get_next_count_ == 0)
            {
                get_next_heap_scan_.closescan();
                
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        rid_t.slotNo = get_next_Rid.slotNo;
        rid_t.pageNo.pid = slot_no;
              
        try{
            t.setHdr((short) len_in1_, attrType_, t1_str_sizes_);
        }catch(Exception e){
            e.printStackTrace();
        }

        return t;
    }

    public Tuple getRecord(RID rid_t)
    {

        Heapfile temp_h = null;

        Tuple t = new Tuple();
        try {
          t.setHdr((short) 2, attrType_, t1_str_sizes_);
        }
        catch (Exception e) {
          
          e.printStackTrace();
        }

        int size = t.size();

        t = new Tuple(size);
        try {
        t.setHdr((short) 2, attrType_, t1_str_sizes_);
        }
        catch (Exception e) {
        
        e.printStackTrace();
        }
        
        try {
            temp_h = new Heapfile("BTC" + String.valueOf(rid_t.pageNo.pid));
        } catch (Exception e) {
            e.printStackTrace();
        }
        if(temp_h == null)
        {
            return null;
        }

        Scan s = null;
        try {
            s = new Scan(temp_h);
        } catch (Exception e1) {
            e1.printStackTrace();
        }

        RID rid = new RID();

        try {
            t = s.getNext(rid);
            
        } catch (InvalidTupleSizeException | IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        if(t == null) return null;

        try {
        t.setHdr((short) 2, attrType_, t1_str_sizes_);
        }
        catch (Exception e) {
        
        e.printStackTrace();
        }

        s.closescan();

        

        RID rid_new = new RID();

        rid_new.pageNo.pid = rid.pageNo.pid;
        rid_new.slotNo = rid_t.slotNo; 

        try {
            t = temp_h.getRecord(rid_new);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        if(t == null) return null;
        try {
            t.setHdr((short) 2, attrType_, t1_str_sizes_);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return t;
    }
}


