package iterator;


import java.io.*;
import global.*;
import bufmgr.*;
import diskmgr.*;
import heap.*;
import iterator.*;
import index.*;
import java.util.Random;
import btree.*;

public class BTreeSky extends Iterator implements GlobalConst {

    AttrType[] in1_;
    int len_in1_;
    short[] t1_str_sizes_;
    int[] pref_list_;
    int pref_list_length_;
    Iterator am1_;
    BTreeFile[] index_file_;
    int n_pages_;
    FileScan fscan_get_next = null;
    IndexScan iscan = null;
    byte bufs[][];

    Heapfile        f = null; //input file of records
    Heapfile        skyline_Heapfile = null; //heapfile to store skyline tuples
    Heapfile        skyline_candidate = null; //heapfile to store the skyline candidates tuples
    public BTreeSky(AttrType[] in1, int len_in1, short[] t1_str_sizes, Iterator am1, java.lang.String relationName, int[] pref_list, int pref_list_length, BTreeFile[] btf, int n_pages)
    throws Exception{

        // in1_ = in1;
        // len_in1_ = len_in1;
        // t1_str_sizes_ = t1_str_sizes;
        // pref_list_ = pref_list;
        // pref_list_length_ = pref_list_length;
        // am1_ = am1;
        // index_file_ = btf;
        // n_pages_ = n_pages;

        //heapfile which has input data
       // f = new Heapfile(relationName);
        //heapfile to store the heapfile that is passed in Sort First Sky
        skyline_candidate = new Heapfile("skyline_candidate");
        //heapfile to store the resultant skyline tuples
        skyline_Heapfile = new Heapfile("skyline4.in");
        short[] Psizes = {};

 for(int j=0; j<pref_list.length; j++)
 {
        try {
            btf[j] = new BTreeFile("BTIndex"+j);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        
        System.out.println("BTIndex"+j+ " opened successfully.\n"); 
        
        RID rid = new RID();
        int key1;
        Tuple temp1 = null;

        FldSpec[] projlist = new FldSpec[len_in1];
        RelSpec rel = new RelSpec(RelSpec.outer); 
        for(int k = 0; k < len_in1; k++)
        {
            projlist[k] = new FldSpec(rel, k+1);
        }

        short REC_LEN1 = 32; 
        short REC_LEN2 = 160; 
        short[] attrSize = new short[2];
        attrSize[0] = REC_LEN2;
        attrSize[1] = REC_LEN1;
        
        // start index scan
        IndexScan iscan = null;
        try {
            iscan = new IndexScan(new IndexType(IndexType.B_Index), relationName, "BTIndex"+j, in1, attrSize, len_in1, len_in1, projlist, null, pref_list[j], false);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        

        int count = 0;
        Tuple t = new Tuple();
        try {
            t.setHdr((short)len_in1, in1, null); 
        } catch (Exception e) {
            e.printStackTrace();
        }
        int size = t.size();
        t = new Tuple(t.size()); 
        try {
            t = iscan.get_next();
        }
        catch (Exception e) {
            e.printStackTrace(); 
        }

        if (t == null) {
            System.err.println("no record retrieved");
        }
        
        // try {
        //     t = iscan.get_next();
        // }
        // catch (Exception e) {
        //     e.printStackTrace(); 
        // }
        
        // clean up
        try {
            iscan.close();
        }
        catch (Exception e) {
            e.printStackTrace();
        }

        //print the leaf nodes

   //}
    }




            //main logic

            //store

            //to use printPage, you need arguments pageID and keyType -> issue is padeID

            //take the first element from the first btree 
            Tuple t = new Tuple();

            
            
            try {
                t.setHdr((short) len_in1, in1, Psizes);
            } catch (Exception e) {
                e.printStackTrace();
            }
            int size = t.size();
            Tuple temp_tuple = new Tuple(size);

            Tuple iter_tuple = new Tuple(size);
            try {
                temp_tuple.setHdr((short) len_in1, in1, Psizes);
            } catch (Exception e) {
                e.printStackTrace();
            }
            try {
                iter_tuple.setHdr((short) len_in1, in1, Psizes);
            } catch (Exception e) {
                e.printStackTrace();
            }
            // Create unsorted data file "unsortedfile"
            RID ridx;
            Heapfile skyline_candidate = null;
            try {
                skyline_candidate = new Heapfile("skyline_candidate");
            } catch (Exception e) {
                e.printStackTrace();
            }

            

            short[] attrSize = new short[2];
            short REC_LEN1 = 32; 
            short REC_LEN2 = 160; 
            attrSize[0] = REC_LEN2;
            attrSize[1] = REC_LEN1;

            AttrType  print_tuple = new AttrType(AttrType.attrReal);


            FldSpec[] projlist = new FldSpec[len_in1];
        RelSpec rel = new RelSpec(RelSpec.outer); 
        for(int k = 0; k < len_in1; k++)
        {
            projlist[k] = new FldSpec(rel, k+1);
        }


            for(int i=0; i<pref_list.length; i++)
            {
                //System.out.println(i);

                if(i==0)
                {
                    //store tuple as temp_tuple to compare with other tuples
                            // start index scan
                            IndexScan iscan1 = null;
                            try {
                                iscan1 = new IndexScan(new IndexType(IndexType.B_Index), "unsortedfile", "BTIndex"+i, in1, attrSize, len_in1, len_in1, projlist, null, len_in1, false);
                                temp_tuple = iscan1.get_next();   
                                try {
                                    temp_tuple.setHdr((short) len_in1, in1, Psizes);
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                            catch (Exception e) {
                                e.printStackTrace();
                                }
                                try {
                                    skyline_candidate.insertRecord(new Tuple(temp_tuple).returnTupleByteArray());
                                   

                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                               
                }
                else{
                  //  IndexScan iscan = null;
                  
                            try {
                                if(iscan!=null)
                                    iscan.close();
                                iscan = new IndexScan(new IndexType(IndexType.B_Index), "unsortedfile", "BTIndex"+i, in1, attrSize, len_in1, len_in1, projlist, null, len_in1, false);
                              //  iter_tuple = iscan.get_next();    

                            }
                            catch (Exception e) {
                                e.printStackTrace();
                                }
                                
                    //else compare this to the temp_tuple and add elements in the heap that will be sent to block nested loop
                    //while get next is not null (we dont reach till the end of the btree) we keep comparing til we find temp_tuple    
                    boolean heap_empty = true;
                    int kk = 0;
                    while((iter_tuple=iscan.get_next())!=null)
                    {
                        
                        try {
                            iter_tuple.setHdr((short) len_in1, in1, Psizes);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        //compare iter_tuple and temp_tuple
                        try {
                            boolean comp_res = TupleUtils.Equal(iter_tuple, temp_tuple, in1, len_in1);
                            if(comp_res)
                            {
                                //iter_tuple and temp_tuple are the same
                                //Hence, we break the loop and check in the next pref attribute BTree
                                break;
                            }
                            else 
                            {

                                //insert the iter_tuple in Heap skyline_candidate after checking if it is not there already
                                // create an scan on the heapfile conataining the data
                            
                                IndexScan scan_skc_hf = null;
                                projlist = new FldSpec[2];
                                rel = new RelSpec(RelSpec.outer); 
                                projlist = new FldSpec[len_in1];
                                rel = new RelSpec(RelSpec.outer); 
                                for(int k = 0; k < len_in1; k++)
                                {
                                    projlist[k] = new FldSpec(rel, k+1);
                                }                    
                                
                                Tuple temptuple = new Tuple(); // outer
                                
                                Scan scan1 = new Scan(skyline_candidate);
                                temptuple = new Tuple(t.size());
                                Tuple temp1234 = null;
                                RID rid2 = new RID();
                                try {
                                    temptuple.setHdr((short) len_in1, in1, Psizes);
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                        }
                                    boolean iter_tuple_found = false;

                                while((temptuple=scan1.getNext(rid2))!=null)
                                {
                                    try {
                                        temptuple.setHdr((short) len_in1, in1, Psizes);
                                            } catch (Exception e) {
                                                e.printStackTrace();
                                            }
                                    boolean comp_tuple = TupleUtils.Equal(iter_tuple,temptuple,in1,len_in1);
                                    if(comp_tuple== true)
                                    {
                                        iter_tuple_found = true;
                                        break;
                                    } 
                                    rid2 = new RID();
                                }
                                
                                scan1.closescan();
                                if(!iter_tuple_found)
                                {
                                    try {
                                        skyline_candidate.insertRecord(new Tuple(iter_tuple).returnTupleByteArray());
                                        
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                } 
                            }  

                              }catch (Exception e){
                                  e.printStackTrace();
                              }

                    }
                }
            }

            FileScan scan_heapFile = null;
            projlist = new FldSpec[2];
            rel = new RelSpec(RelSpec.outer); 
            projlist = new FldSpec[len_in1];
            rel = new RelSpec(RelSpec.outer); 
           for(int k = 0; k < len_in1; k++)
           {
               projlist[k] = new FldSpec(rel, k+1);
           }
            
            try {
                scan_heapFile = new FileScan("skyline_candidate", in1, null, (short) len_in1, len_in1, projlist, null);
            }
            catch (Exception e) {
            e.printStackTrace();
            }
                                
                                // int key = 0;
                                Scan scan = new Scan(skyline_candidate);
                                Tuple tempetuple2 = new Tuple();
                                Tuple temp123 = null;
                                RID rid = new RID();
                                try {
                                    tempetuple2.setHdr((short) len_in1, in1, Psizes);
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                        }
                                System.out.println("final heap file named skyline_candidate");
                                    while((temp123 = scan.getNext(rid)) != null){
                                        tempetuple2.tupleCopy(temp123);
                                    }
                              
                                    scan.closescan();
                                    scan_heapFile.close();
                                BlockNestedLoopSky final_skyline = null;

                                Scan fscan = null;
                                // start the scan on the index file
                                try {   
                                    fscan = new Scan(skyline_candidate);

                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                                rid = new RID();
                                try {
                                    tempetuple2.setHdr((short) len_in1, in1, Psizes);
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                        }
                                    while((temp123 = fscan.getNext(rid)) != null){
                                        tempetuple2.tupleCopy(temp123);
                                        tempetuple2.print(in1);
                                    }

                                    fscan.closescan();
                                    
                                try{
                                    final_skyline = new BlockNestedLoopSky(in1, in1.length, null, null, "skyline_candidate" , pref_list, pref_list.length, n_pages);
                                }catch(Exception e){
                                    e.printStackTrace();
                                }

                               // to do correct this code below

                                Heapfile final_skyline_heapfile = null; //heapfile to store the skyline candidates tuples
                                final_skyline_heapfile = new Heapfile("final_skyline_heapfile");


                                Tuple t_ans = new Tuple();
                                try{
                                    t_ans.setHdr((short)len_in1, in1, Psizes);
                                }catch(Exception e){}
                        
                                t_ans = new Tuple(t.size());
                                try{
                                    t_ans.setHdr((short)len_in1, in1, Psizes);
                                }catch(Exception e){}
                        
                                try {
                                    t_ans = final_skyline.get_next();
                                    t_ans.print(in1);
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }

                                while(t_ans != null)
                                {
                                    try {
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                    try {
                                        final_skyline_heapfile.insertRecord(new Tuple(t_ans).returnTupleByteArray());
                                        t_ans = final_skyline.get_next();

                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                }

                                try {
                                    fscan_get_next = new FileScan("final_skyline_heapfile", in1, null, (short) len_in1, len_in1, projlist, null);
                                }
                                catch (Exception e) {
                                e.printStackTrace();
                                }

    }

    @Override
    public Tuple get_next() throws IOException, JoinsException, IndexException, InvalidTupleSizeException,
            InvalidTypeException, PageNotReadException, TupleUtilsException, PredEvalException, SortException,
            LowMemException, UnknowAttrType, UnknownKeyTypeException, Exception {
       

        // create an iterator by open a file scan
        FldSpec[] projlist = new FldSpec[len_in1_];
        RelSpec rel = new RelSpec(RelSpec.outer);

        for(int i = 0; i < len_in1_; i++)
        {
            projlist[i] = new FldSpec(rel, i+1);
        }

        return fscan_get_next.get_next();
    }

    @Override
    public void close() throws IOException, JoinsException, SortException, IndexException {
        Heapfile x = null;
        try{
            x = new Heapfile("final_skyline_heapfile");
            x.deleteFile();
        }catch(Exception e){}
        fscan_get_next.close();
    }
    
}
