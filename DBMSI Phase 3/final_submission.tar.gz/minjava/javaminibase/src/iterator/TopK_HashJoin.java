package iterator;

import java.io.IOException;

import global.AttrOperator;
import global.AttrType;
import global.Catalogglobal;
import global.GlobalConst;
import global.TupleOrder;
import heap.Heapfile;
import heap.Tuple;

public class TopK_HashJoin extends Iterator implements GlobalConst, Catalogglobal {

    AttrType[] in1_;
    int len_in1_;
    short[] t1_str_sizes_;
    FldSpec joinAttr1_;
    FldSpec mergeAttr1_;

    AttrType[] in2_;
    int len_in2_;
    short[] t2_str_sizes_;
    FldSpec joinAttr2_;
    FldSpec mergeAttr2_;

    int k_;
    int n_pages_;

    FileScan fscan_get_next = null;

    Heapfile topkjoin_heapfile = null; // heapfile to store resultant tuples

    public TopK_HashJoin(AttrType[] in1, int len_in1, short[] t1_str_sizes, FldSpec joinAttr1, FldSpec mergeAttr1,
            AttrType[] in2, int len_in2, short[] t2_str_sizes, FldSpec joinAttr2, FldSpec mergeAttr2,
            java.lang.String relationName1, java.lang.String relationName2, int k, int n_pages)
            throws UnknowAttrType, LowMemException, Exception {
        in1_ = in1;
        len_in1_ = len_in1;
        t1_str_sizes_ = t1_str_sizes;
        joinAttr1_ = joinAttr1;
        mergeAttr1_ = mergeAttr1;

        in2_ = in2;
        len_in2_ = len_in2;
        t2_str_sizes_ = t2_str_sizes;
        joinAttr2_ = joinAttr2;
        mergeAttr2_ = mergeAttr2;

        k_ = k;
        n_pages_ = n_pages;

        // heapfile for final answer
        try {
            topkjoin_heapfile = new Heapfile("topkhashjoin");
        } catch (Exception e) {
            e.printStackTrace();
        }

        // hash join between the two tables
        HashJoin hj = null;

        // proj_list for the hash join
        FldSpec[] projlist = new FldSpec[len_in1 + len_in2];
        RelSpec rel = new RelSpec(RelSpec.outer);
        RelSpec relin = new RelSpec(RelSpec.innerRel);
        for (int i = 0; i < len_in1 + len_in2; i++) {
            if (i < in1.length)
                projlist[i] = new FldSpec(rel, i + 1);
            else {
                projlist[i] = new FldSpec(relin, i + 1 - in1.length);
            }
        }

        CondExpr[] outFilter = new CondExpr[2];
        outFilter[1] = null;
        outFilter[0] = new CondExpr();
        outFilter[0].op = new AttrOperator(AttrOperator.aopEQ);
        outFilter[0].type1 = new AttrType(AttrType.attrSymbol);
        outFilter[0].operand1.symbol = new FldSpec(rel, joinAttr1.offset);
        outFilter[0].type2 = new AttrType(AttrType.attrSymbol);
        outFilter[0].operand2.symbol = new FldSpec(relin, joinAttr2.offset);

        try {
            hj = new HashJoin(in1, len_in1, t1_str_sizes, in2, len_in2, t2_str_sizes, n_pages, relationName1,
                    relationName2, outFilter, null, projlist, len_in1 + len_in2, joinAttr1, joinAttr2);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // attrtype for the joined tuple with avg
        AttrType[] joined_attrType = new AttrType[len_in1 + len_in2 + 1];
        for (int i = 0; i < len_in1 + len_in2 + 1; i++) {
            if (i < len_in1) {
                joined_attrType[i] = in1[i];
            } else if (i >= len_in1 && i < len_in1 + len_in2) {
                joined_attrType[i] = in2[i - len_in1];
            }
            if (i == len_in1 + len_in2) {
                joined_attrType[i] = in1[mergeAttr1.offset - 1];
            }
        }

        // attrtype for the joined tuple without avg
        AttrType[] joined_at_minus_avg = new AttrType[len_in1 + len_in2];
        for (int i = 0; i < len_in1 + len_in2; i++) {
            if (i < len_in1) {
                joined_at_minus_avg[i] = in1[i];
            } else {
                joined_at_minus_avg[i] = in2[i - len_in1];
            }
        }

        // heapfile to store result of hash join
        Heapfile hash_join = null;
        try {
            hash_join = new Heapfile("hashjoinedfile");
        } catch (Exception e) {
            e.printStackTrace();
        }

        // resultant tuple of hash join to insert into the resultant hash join heapfile
        // this has one extra field for avg
        Tuple joined_tuple = new Tuple();
        try {
            joined_tuple.setHdr((short) (len_in1 + len_in2 + 1), joined_attrType, t1_str_sizes);
        } catch (Exception e) {
            e.printStackTrace();
        }
        joined_tuple = new Tuple(joined_tuple.size());
        try {
            joined_tuple.setHdr((short) (len_in1 + len_in2 + 1), joined_attrType, t1_str_sizes);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // tuple for resultant joined tuple without avg
        Tuple jtminusavg = new Tuple();
        try {
            jtminusavg.setHdr((short) (len_in1 + len_in2), joined_at_minus_avg, t1_str_sizes);
        } catch (Exception e) {
            e.printStackTrace();
        }
        jtminusavg = new Tuple(jtminusavg.size());
        try {
            jtminusavg.setHdr((short) (len_in1 + len_in2), joined_at_minus_avg, t1_str_sizes);
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            jtminusavg = hj.get_next();
            for (int i = 0; i < len_in1 + len_in2 + 1; i++) {
                if (i < len_in1) {
                    if (in1[i].attrType == AttrType.attrInteger) {
                        joined_tuple.setIntFld(i + 1, jtminusavg.getIntFld(i + 1));
                    } else if (in1[i].attrType == AttrType.attrReal) {
                        joined_tuple.setFloFld(i + 1, jtminusavg.getFloFld(i + 1));
                    } else if (in1[i].attrType == AttrType.attrString) {
                        joined_tuple.setStrFld(i + 1, jtminusavg.getStrFld(i + 1));
                    }
                } else if (i >= len_in1 && i < len_in1 + len_in2) {
                    if (in2[i - len_in1].attrType == AttrType.attrInteger) {
                        joined_tuple.setIntFld(i + 1, jtminusavg.getIntFld(i + 1));
                    } else if (in2[i - len_in1].attrType == AttrType.attrReal) {
                        joined_tuple.setFloFld(i + 1, jtminusavg.getFloFld(i + 1));
                    } else if (in2[i - len_in1].attrType == AttrType.attrString) {
                        joined_tuple.setStrFld(i + 1, jtminusavg.getStrFld(i + 1));
                    }
                } else {
                    if (in1[mergeAttr1.offset - 1].attrType == AttrType.attrInteger) {
                        joined_tuple.setIntFld(i + 1, (jtminusavg.getIntFld(mergeAttr1.offset)
                                + jtminusavg.getIntFld(len_in1 + mergeAttr2.offset)) / 2);
                    } else if (in1[mergeAttr1.offset - 1].attrType == AttrType.attrReal) {
                        joined_tuple.setFloFld(i + 1, (jtminusavg.getFloFld(mergeAttr1.offset)
                                + jtminusavg.getFloFld(len_in1 + mergeAttr2.offset)) / 2);
                    } else if (in1[mergeAttr1.offset - 1].attrType == AttrType.attrString) {
                        // TODO
                        // joined_tuple.setStrFld(i + 1, jtminusavg.getStrFld(i + 1));
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        while (jtminusavg != null) {
            try {
                hash_join.insertRecord(joined_tuple.returnTupleByteArray());
            } catch (Exception e) {
                e.printStackTrace();
            }

            try {
                jtminusavg.setHdr((short) (len_in1 + len_in2), joined_at_minus_avg, t1_str_sizes);
            } catch (Exception e) {
                e.printStackTrace();
            }
            jtminusavg = new Tuple(jtminusavg.size());
            try {
                jtminusavg.setHdr((short) (len_in1 + len_in2), joined_at_minus_avg, t1_str_sizes);
            } catch (Exception e) {
                e.printStackTrace();
            }

            try {
                jtminusavg = hj.get_next();
                for (int i = 0; i < len_in1 + len_in2 + 1; i++) {
                    if (i < len_in1) {
                        if (in1[i].attrType == AttrType.attrInteger) {
                            joined_tuple.setIntFld(i + 1, jtminusavg.getIntFld(i + 1));
                        } else if (in1[i].attrType == AttrType.attrReal) {
                            joined_tuple.setFloFld(i + 1, jtminusavg.getFloFld(i + 1));
                        } else if (in1[i].attrType == AttrType.attrString) {
                            joined_tuple.setStrFld(i + 1, jtminusavg.getStrFld(i + 1));
                        }
                    } else if (i >= len_in1 && i < len_in1 + len_in2) {
                        if (in2[i - len_in1].attrType == AttrType.attrInteger) {
                            joined_tuple.setIntFld(i + 1, jtminusavg.getIntFld(i + 1));
                        } else if (in2[i - len_in1].attrType == AttrType.attrReal) {
                            joined_tuple.setFloFld(i + 1, jtminusavg.getFloFld(i + 1));
                        } else if (in2[i - len_in1].attrType == AttrType.attrString) {
                            joined_tuple.setStrFld(i + 1, jtminusavg.getStrFld(i + 1));
                        }
                    } else {
                        if (in1[mergeAttr1.offset - 1].attrType == AttrType.attrInteger) {
                            joined_tuple.setIntFld(i + 1, (jtminusavg.getIntFld(mergeAttr1.offset)
                                    + jtminusavg.getIntFld(len_in1 + mergeAttr2.offset)) / 2);
                        } else if (in1[mergeAttr1.offset - 1].attrType == AttrType.attrReal) {
                            joined_tuple.setFloFld(i + 1, (jtminusavg.getFloFld(mergeAttr1.offset)
                                    + jtminusavg.getFloFld(len_in1 + mergeAttr2.offset)) / 2);
                        } else if (in1[mergeAttr1.offset - 1].attrType == AttrType.attrString) {
                            // TODO
                            // joined_tuple.setStrFld(i + 1, jtminusavg.getStrFld(i + 1));
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        // sort the data in descending order
        // create a tuple of appropriate size
        try {
            joined_tuple.setHdr((short) (len_in1 + len_in2 + 1), joined_attrType, t1_str_sizes);
        } catch (Exception e) {
            e.printStackTrace();
        }
        joined_tuple = new Tuple(joined_tuple.size());
        try {
            joined_tuple.setHdr((short) (len_in1 + len_in2 + 1), joined_attrType, t1_str_sizes);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // create an iterator by open a file scan
        FldSpec[] projlist5 = new FldSpec[len_in1 + len_in2 + 1];
        RelSpec rel5 = new RelSpec(RelSpec.outer);
        for (int i = 0; i < len_in1 + len_in2 + 1; i++) {
            projlist5[i] = new FldSpec(rel5, i + 1);
        }

        FileScan fscan = null;
        try {
            fscan = new FileScan("hashjoinedfile", joined_attrType, t1_str_sizes, (short) joined_attrType.length,
                    joined_attrType.length, projlist5, null);
        } catch (Exception e) {
            e.printStackTrace();
        }

        TupleOrder[] order = new TupleOrder[2];
        order[0] = new TupleOrder(TupleOrder.Ascending);
        order[1] = new TupleOrder(TupleOrder.Descending);

        Sort sort = null;
        try {
            sort = new Sort(joined_attrType, (short) joined_attrType.length, t1_str_sizes, fscan, len_in1 + len_in2 + 1,
                    order[1], 1, n_pages);
        } catch (Exception e) {
            e.printStackTrace();
        }

        for (int i = 0; i < k; i++) {
            joined_tuple = sort.get_next();
            topkjoin_heapfile.insertRecord(joined_tuple.returnTupleByteArray());
            try {
                joined_tuple.setHdr((short) (len_in1 + len_in2 + 1), joined_attrType, t1_str_sizes);
            } catch (Exception e) {
                e.printStackTrace();
            }
            joined_tuple = new Tuple(joined_tuple.size());
            try {
                joined_tuple.setHdr((short) (len_in1 + len_in2 + 1), joined_attrType, t1_str_sizes);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        fscan_get_next = new FileScan("topkhashjoin", joined_attrType, t1_str_sizes, (short) joined_attrType.length,
                joined_attrType.length, projlist5, null);
    }

    @Override
    public Tuple get_next() throws Exception {

        FldSpec[] projlist = new FldSpec[len_in1_ + len_in2_ + 1];
        RelSpec rel = new RelSpec(RelSpec.outer);
        for (int i = 0; i < len_in1_ + len_in2_ + 1; i++) {
            projlist[i] = new FldSpec(rel, i + 1);
        }

        return fscan_get_next.get_next();
    }

    @Override
    public void close() throws IOException, JoinsException, SortException {

        Heapfile x = null;
        try {
            x = new Heapfile("topkhashjoin");
            x.deleteFile();
        } catch (Exception e) {
        }
        fscan_get_next.close();
    }
}
