package iterator;

import java.io.IOException;

import btree.BTreeFile;
import btree.FloatKey;
import global.AttrType;
import global.Catalogglobal;
import global.GlobalConst;
import global.IndexType;
import global.RID;
import heap.FieldNumberOutOfBoundException;
import heap.HFBufMgrException;
import heap.HFDiskMgrException;
import heap.HFException;
import heap.Heapfile;
import heap.InvalidSlotNumberException;
import heap.InvalidTupleSizeException;
import heap.Scan;
import heap.SpaceNotAvailableException;
import heap.Tuple;
import index.IndexScan;

public class HashJoin extends Iterator implements GlobalConst, Catalogglobal {

    AttrType[] in1_, in2_;
    int len_in1_, len_in2_;
    short[] t1_str_sizes_, t2_str_sizes_;
    CondExpr[] OutputFilter;
    CondExpr[] RightFilter;
    int n_pages_; // # of buffer pages available.
    boolean get_from_outer; // if TRUE, a tuple is got from outer
    Tuple outer_tuple, inner_tuple;
    Tuple Jtuple; // Joined tuple
    FldSpec[] perm_mat;
    int nOutFlds;
    FldSpec join_attr_1_;
    FldSpec join_attr_2_;
    Heapfile hf1; // file for first relation
    Heapfile hf2; // file for second relation
    Scan inner;
    Scan outer;
    FileScan fscan_get_next = null;

    Heapfile hashjoin_heapfile = null; // heapfile to store resultant tuples

    public HashJoin(AttrType[] in1, int len_in1, short[] t1_str_sizes, AttrType[] in2, int len_in2,
            short[] t2_str_sizes, int n_pages, String relationName1, String relationName2, CondExpr[] outFilter,
            CondExpr[] rightFilter, FldSpec[] proj_list, int n_out_flds, FldSpec join_attr_1, FldSpec join_attr_2)
            throws IOException, NestedLoopException, FileScanException, TupleUtilsException, InvalidRelation,
            InvalidSlotNumberException, InvalidTupleSizeException, HFDiskMgrException, HFBufMgrException,
            FieldNumberOutOfBoundException, SpaceNotAvailableException, HFException {

        in1_ = in1;
        len_in1_ = len_in1;
        t1_str_sizes_ = t1_str_sizes;
        in2_ = in2;
        len_in2_ = len_in2;
        t2_str_sizes_ = t2_str_sizes;
        n_pages_ = n_pages;
        OutputFilter = outFilter;
        RightFilter = rightFilter;
        join_attr_1_ = join_attr_1;
        join_attr_2_ = join_attr_2;

        get_from_outer = true;

        inner = null;
        outer = null;

        inner_tuple = new Tuple();
        Jtuple = new Tuple();

        AttrType[] Jtypes = new AttrType[n_out_flds];
        short[] t_size;

        perm_mat = proj_list;
        nOutFlds = n_out_flds;

        // heapfile for first relation
        try {
            hf1 = new Heapfile(relationName1);
            System.out.println(hf1.getRecCnt());

        } catch (Exception e) {
            e.printStackTrace();
        }

        // heapfile for second relation
        try {
            hf2 = new Heapfile(relationName2);
            System.out.println(hf2.getRecCnt());

        } catch (Exception e) {
            e.printStackTrace();
        }

        // heapfile for result
        try {
            hashjoin_heapfile = new Heapfile("hashjoin");
        } catch (Exception e) {
            e.printStackTrace();
        }

        // create 4 buckets for outer relation
        Heapfile outerbucket1 = null;
        try {
            outerbucket1 = new Heapfile("outerbucket1");
        } catch (Exception e) {
        }

        Heapfile outerbucket2 = null;
        try {
            outerbucket2 = new Heapfile("outerbucket2");
        } catch (Exception e) {
        }

        Heapfile outerbucket3 = null;
        try {
            outerbucket3 = new Heapfile("outerbucket3");
        } catch (Exception e) {
        }

        Heapfile outerbucket4 = null;
        try {
            outerbucket4 = new Heapfile("outerbucket4");
        } catch (Exception e) {
        }

        // create 4 buckets for inner relation
        Heapfile innerbucket1 = null;
        try {
            innerbucket1 = new Heapfile("innerbucket1");
        } catch (Exception e) {
        }

        Heapfile innerbucket2 = null;
        try {
            innerbucket2 = new Heapfile("innerbucket2");
        } catch (Exception e) {
        }

        Heapfile innerbucket3 = null;
        try {
            innerbucket3 = new Heapfile("innerbucket3");
        } catch (Exception e) {
        }

        Heapfile innerbucket4 = null;
        try {
            innerbucket4 = new Heapfile("innerbucket4");
        } catch (Exception e) {
        }

        // tuple for outer relation
        Tuple outer_Tuple = new Tuple();
        try {
            outer_Tuple.setHdr((short) len_in1, in1, t1_str_sizes);
        } catch (Exception e) {
            e.printStackTrace();
        }

        outer_Tuple = new Tuple(outer_Tuple.size());

        try {
            outer_Tuple.setHdr((short) len_in1, in1, t1_str_sizes);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // tuple for inner relation
        Tuple inner_tuple = new Tuple();
        try {
            inner_tuple.setHdr((short) len_in2, in2, t2_str_sizes);
        } catch (Exception e) {
            e.printStackTrace();
        }

        inner_tuple = new Tuple(inner_tuple.size());

        try {
            inner_tuple.setHdr((short) len_in2, in2, t2_str_sizes);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // create hash partitions by scanning the outer relation heapfile and inserting
        // tuples into relevant buckets
        try {
            outer = hf1.openScan();
        } catch (Exception e) {
        }

        RID r = new RID();
        int hash;

        try {
            outer_Tuple.tupleCopy(outer.getNext(r));
            // apply hash function
            if (in1[join_attr_1.offset - 1].attrType == AttrType.attrString) {
                hash = 7;
                for (int i = 0; i < (outer_Tuple.getStrFld(join_attr_1.offset)).length(); i++) {
                    hash = hash * 31 + outer_Tuple.getStrFld(join_attr_1.offset).charAt(i);
                }
                if (hash % 4 == 0) {
                    outerbucket1.insertRecord(outer_Tuple.returnTupleByteArray());
                } else if (hash % 4 == 1) {
                    outerbucket2.insertRecord(outer_Tuple.returnTupleByteArray());
                } else if (hash % 4 == 2) {
                    outerbucket3.insertRecord(outer_Tuple.returnTupleByteArray());
                } else if (hash % 4 == 3) {
                    outerbucket4.insertRecord(outer_Tuple.returnTupleByteArray());
                }
            } else if (in1[join_attr_1.offset - 1].attrType == AttrType.attrReal) {

                if ((outer_Tuple.getFloFld(join_attr_1.offset) * 10000) % 4 == 0) {
                    outerbucket1.insertRecord(outer_Tuple.returnTupleByteArray());
                } else if ((outer_Tuple.getFloFld(join_attr_1.offset) * 10000) % 4 == 1) {
                    outerbucket2.insertRecord(outer_Tuple.returnTupleByteArray());
                } else if ((outer_Tuple.getFloFld(join_attr_1.offset) * 10000) % 4 == 2) {
                    outerbucket3.insertRecord(outer_Tuple.returnTupleByteArray());
                } else if ((outer_Tuple.getFloFld(join_attr_1.offset) * 10000) % 4 == 3) {
                    outerbucket4.insertRecord(outer_Tuple.returnTupleByteArray());
                }
            } else if (in1[join_attr_1.offset - 1].attrType == AttrType.attrInteger) {

                if (outer_Tuple.getIntFld(join_attr_1.offset) % 4 == 0) {
                    outerbucket1.insertRecord(outer_Tuple.returnTupleByteArray());
                } else if (outer_Tuple.getIntFld(join_attr_1.offset) % 4 == 1) {
                    outerbucket2.insertRecord(outer_Tuple.returnTupleByteArray());
                } else if (outer_Tuple.getIntFld(join_attr_1.offset) % 4 == 2) {
                    outerbucket3.insertRecord(outer_Tuple.returnTupleByteArray());
                } else if (outer_Tuple.getIntFld(join_attr_1.offset) % 4 == 3) {
                    outerbucket4.insertRecord(outer_Tuple.returnTupleByteArray());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        int count = 1;
        while (count < hf1.getRecCnt()) {
            count++;
            try {
                try {
                    outer_Tuple.setHdr((short) len_in1, in1, t1_str_sizes);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                outer_Tuple = new Tuple(outer_Tuple.size());

                try {
                    outer_Tuple.setHdr((short) len_in1, in1, t1_str_sizes);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                outer_Tuple.tupleCopy(outer.getNext(r));
                // apply hash function
                if (in1[join_attr_1.offset - 1].attrType == AttrType.attrString) {
                    hash = 7;
                    for (int i = 0; i < (outer_Tuple.getStrFld(join_attr_1.offset)).length(); i++) {
                        hash = hash * 31 + outer_Tuple.getStrFld(join_attr_1.offset).charAt(i);
                    }
                    if (hash % 4 == 0) {
                        outerbucket1.insertRecord(outer_Tuple.returnTupleByteArray());
                    } else if (hash % 4 == 1) {
                        outerbucket2.insertRecord(outer_Tuple.returnTupleByteArray());
                    } else if (hash % 4 == 2) {
                        outerbucket3.insertRecord(outer_Tuple.returnTupleByteArray());
                    } else if (hash % 4 == 3) {
                        outerbucket4.insertRecord(outer_Tuple.returnTupleByteArray());
                    }
                } else if (in1[join_attr_1.offset - 1].attrType == AttrType.attrReal) {

                    if ((outer_Tuple.getFloFld(join_attr_1.offset) * 10000) % 4 == 0) {
                        outerbucket1.insertRecord(outer_Tuple.returnTupleByteArray());
                    } else if ((outer_Tuple.getFloFld(join_attr_1.offset) * 10000) % 4 == 1) {
                        outerbucket2.insertRecord(outer_Tuple.returnTupleByteArray());
                    } else if ((outer_Tuple.getFloFld(join_attr_1.offset) * 10000) % 4 == 2) {
                        outerbucket3.insertRecord(outer_Tuple.returnTupleByteArray());
                    } else if ((outer_Tuple.getFloFld(join_attr_1.offset) * 10000) % 4 == 3) {
                        outerbucket4.insertRecord(outer_Tuple.returnTupleByteArray());
                    }
                } else if (in1[join_attr_1.offset - 1].attrType == AttrType.attrInteger) {

                    if (outer_Tuple.getIntFld(join_attr_1.offset) % 4 == 0) {
                        outerbucket1.insertRecord(outer_Tuple.returnTupleByteArray());
                    } else if (outer_Tuple.getIntFld(join_attr_1.offset) % 4 == 1) {
                        outerbucket2.insertRecord(outer_Tuple.returnTupleByteArray());
                    } else if (outer_Tuple.getIntFld(join_attr_1.offset) % 4 == 2) {
                        outerbucket3.insertRecord(outer_Tuple.returnTupleByteArray());
                    } else if (outer_Tuple.getIntFld(join_attr_1.offset) % 4 == 3) {
                        outerbucket4.insertRecord(outer_Tuple.returnTupleByteArray());
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        // clean up
        try {
            outer.closescan();
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        // create hash partitions by scanning the inner relation heapfile and inserting
        // tuples into relevant buckets
        try {
            inner = hf2.openScan();
        } catch (Exception e) {
        }

        RID r1 = new RID();
        try {
            inner_tuple.tupleCopy(inner.getNext(r));
            // apply hash function
            if (in2[join_attr_2.offset - 1].attrType == AttrType.attrString) {
                hash = 7;
                for (int i = 0; i < (inner_tuple.getStrFld(join_attr_2.offset)).length(); i++) {
                    hash = hash * 31 + inner_tuple.getStrFld(join_attr_2.offset).charAt(i);
                }
                if (hash % 4 == 0) {
                    innerbucket1.insertRecord(inner_tuple.returnTupleByteArray());
                } else if (hash % 4 == 1) {
                    innerbucket2.insertRecord(inner_tuple.returnTupleByteArray());
                } else if (hash % 4 == 2) {
                    innerbucket3.insertRecord(inner_tuple.returnTupleByteArray());
                } else if (hash % 4 == 3) {
                    innerbucket4.insertRecord(inner_tuple.returnTupleByteArray());
                }
            } else if (in2[join_attr_2.offset - 1].attrType == AttrType.attrReal) {

                if ((inner_tuple.getFloFld(join_attr_2.offset) * 10000) % 4 == 0) {
                    innerbucket1.insertRecord(inner_tuple.returnTupleByteArray());
                } else if ((inner_tuple.getFloFld(join_attr_2.offset) * 10000) % 4 == 1) {
                    innerbucket2.insertRecord(inner_tuple.returnTupleByteArray());
                } else if ((inner_tuple.getFloFld(join_attr_2.offset) * 10000) % 4 == 2) {
                    innerbucket3.insertRecord(inner_tuple.returnTupleByteArray());
                } else if ((inner_tuple.getFloFld(join_attr_2.offset) * 10000) % 4 == 3) {
                    innerbucket4.insertRecord(inner_tuple.returnTupleByteArray());
                }
            } else if (in2[join_attr_2.offset - 1].attrType == AttrType.attrInteger) {

                if (inner_tuple.getIntFld(join_attr_2.offset) % 4 == 0) {
                    innerbucket1.insertRecord(inner_tuple.returnTupleByteArray());
                } else if (inner_tuple.getIntFld(join_attr_2.offset) % 4 == 1) {
                    innerbucket2.insertRecord(inner_tuple.returnTupleByteArray());
                } else if (inner_tuple.getIntFld(join_attr_2.offset) % 4 == 2) {
                    innerbucket3.insertRecord(inner_tuple.returnTupleByteArray());
                } else if (inner_tuple.getIntFld(join_attr_2.offset) % 4 == 3) {
                    innerbucket4.insertRecord(inner_tuple.returnTupleByteArray());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        count = 1;
        while (count < hf2.getRecCnt()) {
            count++;
            try {
                try {
                    inner_tuple.setHdr((short) len_in1, in1, t1_str_sizes);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                inner_tuple = new Tuple(inner_tuple.size());

                try {
                    inner_tuple.setHdr((short) len_in1, in1, t1_str_sizes);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                inner_tuple.tupleCopy(inner.getNext(r));
                // apply hash function
                if (in2[join_attr_2.offset - 1].attrType == AttrType.attrString) {
                    hash = 7;
                    for (int i = 0; i < (inner_tuple.getStrFld(join_attr_2.offset)).length(); i++) {
                        hash = hash * 31 + inner_tuple.getStrFld(join_attr_2.offset).charAt(i);
                    }
                    if (hash % 4 == 0) {
                        innerbucket1.insertRecord(inner_tuple.returnTupleByteArray());
                    } else if (hash % 4 == 1) {
                        innerbucket2.insertRecord(inner_tuple.returnTupleByteArray());
                    } else if (hash % 4 == 2) {
                        innerbucket3.insertRecord(inner_tuple.returnTupleByteArray());
                    } else if (hash % 4 == 3) {
                        innerbucket4.insertRecord(inner_tuple.returnTupleByteArray());
                    }
                } else if (in2[join_attr_2.offset - 1].attrType == AttrType.attrReal) {

                    if ((inner_tuple.getFloFld(join_attr_2.offset) * 10000) % 4 == 0) {
                        innerbucket1.insertRecord(inner_tuple.returnTupleByteArray());
                    } else if ((inner_tuple.getFloFld(join_attr_2.offset) * 10000) % 4 == 1) {
                        innerbucket2.insertRecord(inner_tuple.returnTupleByteArray());
                    } else if ((inner_tuple.getFloFld(join_attr_2.offset) * 10000) % 4 == 2) {
                        innerbucket3.insertRecord(inner_tuple.returnTupleByteArray());
                    } else if ((inner_tuple.getFloFld(join_attr_2.offset) * 10000) % 4 == 3) {
                        innerbucket4.insertRecord(inner_tuple.returnTupleByteArray());
                    }
                } else if (in2[join_attr_2.offset - 1].attrType == AttrType.attrInteger) {

                    if (inner_tuple.getIntFld(join_attr_2.offset) % 4 == 0) {
                        innerbucket1.insertRecord(inner_tuple.returnTupleByteArray());
                    } else if (inner_tuple.getIntFld(join_attr_2.offset) % 4 == 1) {
                        innerbucket2.insertRecord(inner_tuple.returnTupleByteArray());
                    } else if (inner_tuple.getIntFld(join_attr_2.offset) % 4 == 2) {
                        innerbucket3.insertRecord(inner_tuple.returnTupleByteArray());
                    } else if (inner_tuple.getIntFld(join_attr_2.offset) % 4 == 3) {
                        innerbucket4.insertRecord(inner_tuple.returnTupleByteArray());
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        // clean up
        try {
            inner.closescan();
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        AttrType[] x = new AttrType[6];
        x[0] = new AttrType(AttrType.attrReal);
        x[1] = new AttrType(AttrType.attrReal);
        x[2] = new AttrType(AttrType.attrReal);
        x[3] = new AttrType(AttrType.attrReal);
        x[4] = new AttrType(AttrType.attrReal);
        x[5] = new AttrType(AttrType.attrReal);

        for (int i = 0; i < 4; i++) {
            
            String one = "outerbucket" + (i + 1);
            String two = "innerbucket" + (i + 1);

            // heapfile for outer relation
            Heapfile out = null;
            try {
                out = new Heapfile(one);
            } catch (Exception e) {
                e.printStackTrace();
            }
            
            if (out.getRecCnt() > 0) {
                // to create index file on outer relation
                Iterator am = null;

                IndexType b_index = new IndexType(IndexType.B_Index);

                // scan on the heapfile for outer relation
                Scan out_sc = null;
                try {
                    out_sc = new Scan(out);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                // create the index file
                BTreeFile btf = null;
                try {
                    btf = new BTreeFile("BTreeFile", in1[join_attr_1.offset - 1].attrType, 4, 1);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                RID rid = new RID();
                float key = 0;
                Tuple temp = new Tuple();
                try {
                    temp.setHdr((short) len_in1, in1, t1_str_sizes);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                temp = new Tuple(temp.size());

                try {
                    temp.setHdr((short) len_in1, in1, t1_str_sizes);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                try {
                    temp.tupleCopy(out_sc.getNext(rid));
                } catch (Exception e) {
                    if (out_sc == null) {
                        break;
                    }
                    e.printStackTrace();
                }
                count = 1;
                while (count < out.getRecCnt()) {
                    count++;
                    try {
                        temp.setHdr((short) len_in1, in1, t1_str_sizes);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    temp = new Tuple(temp.size());

                    try {
                        temp.setHdr((short) len_in1, in1, t1_str_sizes);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    temp.tupleCopy(out_sc.getNext(rid));

                    try {
                        if (in1[join_attr_1.offset - 1].attrType == AttrType.attrInteger) {
                            key = (float) temp.getIntFld(join_attr_1.offset);
                        } else if (in1[join_attr_1.offset - 1].attrType == AttrType.attrReal) {
                            key = temp.getFloFld(join_attr_1.offset);
                        } else {
                            String str = temp.getStrFld(join_attr_1.offset);
                            key = 0;
                            for (int k = 0; k < str.length(); k++) {
                                key += str.charAt(k);
                            }
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    try {
                        btf.insert(new FloatKey(key), rid);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

                // close the file scan
                out_sc.closescan();

                FldSpec[] projlist1 = new FldSpec[in1.length];
                RelSpec rel = new RelSpec(RelSpec.outer);
                for (int m = 0; m < in1.length; m++) {
                    projlist1[m] = new FldSpec(rel, m + 1);
                }

                try {
                    am = new IndexScan(new IndexType(IndexType.B_Index), one, "BTreeFile", in1, t1_str_sizes,
                            in1.length, in1.length, projlist1, null, join_attr_1.offset, false);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                NestedLoopsJoins nlj = null;
                try {
                    nlj = new NestedLoopsJoins(in1, len_in1, t1_str_sizes, in2, len_in2, t2_str_sizes, n_pages, am, two,
                            outFilter, rightFilter, proj_list, len_in1 + len_in2);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                try {
                    temp.setHdr((short) x.length, x, t1_str_sizes);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                temp = new Tuple(temp.size());

                try {
                    temp.setHdr((short) x.length, x, t1_str_sizes);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                try {
                    temp = nlj.get_next();
                    hashjoin_heapfile.insertRecord(new Tuple(temp).returnTupleByteArray());
                } catch (Exception e) {
                    e.printStackTrace();
                }

                while (temp != null) {
                    try {
                        
                        hashjoin_heapfile.insertRecord(new Tuple(temp).returnTupleByteArray());
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                    try {
                        try {
                            temp.setHdr((short) x.length, x, t1_str_sizes);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        temp = new Tuple(temp.size());
                        try {
                            temp.setHdr((short) x.length, x, t1_str_sizes);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        temp = nlj.get_next();
                        if (temp == null) {
                            break;
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }

        FldSpec[] projlist5 = new FldSpec[2 * in1_.length];
        RelSpec rel5 = new RelSpec(RelSpec.outer);
        for (int i = 0; i < 2 * in1_.length; i++) {
            projlist5[i] = new FldSpec(rel5, i + 1);
        }
       
        fscan_get_next = new FileScan("hashjoin", x, t1_str_sizes, (short) x.length, x.length, projlist5, null);

    }

    @Override
    public Tuple get_next() throws Exception {

        FldSpec[] projlist = new FldSpec[2 * in1_.length];
        RelSpec rel = new RelSpec(RelSpec.outer);
        // RelSpec relin = new RelSpec(RelSpec.innerRel);
        for (int i = 0; i < 2 * in1_.length; i++) {
            projlist[i] = new FldSpec(rel, i + 1);
        }

        return fscan_get_next.get_next();
    }

    @Override
    public void close() throws IOException, JoinsException, SortException {

        Heapfile x = null;
        try {
            x = new Heapfile("hashjoin");
            x.deleteFile();
        } catch (Exception e) {
        }
        fscan_get_next.close();
    }
}
