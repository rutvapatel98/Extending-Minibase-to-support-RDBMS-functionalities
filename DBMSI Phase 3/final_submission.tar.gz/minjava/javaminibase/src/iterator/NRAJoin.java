package iterator;

import heap.*;
import global.*;
import bufmgr.*;
import index.*;
import java.util.ArrayList;
import java.util.ListIterator;
import java.util.*;
import java.util.Iterator;

import java.io.*;

class Record {
    public String joinatt;
    public float low_bound_rel1 = -1;
    public float low_bound_rel2 = -1;
    public RID rid_rel1 = null;
    public RID rid_rel2 = null;

    public Record(String join_attr, float lowr1, float lowr2, RID r1, RID r2) {
        joinatt = join_attr;
        low_bound_rel1 = lowr1;
        low_bound_rel2 = lowr2;
        rid_rel1 = r1;
        rid_rel2 = r2;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }

        if (!(o instanceof Record)) {
            return false;
        }
          
        Record c = (Record) o;
        boolean ret = (low_bound_rel1 == c.low_bound_rel1) && (low_bound_rel2 == c.low_bound_rel2) && (rid_rel1.pageNo.pid == c.rid_rel1.pageNo.pid) && (rid_rel1.slotNo == c.rid_rel1.slotNo) && (rid_rel2.pageNo.pid == c.rid_rel2.pageNo.pid) && (rid_rel2.slotNo == c.rid_rel2.slotNo);
        return ret;

    }

    @Override
    public int hashCode() {
        int result;
        if(rid_rel1==null) {
            result = Objects.hash(0, 0,rid_rel2.pageNo.pid, rid_rel2.slotNo, low_bound_rel1, low_bound_rel2);
        }else if(rid_rel2 == null)
        {
            result = Objects.hash(rid_rel1.pageNo.pid, rid_rel1.slotNo,0, 0, low_bound_rel1, low_bound_rel2);
        }else
        {
            result = Objects.hash(rid_rel1.pageNo.pid, rid_rel2.pageNo.pid,rid_rel1.slotNo,rid_rel2.slotNo, low_bound_rel1, low_bound_rel2);
        }
        return result;
    }}
public class NRAJoin extends iterator.Iterator {
    private AttrType _in1[], _in2[];
    private int in1_len, in2_len;
    private short str2[];
    private short str1[];
    private int _npages; // # of buffer pages available.
    private Tuple outer_ele, inner_ele;
    private Tuple Jtuple; // Joined tuple
    private int _K;
    private float threshold = 0;
    private int _join_attr1;
    private int _merge_attr1;
    private int _join_attr2;
    private int _merge_attr2;
    private Sort sort_rel1;
    private Sort sort_rel2;
    private FldSpec projList[];
    private Heapfile temp_file;
    private ArrayList<Record> record_list = new ArrayList<Record>();
    private ArrayList<ArrayList<Float>> lowerval = new ArrayList();
    private int count_k = 0;
    private boolean duplicate = false;
    private ListIterator<ArrayList<Float>> iterate;
    private int count_get_next = 0;
    private AttrType[] Jtypes;
    private HashMap<String, String> map = new HashMap<>();


    public NRAJoin(AttrType in1[], int len_in1, short t1str1[], AttrType in2[], int len_in2, short t2str2[],
            int npages, String relation1, String relation2, FldSpec join_attr1, FldSpec merge_attr1,
            FldSpec join_attr2, FldSpec merge_attr2, int k)
            throws SortException, UnknowAttrType, LowMemException, JoinsException, Exception {

        _in1 = in1;
        _in2 = in2;
        _join_attr1 = join_attr1.offset - 1;
        _merge_attr1 = merge_attr1.offset - 1;
        _join_attr2 = join_attr2.offset - 1;
        _merge_attr2 = merge_attr2.offset - 1;
        System.arraycopy(in1, 0, _in1, 0, in1.length);
        System.arraycopy(in2, 0, _in2, 0, in2.length);
        in1_len = len_in1;
        in2_len = len_in2;
        _K = k;
        TupleOrder[] tupleorder = new TupleOrder[2];
        tupleorder[0] = new TupleOrder(TupleOrder.Ascending);
        tupleorder[1] = new TupleOrder(TupleOrder.Descending);
        projList = new FldSpec[in1_len + in2_len];
        str1 = t1str1;
        str2 = t2str2;
        inner_ele = new Tuple();
        Jtuple = new Tuple();
        _npages = npages;
        Jtypes = new AttrType[len_in1 + len_in2];
        short[] t_size;
        temp_file = new Heapfile("NRAJoin");

        short REC_LEN1 = 32;
        FileScan am1 = null;
        FileScan am2 = null;
        FldSpec[] SProj = new FldSpec[in1_len];
        for (int i = 0; i < len_in1; i++) {
            projList[i] = new FldSpec(new RelSpec(RelSpec.outer), i + 1);
            SProj[i] = new FldSpec(new RelSpec(RelSpec.outer), i + 1);
        }
        FldSpec[] SProj1 = new FldSpec[in2_len];
        for (int i = 0; i < in2_len; i++) {
            projList[i + in1_len] = new FldSpec(new RelSpec(RelSpec.innerRel), i + 1);
            SProj1[i] = new FldSpec(new RelSpec(RelSpec.innerRel), i + 1);
        }
        try {
            am1 = new FileScan(relation1, _in1, str1, (short) len_in1, (short) len_in1, SProj,
                    null);
        } catch (Exception e) {
            System.err.println("" + e);
        }
        try {
            am2 = new FileScan(relation2, _in2, str2, (short) len_in2, (short) len_in2, SProj,
                    null);
        } catch (Exception e) {
            System.err.println("" + e);
        }

        sort_rel1 = null;
        try {
            sort_rel1 = new Sort(in1, (short) in1_len, str1, am1, _merge_attr1 + 1, tupleorder[1], REC_LEN1, 12);
        } catch (Exception e) {
            e.printStackTrace();
        }

        sort_rel2 = null;
        try {
            sort_rel2 = new Sort(in2, (short) in2_len, str2, am2, _merge_attr2 + 1, tupleorder[1], REC_LEN1, 12);
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            t_size = TupleUtils.setup_op_tuple(Jtuple, Jtypes, in1, len_in1, in2, len_in2, t1str1, t2str2,
                    projList, in1_len + in2_len);
        } catch (TupleUtilsException e) {
            throw new NestedLoopException(e, "Error");
        }

        outer_ele = sort_rel1.get_next();
        inner_ele = sort_rel2.get_next();
        if ((_in1[_merge_attr1].attrType == AttrType.attrString)
                || (_in2[_merge_attr2].attrType == AttrType.attrString)) {
            throw new Exception(" Merge attributes should not be strings");
        }

        while ((inner_ele != null) && (outer_ele != null)) {
            float thres1 = 0;
            float thres2 = 0;
            if (_in1[_merge_attr1].attrType == AttrType.attrInteger) {
                thres1 += outer_ele.getIntFld(_merge_attr1 + 1);
            } else {
                thres1 += outer_ele.getFloFld(_merge_attr1 + 1);
            }
            if (_in2[_merge_attr2].attrType == AttrType.attrInteger) {
                thres2 += inner_ele.getIntFld(_merge_attr2 + 1);
            } else {
                thres2 += inner_ele.getFloFld(_merge_attr2 + 1);
            }
            threshold = thres1 + thres2;
            if (_in1[_join_attr1].attrType == AttrType.attrString) {
                updateTable(outer_ele.getStrFld(_join_attr1 + 1), 1, thres1,
                        temp_file.insertRecord(new Tuple(outer_ele).returnTupleByteArray()));
            } else if (_in1[_join_attr1].attrType == AttrType.attrReal) {
                updateTable(String.valueOf(outer_ele.getFloFld(_join_attr1 + 1)), 1, thres1,
                        temp_file.insertRecord(new Tuple(outer_ele).returnTupleByteArray()));
            } else {
                updateTable(String.valueOf(outer_ele.getIntFld(_join_attr1 + 1)), 1, thres1,
                        temp_file.insertRecord(new Tuple(outer_ele).returnTupleByteArray()));
            }

            if (_in2[_join_attr2].attrType == AttrType.attrString) {
                updateTable(inner_ele.getStrFld(_join_attr2 + 1), 2, thres2,
                        temp_file.insertRecord(new Tuple(inner_ele).returnTupleByteArray()));
            } else if (_in1[_join_attr2].attrType == AttrType.attrReal) {
                updateTable(String.valueOf(inner_ele.getFloFld(_join_attr2 + 1)), 2, thres2,
                        temp_file.insertRecord(new Tuple(inner_ele).returnTupleByteArray()));
            } else {
                updateTable(String.valueOf(inner_ele.getIntFld(_join_attr2 + 1)), 2, thres2,
                        temp_file.insertRecord(new Tuple(inner_ele).returnTupleByteArray()));
            }
            // get_count
            if (get_count() >= _K && !duplicate){
                break;
            }
            outer_ele = sort_rel1.get_next();
            inner_ele = sort_rel2.get_next();
        }

        Collections.sort(lowerval, new Comparator<ArrayList<Float>>() {
            @Override

            public int compare(ArrayList<Float> o1, ArrayList<Float> o2) {
                int compare = o1.get(0).compareTo(o2.get(0));
                return compare * (-1);

            }
        });

        iterate = lowerval.listIterator();
    }


    private void updateTable(String join_attr, int rel, float merge_value, RID r1) {
        Set<Record> add_records = new HashSet<Record>();
        Record tuplerec = null;
        Record rec;
        boolean found = false;
        int count = -1;
        if (record_list.isEmpty()) {
            if (rel == 1) {
                tuplerec = new Record(join_attr, merge_value, -1, r1, null);
            } else {
                tuplerec = new Record(join_attr, -1, merge_value, null, r1);
            }

            record_list.add(tuplerec);
            ArrayList<Float> temp = new ArrayList();
            temp.add(merge_value);
            temp.add((float) 0);
            lowerval.add(temp);
            map.put(join_attr, "");
        } else {
            ListIterator<Record> iterate = record_list.listIterator();
            if (map.containsKey(join_attr)) {
                while (iterate.hasNext()) {
                    count += 1;
                    rec = iterate.next();
                    if (rec.joinatt.equals(join_attr)) {
                        found = true;
                        if (rel == 1) {
                            if (rec.low_bound_rel1 == -1) {
                                rec.low_bound_rel1 = merge_value;
                                rec.rid_rel1 = r1;
                                lowerval.get(count).set(1, rec.low_bound_rel1 + rec.low_bound_rel2);
                                break;
                            } else {
                                duplicate = true;
                                if (rec.low_bound_rel2 != -1) {
                                    add_records.add(new Record(join_attr, merge_value, rec.low_bound_rel2, r1,
                                            rec.rid_rel2));
                                } else {
                                    add_records.add(new Record(join_attr, merge_value, rec.low_bound_rel2, r1,
                                            rec.rid_rel2));
                                    break;
                                }

                            }
                        } else {
                            if (rec.low_bound_rel2 == -1) {
                                rec.low_bound_rel2 = merge_value;
                                rec.rid_rel2 = r1;
                                lowerval.get(count).set(0, rec.low_bound_rel1 + rec.low_bound_rel2);
                                break;
                            } else {
                                duplicate = true;
                                if (rec.low_bound_rel1 != -1) {
                                    add_records.add(new Record(join_attr, rec.low_bound_rel1, merge_value,
                                            rec.rid_rel1, r1));
                                } else {
                                    add_records.add(new Record(join_attr, rec.low_bound_rel1, merge_value,
                                            rec.rid_rel1, r1));
                                    break;
                                }

                            }
                        }
                    }
                }
            }
        }
        Iterator<Record> it = add_records.iterator();
        while(it.hasNext()){
            Record test_r = it.next();
            ArrayList<Float> temp = new ArrayList();
            if(test_r.low_bound_rel1 == -1)
            {
                temp.add(test_r.low_bound_rel2);
            }else if(test_r.low_bound_rel2 == -1)
            {
                temp.add(test_r.low_bound_rel1);
            }else
            {
                temp.add(test_r.low_bound_rel1 + test_r.low_bound_rel2);
            }
            temp.add((float) lowerval.size() - 1);
            lowerval.add(temp);
            record_list.add(test_r);
        }
        if (!found) {
            if (rel == 1) {
                tuplerec = new Record(join_attr, merge_value, -1, r1, null);
            } else {
                tuplerec = new Record(join_attr, -1, merge_value, null, r1);
            }
            record_list.add(tuplerec);
            ArrayList<Float> temp = new ArrayList();
            temp.add(merge_value);
            temp.add((float) lowerval.size());
            map.put(join_attr, "");
            lowerval.add(temp);
        }
    }

    private int get_count() {
        ListIterator<ArrayList<Float>> iterator = lowerval.listIterator();
        int check_count = 0;
        while (iterator.hasNext()) {
            ArrayList<Float> r = iterator.next();
            if (r.get(0) >= threshold) {
                check_count += 1;
            }

        }
        count_k = Integer.max(count_k, check_count);
        return check_count;
    }


    public Tuple get_next() throws IOException, JoinsException, IndexException, InvalidTupleSizeException,
            InvalidTypeException, PageNotReadException, TupleUtilsException, PredEvalException, SortException,
            LowMemException, UnknowAttrType, UnknownKeyTypeException, Exception {
        int ind = 0;
        if (count_k < _K) {
            System.out.println("Top K not found");
            return null;
        }
        while (iterate.hasNext()) {
            if (count_get_next == _K) {
                break;
            }

            ArrayList<Float> r = iterate.next();
            ind = Math.round(r.get(1));
            Record ret = record_list.get(ind);
            Tuple return_tuple = new Tuple(Jtuple);
            if (ret.rid_rel1 == null) {
                for (int i = 0; i < in1_len; i++) {
                    if (_in1[i].attrType == AttrType.attrString) {
                        return_tuple.setStrFld(i + 1, "");
                    } else if (_in1[i].attrType == AttrType.attrInteger) {
                        return_tuple.setIntFld(i + 1, 0);
                    } else {
                        return_tuple.setFloFld(i + 1, (float) 0.0);
                    }
                }
            } else {
                Tuple out = temp_file.getRecord(ret.rid_rel1);
                try {
                    out.setHdr((short) in1_len, _in1, str1);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                for (int i = 0; i < in1_len; i++) {
                    if (_in1[i].attrType == AttrType.attrString) {
                        return_tuple.setStrFld(i + 1, out.getStrFld(i + 1));
                    } else if (_in1[i].attrType == AttrType.attrInteger) {
                        return_tuple.setIntFld(i + 1, out.getIntFld(i + 1));
                    } else {
                        return_tuple.setFloFld(i + 1, out.getFloFld(i + 1));
                    }
                }
            }
            if (ret.rid_rel2 == null) {
                for (int i = 0; i < in2_len; i++) {
                    if (_in2[i].attrType == AttrType.attrString) {
                        return_tuple.setStrFld(i + in1_len + 1, "");
                    } else if (_in2[i].attrType == AttrType.attrInteger) {
                        return_tuple.setIntFld(i + in1_len + 1, 0);
                    } else {
                        return_tuple.setFloFld(i + in1_len + 1, (float) 0.0);
                    }
                }
            } else {
                Tuple inner = temp_file.getRecord(ret.rid_rel2);
                try {
                    inner.setHdr((short) in2_len, _in2, str2);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                for (int i = 0; i < in2_len; i++) {
                    if (_in2[i].attrType == AttrType.attrString) {
                        return_tuple.setStrFld(i + in1_len + 1, inner.getStrFld(i + 1));
                    } else if (_in2[i].attrType == AttrType.attrInteger) {
                        return_tuple.setIntFld(i + in1_len + 1, inner.getIntFld(i + 1));
                    } else {
                        return_tuple.setFloFld(i + in1_len + 1, inner.getFloFld(i + 1));
                    }
                }
            }
            count_get_next += 1;
            return new Tuple(return_tuple);
        }

        return null;
    }

    public void close() throws IOException, SortException, FileAlreadyDeletedException, InvalidTupleSizeException, HFBufMgrException, HFDiskMgrException {
        try {
            temp_file.deleteFile();
        } catch (InvalidSlotNumberException e) {
            e.printStackTrace();
        }
        sort_rel1.close();
        sort_rel2.close();
    }
}