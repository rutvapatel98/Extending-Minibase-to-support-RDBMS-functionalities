package iterator;

import java.io.IOException;

import btree.BTreeFile;
import heap.*;
import global.*;
import index.*;

public class IndexNestedLoopJoins extends Iterator implements GlobalConst, Catalogglobal {

    AttrType[] in1_, in2_;
    int len_in1_, len_in2_;
    short[] t1_str_sizes_, t2_str_sizes_;
    int n_pages_; // # of buffer pages available.
    CondExpr[] condexpr_;

    Tuple outer_tuple, inner_tuple;
    Tuple Jtuple; // Joined tuple
    FldSpec[] perm_mat;
    int nOutFlds;

    Heapfile hf1; // file for first relation
    Heapfile hf2; // file for second relation

    String inner_index_name_;

    Scan inner;
    Scan outer;
    FileScan fscan_get_next = null;

    Heapfile final_ans = null;

    public IndexNestedLoopJoins(AttrType[] in1, int len_in1, short[] t1_str_sizes, AttrType[] in2, int len_in2,
            short[] t2_str_sizes, int n_pages, String relationName1, String relationName2, FldSpec[] proj_list,
            int n_out_flds, String inner_index_name, CondExpr[] condexpr)
            throws InvalidSlotNumberException, InvalidTupleSizeException, HFDiskMgrException, HFBufMgrException,
            IOException, FieldNumberOutOfBoundException, SpaceNotAvailableException, HFException, IndexException,
            UnknownKeyTypeException, FileScanException, TupleUtilsException, InvalidRelation {

        in1_ = in1;
        len_in1_ = len_in1;
        t1_str_sizes_ = t1_str_sizes;
        in2_ = in2;
        len_in2_ = len_in2;
        t2_str_sizes_ = t2_str_sizes;
        n_pages_ = n_pages;
        inner_index_name_ = inner_index_name;
        condexpr_ = condexpr;

        inner = null;
        outer = null;

        inner_tuple = new Tuple();
        Jtuple = new Tuple();

        AttrType[] JAttr = new AttrType[len_in1 + len_in2];
        for (int i = 0; i < len_in1 + len_in2; i++) {
            if (i < len_in1) {
                JAttr[i] = in1[i];
            } else {
                JAttr[i] = in2[i - len_in1];
            }
        }

        short[] t_size;

        perm_mat = proj_list;
        nOutFlds = n_out_flds;

        // heapfile for final ans
        try {
            final_ans = new Heapfile("final");
        } catch (Exception e) {
            e.printStackTrace();
        }

        // tuple for outer relation
        Tuple outer_Tuple = new Tuple();
        try {
            outer_Tuple.setHdr((short) len_in1, in1, t1_str_sizes);
        } catch (Exception e) {
            e.printStackTrace();
        }

        outer_Tuple = new Tuple(outer_Tuple.size());

        try {
            outer_Tuple.setHdr((short) len_in1, in1, t1_str_sizes);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // tuple for inner relation
        Tuple inner_tuple = new Tuple();
        try {
            inner_tuple.setHdr((short) len_in2, in2, t2_str_sizes);
        } catch (Exception e) {
            e.printStackTrace();
        }

        inner_tuple = new Tuple(inner_tuple.size());

        try {
            inner_tuple.setHdr((short) len_in2, in2, t2_str_sizes);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // tuple for joined result
        try {
            Jtuple.setHdr((short) (len_in1 + len_in2), JAttr, t1_str_sizes);
        } catch (Exception e) {
            e.printStackTrace();
        }

        Jtuple = new Tuple(Jtuple.size());

        try {
            Jtuple.setHdr((short) (len_in1 + len_in2), JAttr, t1_str_sizes);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // open heapfile for outer relation
        Heapfile outer_file = null;
        try {
            outer_file = new Heapfile("relation1");
        } catch (Exception e) {
            e.printStackTrace();
        }

        // open scan on the outer heapfile
        try {
            outer = outer_file.openScan();
        } catch (Exception e) {
            e.printStackTrace();
        }

        RID rid = new RID();
        RelSpec rel = new RelSpec(RelSpec.outer);
        RelSpec relin = new RelSpec(RelSpec.innerRel);

        FldSpec[] projlist10 = new FldSpec[len_in2];
        for (int i = 0; i < len_in2; i++) {
            projlist10[i] = new FldSpec(rel, i + 1);
        }

        try {
            outer_Tuple.tupleCopy(outer.getNext(rid));

            CondExpr[] selects = new CondExpr[2];
            selects[1] = null;
            selects[0] = new CondExpr();
            selects[0].op = new AttrOperator(condexpr_[0].op.attrOperator);
            selects[0].type1 = new AttrType(AttrType.attrSymbol);
            selects[0].operand1.symbol = new FldSpec(rel, condexpr_[0].operand2.symbol.offset);

            if (in2[condexpr_[0].operand2.symbol.offset - 1].attrType == AttrType.attrInteger) {
                selects[0].type2 = new AttrType(AttrType.attrInteger);
                selects[0].operand2.integer = outer_Tuple.getIntFld(condexpr_[0].operand1.symbol.offset);
            } else if (in2[condexpr_[0].operand2.symbol.offset - 1].attrType == AttrType.attrReal) {
                selects[0].type2 = new AttrType(AttrType.attrReal);
                selects[0].operand2.real = outer_Tuple.getFloFld(condexpr_[0].operand1.symbol.offset);
            } else if (in2[condexpr_[0].operand2.symbol.offset - 1].attrType == AttrType.attrString) {
                selects[0].type2 = new AttrType(AttrType.attrString);
                selects[0].operand2.string = outer_Tuple.getStrFld(condexpr_[0].operand1.symbol.offset);
            }

            IndexScan i_scan = null;

            try {
                i_scan = new IndexScan(new IndexType(IndexType.B_Index), relationName2, inner_index_name, in2,
                        t2_str_sizes, in2.length, in2.length, projlist10, selects, selects[0].operand1.symbol.offset,
                        false);
            } catch (Exception e) {
                e.printStackTrace();
            }

            try {
                inner_tuple.tupleCopy(i_scan.get_next());
            } catch (Exception ex) {
                ex.printStackTrace();
            }

            while (inner_tuple != null) {
                try {
                    Jtuple.setHdr((short) (len_in1 + len_in2), JAttr, t1_str_sizes);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                Jtuple = new Tuple(Jtuple.size());

                try {
                    Jtuple.setHdr((short) (len_in1 + len_in2), JAttr, t1_str_sizes);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                for (int k = 0; k < len_in1 + len_in2; k++) {
                    if (k < len_in1) {
                        if (JAttr[k].attrType == AttrType.attrInteger) {
                            Jtuple.setIntFld(k + 1, outer_Tuple.getIntFld(k + 1));
                        } else if (JAttr[k].attrType == AttrType.attrReal) {
                            Jtuple.setFloFld(k + 1, outer_Tuple.getFloFld(k + 1));
                        } else if (JAttr[k].attrType == AttrType.attrString) {
                            Jtuple.setStrFld(k + 1, outer_Tuple.getStrFld(k + 1));
                        }
                    } else {
                        if (JAttr[k].attrType == AttrType.attrInteger) {
                            Jtuple.setIntFld(k + 1, inner_tuple.getIntFld(k + 1 - len_in1));
                        } else if (JAttr[k].attrType == AttrType.attrReal) {
                            Jtuple.setFloFld(k + 1, inner_tuple.getFloFld(k + 1 - len_in1));
                        } else if (JAttr[k].attrType == AttrType.attrString) {
                            Jtuple.setStrFld(k + 1, inner_tuple.getStrFld(k + 1 - len_in1));
                        }
                    }
                }

                final_ans.insertRecord(Jtuple.returnTupleByteArray());
                try {
                    inner_tuple.setHdr((short) len_in2, in2, t2_str_sizes);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                inner_tuple = new Tuple(inner_tuple.size());

                try {
                    inner_tuple.setHdr((short) len_in2, in2, t2_str_sizes);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                inner_tuple.tupleCopy(i_scan.get_next());

                if (inner_tuple == null){
                    i_scan.close();
                    break;
                }

            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        int count = 1;
        while (count < outer_file.getRecCnt()) {
            count++;
            try {
                outer_Tuple.setHdr((short) len_in1, in1, t1_str_sizes);
            } catch (Exception e) {
                e.printStackTrace();
            }

            outer_Tuple = new Tuple(outer_Tuple.size());

            try {
                outer_Tuple.setHdr((short) len_in1, in1, t1_str_sizes);
            } catch (Exception e) {
                e.printStackTrace();
            }
            outer_Tuple.tupleCopy(outer.getNext(rid));

            CondExpr[] selects = new CondExpr[2];
            selects[1] = null;
            selects[0] = new CondExpr();
            selects[0].op = new AttrOperator(condexpr_[0].op.attrOperator);
            selects[0].type1 = new AttrType(AttrType.attrSymbol);
            selects[0].operand1.symbol = new FldSpec(rel, condexpr_[0].operand2.symbol.offset);

            if (in2[condexpr_[0].operand2.symbol.offset - 1].attrType == AttrType.attrInteger) {
                selects[0].type2 = new AttrType(AttrType.attrInteger);
                selects[0].operand2.integer = outer_Tuple.getIntFld(condexpr_[0].operand1.symbol.offset);
            } else if (in2[condexpr_[0].operand2.symbol.offset - 1].attrType == AttrType.attrReal) {
                selects[0].type2 = new AttrType(AttrType.attrReal);
                selects[0].operand2.real = outer_Tuple.getFloFld(condexpr_[0].operand1.symbol.offset);
            } else if (in2[condexpr_[0].operand2.symbol.offset - 1].attrType == AttrType.attrString) {
                selects[0].type2 = new AttrType(AttrType.attrString);
                selects[0].operand2.string = outer_Tuple.getStrFld(condexpr_[0].operand1.symbol.offset);
            }

            IndexScan i_scan = null;

            try {
                i_scan = new IndexScan(new IndexType(IndexType.B_Index), relationName2, inner_index_name, in2,
                        t2_str_sizes, in2.length, in2.length, projlist10, selects, selects[0].operand1.symbol.offset,
                        false);
            } catch (Exception e) {
                e.printStackTrace();
            }

            try {
                try {
                    inner_tuple.setHdr((short) len_in2, in2, t2_str_sizes);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                inner_tuple = new Tuple(inner_tuple.size());

                try {
                    inner_tuple.setHdr((short) len_in2, in2, t2_str_sizes);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                inner_tuple.tupleCopy(i_scan.get_next());
            } catch (Exception ex) {
                ex.printStackTrace();
            }

            while (inner_tuple != null) {
                try {
                    Jtuple.setHdr((short) (len_in1 + len_in2), JAttr, t1_str_sizes);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                Jtuple = new Tuple(Jtuple.size());

                try {
                    Jtuple.setHdr((short) (len_in1 + len_in2), JAttr, t1_str_sizes);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                for (int k = 0; k < len_in1 + len_in2; k++) {
                    if (k < len_in1) {
                        if (JAttr[k].attrType == AttrType.attrInteger) {
                            Jtuple.setIntFld(k + 1, outer_Tuple.getIntFld(k + 1));
                        } else if (JAttr[k].attrType == AttrType.attrReal) {
                            Jtuple.setFloFld(k + 1, outer_Tuple.getFloFld(k + 1));
                        } else if (JAttr[k].attrType == AttrType.attrString) {
                            Jtuple.setStrFld(k + 1, outer_Tuple.getStrFld(k + 1));
                        }
                    } else {
                        if (JAttr[k].attrType == AttrType.attrInteger) {
                            Jtuple.setIntFld(k + 1, inner_tuple.getIntFld(k + 1 - len_in1));
                        } else if (JAttr[k].attrType == AttrType.attrReal) {
                            Jtuple.setFloFld(k + 1, inner_tuple.getFloFld(k + 1 - len_in1));
                        } else if (JAttr[k].attrType == AttrType.attrString) {
                            Jtuple.setStrFld(k + 1, inner_tuple.getStrFld(k + 1 - len_in1));
                        }
                    }
                }

                final_ans.insertRecord(Jtuple.returnTupleByteArray());
                try {
                    inner_tuple.setHdr((short) len_in2, in2, t2_str_sizes);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                inner_tuple = new Tuple(inner_tuple.size());

                try {
                    inner_tuple.setHdr((short) len_in2, in2, t2_str_sizes);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                inner_tuple.tupleCopy(i_scan.get_next());
                if (inner_tuple == null){
                    i_scan.close();
                    break;
                }

            }
        }

        FldSpec[] projlist5 = new FldSpec[len_in1 + len_in2];
        RelSpec rel5 = new RelSpec(RelSpec.outer);
        for (int i = 0; i < len_in1 + len_in2; i++) {
            projlist5[i] = new FldSpec(rel5, i + 1);
        }

        fscan_get_next = new FileScan("final", JAttr, t1_str_sizes, (short) JAttr.length, JAttr.length, projlist5,
                null);

    }

    @Override
    public Tuple get_next() throws Exception {

        FldSpec[] projlist = new FldSpec[len_in1_ + len_in2_];
        RelSpec rel = new RelSpec(RelSpec.outer);
        // RelSpec relin = new RelSpec(RelSpec.innerRel);
        for (int i = 0; i < len_in1_ + len_in2_; i++) {
            projlist[i] = new FldSpec(rel, i + 1);
        }

        return fscan_get_next.get_next();
    }

    @Override
    public void close() throws IOException, JoinsException, SortException {

        Heapfile x = null;
        try {
            x = new Heapfile("final");
            x.deleteFile();
        } catch (Exception e) {
        }
        fscan_get_next.close();
    }
}
