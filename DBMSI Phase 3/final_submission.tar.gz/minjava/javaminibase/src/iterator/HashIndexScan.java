package iterator;
import global.*;
import bufmgr.*;
import diskmgr.*; 
import btree.*;
import iterator.*;
import heap.*;
import index.IndexException;
import index.UnknownIndexTypeException;

import java.io.*;

import org.w3c.dom.Attr;


/**
 * Index Scan iterator will directly access the required tuple using
 * the provided key. It will also perform selections and projections.
 * information about the tuples and the index are passed to the constructor,
 * then the user calls <code>get_next()</code> to get the tuples.
 */
public class HashIndexScan extends Iterator {

  /**
   * class constructor. set up the index scan.
   * @param index type of the index (B_Index, Hash)
   * @param relName name of the input relation
   * @param indName name of the input index
   * @param types array of types in this relation
   * @param str_sizes array of string sizes (for attributes that are string)
   * @param noInFlds number of fields in input tuple
   * @param noOutFlds number of fields in output tuple
   * @param outFlds fields to project
   * @param selects conditions to apply, first one is primary
   * @param fldNum field number of the indexed field
   * @param indexOnly whether the answer requires only the key or the tuple
   * @exception IndexException error from the lower layer
   * @exception InvalidTypeException tuple type not valid
   * @exception InvalidTupleSizeException tuple size not valid
   * @exception UnknownIndexTypeException index type unknown
   * @exception IOException from the lower layer
   */

       //for the iterator
       String maindirectory = null;
       Tuple maintuple = new Tuple();
       Tuple firstleveltuple = new Tuple();
       Tuple secondleveltuple = new Tuple();
       String firstheapfile = null;
       int finalpageid = 0;
       int count =0;
       Boolean page_not_full = true;
       Boolean firstime = true;
       RID riddatafile = new RID();
       int num_cols = 2;
       int num_cols3 = 3;
       short[] Psizes = {};
       short[] stringsize = new short[2];
       short[] str_size = new short[1];

       AttrType[] attr;
       AttrType[] attr2;
       AttrType[] attr_uc_last;
       AttrType[] attr_uc_mid;
       RID secondlevelrid = new RID();
       Scan scansecondlevelhf;
       Heapfile secondlevelhf;
       Heapfile firstlevelhf;
       Boolean firsttimefirstlevel = true;
       Scan scanfirstlevelhf;
       RID firstlevelrid;
       Boolean firsttimemaindirectory = true;
       Heapfile mainhf;
       Scan scanmainhf;
       RID mainrid;
       int pageId;
       int slotNo;
       String datafilename;
        int equalityKey;
        String equalityValue;    
        int equalityValueint;
        AttrType[] typesattr;
  public HashIndexScan(
	   final String  _datafilename,  
	   final String  indexfilename,  
       AttrType      types[],
       final String  _tableName,
        int _key, 
        int _equalityKey,
        String _equalityValue
	//    short         str_sizes[],     
	//    int           noInFlds,          
	//    int           noOutFlds,         
	//    FldSpec       outFlds[],     
	//    CondExpr      selects[],  
	//    final int     fldNum,
	//    final boolean indexOnly
	   ) 
    throws IndexException, 
	   InvalidTypeException,
	   InvalidTupleSizeException,
	   UnknownIndexTypeException,
	   IOException
  {
      tableName = _tableName;
      key = _key;
      datafilename = _datafilename;
      equalityKey = _equalityKey;
      equalityValue = _equalityValue;
      typesattr = types;
      if(types[equalityKey-1].attrType==AttrType.attrInteger)
      {
        equalityValueint = Integer.parseInt(equalityValue);
      }
      

    // _fldNum = fldNum;
    // _noInFlds = noInFlds;
    // _types = types;
    // _s_sizes = str_sizes;
    
    // AttrType[] Jtypes = new AttrType[noOutFlds];
    // short[] ts_sizes;
    // Jtuple = new Tuple();

    attr_uc_last = new AttrType[2];
    attr_uc_last[0] = new AttrType(AttrType.attrInteger);
    attr_uc_last[1] = new AttrType(AttrType.attrInteger);

    attr_uc_mid = new AttrType[2];
    attr_uc_mid[0] = new AttrType(AttrType.attrInteger);
    attr_uc_mid[1] = new AttrType(AttrType.attrString);

    attr = new AttrType[2];
    attr[0] = types[key-1];
    attr[1] = new AttrType(AttrType.attrString);

    attr2 = new AttrType[2];
    attr2[0] = types[key-1];
    attr2[1] = new AttrType(AttrType.attrInteger);
    
    stringsize[0] = 64;
    stringsize[1] = 64;

    str_size[0]=128;
    // try {
    //   ts_sizes = TupleUtils.setup_op_tuple(Jtuple, Jtypes, types, noInFlds, str_sizes, outFlds, noOutFlds);
    // }
    // catch (TupleUtilsException e) {
    //   throw new IndexException(e, "IndexScan.java: TupleUtilsException caught from TupleUtils.setup_op_tuple()");
    // }
    // catch (InvalidRelation e) {
    //   throw new IndexException(e, "IndexScan.java: InvalidRelation caught from TupleUtils.setup_op_tuple()");
    // }
     
    // _selects = selects;
    // perm_mat = outFlds;
    // _noOutFlds = noOutFlds;
    // tuple1 = new Tuple();    
    // try {
    //   tuple1.setHdr((short) noInFlds, types, str_sizes);
    // }
    // catch (Exception e) {
    //   throw new IndexException(e, "IndexScan.java: Heapfile error");
    // }
    
    // t1_size = tuple1.size();
    // index_only = indexOnly;  // added by bingjie miao
    
    // try {
    //   f = new Heapfile(relName);
    // }
    // catch (Exception e) {
    //   throw new IndexException(e, "IndexScan.java: Heapfile not created");
    // }
    
    // switch(index.indexType) {
    //   // linear hashing is not yet implemented
    // case IndexType.B_Index:
    //   // error check the select condition
    //   // must be of the type: value op symbol || symbol op value
    //   // but not symbol op symbol || value op value
    //   try {
	// indFile = new BTreeFile(indName); 
    //   }
    //   catch (Exception e) {
	// throw new IndexException(e, "IndexScan.java: BTreeFile exceptions caught from BTreeFile constructor");
    //   }
      
    //   try {
	// indScan = (BTFileScan) IndexUtils.BTree_scan(selects, indFile);
    //   }
    //   catch (Exception e) {
	// throw new IndexException(e, "IndexScan.java: BTreeFile exceptions caught from IndexUtils.BTree_scan().");
    //   }
      
    //   break;
    // case IndexType.None:
    // default:
    //   throw new UnknownIndexTypeException("Only BTree index is supported so far");
      
    // }
    
  }
  
  /**
   * returns the next tuple.
   * if <code>index_only</code>, only returns the key value 
   * (as the first field in a tuple)
   * otherwise, retrive the tuple and returns the whole tuple
   * @return the tuple
   * @exception IndexException error from the lower layer
   * @exception UnknownKeyTypeException key type unknown
   * @exception IOException from the lower layer
 * @throws HFDiskMgrException
 * @throws HFBufMgrException
 * @throws HFException
 * @throws FieldNumberOutOfBoundException
 * @throws InvalidTupleSizeException
 * @throws BufMgrException
 * @throws PagePinnedException
 * @throws BufferPoolExceededException
 * @throws PageNotReadException
 * @throws InvalidFrameNumberException
 * @throws PageUnpinnedException
 * @throws HashOperationException
 * @throws ReplacerException
 * @throws InvalidSlotNumberException
   */
  public Tuple get_next() 
    throws IndexException, 
	   UnknownKeyTypeException,
	   IOException, HFException, HFBufMgrException, HFDiskMgrException, FieldNumberOutOfBoundException, InvalidTupleSizeException, ReplacerException, HashOperationException, PageUnpinnedException, InvalidFrameNumberException, PageNotReadException, BufferPoolExceededException, PagePinnedException, BufMgrException, InvalidSlotNumberException
  {
        if(maindirectory == null)
        {
            if(firsttimemaindirectory == true)
            {
                 mainhf = new Heapfile("clusteredhash"+tableName+key);
                 scanmainhf = new Scan(mainhf);
                 mainrid = new RID();
                try {
                    maintuple.setHdr((short) num_cols, attr_uc_mid, stringsize);
                } catch (Exception e) {
                    System.out.println(e);
                }
                maintuple = scanmainhf.getNext(mainrid);
                try {
                    maintuple.setHdr((short) num_cols, attr_uc_mid, stringsize);
                } catch (Exception e) {
                    System.out.println(e);
                }
                firsttimemaindirectory = false; 
            }
            else{
                maintuple = scanmainhf.getNext(mainrid);
                if(maintuple==null)
                {
                    return null;
                }
                try {
                    maintuple.setHdr((short) num_cols, attr_uc_mid, stringsize);
                } catch (Exception e) {
                    System.out.println(e);
                }
                try {
                    maintuple.setHdr((short) num_cols, attr_uc_mid, stringsize);
                } catch (Exception e) {
                    System.out.println(e);
                }
            }
            maindirectory = maintuple.getStrFld(2);
            return get_next();
        }
        else if(firstheapfile == null)
        {
            if(firsttimefirstlevel)
            {
                firstlevelhf = new Heapfile(maindirectory);
                scanfirstlevelhf = new Scan(firstlevelhf);
                 firstlevelrid = new RID();
                firstleveltuple = scanfirstlevelhf.getNext(firstlevelrid);
                try {
                    firstleveltuple.setHdr((short) num_cols, attr, stringsize);
                } catch (Exception e) {
                    System.out.println(e);
                }
                try {
                    firstleveltuple.setHdr((short) num_cols, attr, stringsize);
                } catch (Exception e) {
                    System.out.println(e);
                }
                firsttimefirstlevel = false;
            }
            else{
                firstleveltuple = scanfirstlevelhf.getNext(firstlevelrid);
                if(firstleveltuple==null)
                {
                maindirectory = null; 
                firsttimefirstlevel = true;
                return get_next();
                }
                try {
                    firstleveltuple.setHdr((short) num_cols, attr, stringsize);
                } catch (Exception e) {
                    System.out.println(e);
                }
                try {
                    firstleveltuple.setHdr((short) num_cols, attr, stringsize);
                } catch (Exception e) {
                    System.out.println(e);
                }
            }
            
            if(firstleveltuple==null)
            {
                maindirectory = null; 
                firsttimefirstlevel = true;
                return get_next();
            }
            firstheapfile = firstleveltuple.getStrFld(2);
            return get_next();
        }
        else{
            if(firstime)
            {
                secondlevelhf = new Heapfile(firstheapfile);
                scansecondlevelhf = new Scan(secondlevelhf);
                secondleveltuple = scansecondlevelhf.getNext(secondlevelrid);
                try {
                    secondleveltuple.setHdr((short) num_cols, attr2, stringsize);
                } catch (Exception e) {
                    System.out.println(e);
                }
                page_not_full = true;
            }
            if(!page_not_full){
            secondleveltuple = scansecondlevelhf.getNext(secondlevelrid);
            if(secondleveltuple==null)
            {
                firstheapfile = null;
                firstime = true;
                return get_next();
            }
            try {
                secondleveltuple.setHdr((short) num_cols, attr2, stringsize);
            } catch (Exception e) {
                System.out.println(e);
            }
            
            try {
                secondleveltuple.setHdr((short) num_cols, attr2, stringsize);
            } catch (Exception e) {
                System.out.println(e);
            }
            }
            try {
                secondleveltuple.setHdr((short) num_cols, attr2, stringsize);
            } catch (Exception e) {
                System.out.println(e);
            }
            int count = 0;
            finalpageid = secondleveltuple.getIntFld(2);
            //search the datafile
            Heapfile        datafilehf = null; //heapfile that stores all the tuples 
            datafilehf = new Heapfile(datafilename);
            Tuple dftuple = new Tuple();
            RID dfrid = new RID();
            Scan dfscan = new Scan(datafilehf);
            Page page = new Page();
            SystemDefs.JavabaseBM.pinPage(new PageId(finalpageid), page, false);
            HFPage hfpage = new HFPage(page);
            if(firstime)
            {
                riddatafile = hfpage.firstRecord();
                firstime = false;
                //page_not_full = false;
                return hfpage.getRecord(riddatafile); 
            }
            else{
                if(page_not_full)
                {
                    riddatafile = hfpage.nextRecord(riddatafile);
                    if(riddatafile==null)
                    {
                        page_not_full = false;
                        return get_next();

                    }
                    return hfpage.getRecord(riddatafile);
                }
            }
        }
        return null;
  }

  public Tuple get_next_unclustered() 
  throws Exception
{
      if(maindirectory == null)
      {
          if(firsttimemaindirectory == true)
          {
               mainhf = new Heapfile("unclusteredhash"+tableName+key);
               scanmainhf = new Scan(mainhf);
               mainrid = new RID();
              try {
                  maintuple.setHdr((short) num_cols, attr, stringsize);
              } catch (Exception e) {
                  System.out.println(e);
              }
              maintuple = scanmainhf.getNext(mainrid);
              try {
                  maintuple.setHdr((short) num_cols, attr, stringsize);
              } catch (Exception e) {
                  System.out.println(e);
              }
              firsttimemaindirectory = false; 
          }
          else{
              maintuple = scanmainhf.getNext(mainrid);
              if(maintuple==null)
              {
                  return null;
              }
              try {
                  maintuple.setHdr((short) num_cols, attr, stringsize);
              } catch (Exception e) {
                  System.out.println(e);
              }
              try {
                  maintuple.setHdr((short) num_cols, attr, stringsize);
              } catch (Exception e) {
                  System.out.println(e);
              }
          }
          try {
            maintuple.setHdr((short) num_cols, attr, stringsize);
        } catch (Exception e) {
            System.out.println(e);
        }
          maintuple.print(attr_uc_mid);
          try {
            maintuple.setHdr((short) num_cols, attr_uc_mid, stringsize);
        } catch (Exception e) {
            System.out.println(e);
        }
          maindirectory = maintuple.getStrFld(2);
          return get_next_unclustered();
      }
      else if(firstheapfile == null)
      {
          if(firsttimefirstlevel)
          {
              firstlevelhf = new Heapfile(maindirectory);
              scanfirstlevelhf = new Scan(firstlevelhf);
               firstlevelrid = new RID();
              firstleveltuple = scanfirstlevelhf.getNext(firstlevelrid);
              try {
                  firstleveltuple.setHdr((short) num_cols, attr, stringsize);
              } catch (Exception e) {
                  System.out.println(e);
              }
              try {
                  firstleveltuple.setHdr((short) num_cols, attr, stringsize);
              } catch (Exception e) {
                  System.out.println(e);
              }
              firsttimefirstlevel = false;
          }
          else{
              firstleveltuple = scanfirstlevelhf.getNext(firstlevelrid);
              if(firstleveltuple==null)
              {
              maindirectory = null; 
              firsttimefirstlevel = true;
              return get_next_unclustered();
              }
              try {
                  firstleveltuple.setHdr((short) num_cols, attr, stringsize);
              } catch (Exception e) {
                  System.out.println(e);
              }
          }
          
          if(firstleveltuple==null)
          {
              maindirectory = null; 
              firsttimefirstlevel = true;
              return get_next_unclustered();
          }
          firstheapfile = firstleveltuple.getStrFld(2);
          return get_next_unclustered();
      }
    else{
        if(firstime)
        {
            secondlevelhf = new Heapfile(firstheapfile);
            scansecondlevelhf = new Scan(secondlevelhf);
            secondleveltuple = scansecondlevelhf.getNext(secondlevelrid);
            try {
                secondleveltuple.setHdr((short) num_cols, attr_uc_last, Psizes);
            } catch (Exception e) {
                System.out.println(e);
            }
        }
        if(!firstime){
        secondleveltuple = scansecondlevelhf.getNext(secondlevelrid);
        if(secondleveltuple==null)
        {
            firstheapfile = null;
            firstime = true;
            return get_next_unclustered();
        }
        try {
            secondleveltuple.setHdr((short) num_cols, attr_uc_last, stringsize);
        } catch (Exception e) {
            System.out.println(e);
        }
        }
        try {
            secondleveltuple.setHdr((short) num_cols, attr_uc_last, stringsize);
        } catch (Exception e) {
            System.out.println(e);
        }
        int count = 0;
        slotNo = secondleveltuple.getIntFld(1);
        pageId = secondleveltuple.getIntFld(2);

        //search the datafile
        Heapfile        datafilehf = null; //heapfile that stores all the tuples 
        datafilehf = new Heapfile(datafilename);
        RID rid_get = new RID();
        rid_get.pageNo.pid = pageId;
        rid_get.slotNo = slotNo;
            if(firstime)
            firstime = false;

            return datafilehf.getRecord(rid_get); 
    }

}
  
  public Tuple get_next_withKey_unclustered() throws InvalidSlotNumberException, Exception
    {
        if(firstime)
        {
            if(typesattr[equalityKey-1].attrType==AttrType.attrInteger)
            secondlevelhf = new Heapfile("unclusteredhash"+tableName+key+"key"+"_"+String.valueOf(equalityValueint));
            else
            secondlevelhf = new Heapfile("unclusteredhash"+tableName+key+"key"+"_"+equalityValue);

            if(secondlevelhf.getRecCnt()==0)
                return null;  

            scansecondlevelhf = new Scan(secondlevelhf);
            secondleveltuple = scansecondlevelhf.getNext(secondlevelrid);
            try {
                secondleveltuple.setHdr((short) num_cols, attr_uc_last, Psizes);
            } catch (Exception e) {
                System.out.println(e);
            }
        }
        if(!firstime){
        secondleveltuple = scansecondlevelhf.getNext(secondlevelrid);
        if(secondleveltuple==null)
        {
            firstheapfile = null;
            return null;
        }
        try {
            secondleveltuple.setHdr((short) num_cols, attr_uc_last, stringsize);
        } catch (Exception e) {
            System.out.println(e);
        }
        }
        try {
            secondleveltuple.setHdr((short) num_cols, attr_uc_last, stringsize);
        } catch (Exception e) {
            System.out.println(e);
        }
        int count = 0;
        slotNo = secondleveltuple.getIntFld(1);
        pageId = secondleveltuple.getIntFld(2);

        //search the datafile
        Heapfile        datafilehf = null; //heapfile that stores all the tuples 
        datafilehf = new Heapfile(datafilename);
        RID rid_get = new RID();
        rid_get.pageNo.pid = pageId;
        rid_get.slotNo = slotNo;
            if(firstime)
            firstime = false;

            return datafilehf.getRecord(rid_get); 
    }

    public Tuple get_next_withKey_clustered() throws InvalidTupleSizeException, IOException, FieldNumberOutOfBoundException, ReplacerException, HashOperationException, PageUnpinnedException, InvalidFrameNumberException, PageNotReadException, BufferPoolExceededException, PagePinnedException, BufMgrException, InvalidSlotNumberException, HFException, HFBufMgrException, HFDiskMgrException
    {
        if(firstime)
        {
            if(typesattr[equalityKey-1].attrType==AttrType.attrInteger)
            secondlevelhf = new Heapfile("clusteredhash"+tableName+key+"key"+"_"+String.valueOf(equalityValueint));
            else
            secondlevelhf = new Heapfile("clusteredhash"+tableName+key+"key"+"_"+equalityValue);


            if(secondlevelhf.getRecCnt()==0)
                return null;
            
            //secondlevelhf = new Heapfile(firstheapfile);
            scansecondlevelhf = new Scan(secondlevelhf);
            secondleveltuple = scansecondlevelhf.getNext(secondlevelrid);
            try {
                secondleveltuple.setHdr((short) num_cols, attr2, stringsize);
            } catch (Exception e) {
                System.out.println(e);
            }
            page_not_full = true;
        }
        if(!page_not_full){
        secondleveltuple = scansecondlevelhf.getNext(secondlevelrid);


        if(secondleveltuple==null)
        {
            firstheapfile = null;
            // firstime = true;
            return get_next_withKey_clustered();
        }
        try {
            secondleveltuple.setHdr((short) num_cols, attr2, stringsize);
        } catch (Exception e) {
            System.out.println(e);
        }
        }
        try {
            secondleveltuple.setHdr((short) num_cols, attr2, stringsize);
        } catch (Exception e) {
            System.out.println(e);
        }
        int count = 0;
        finalpageid = secondleveltuple.getIntFld(2);
        //search the datafile
        Heapfile        datafilehf = null; //heapfile that stores all the tuples 
        datafilehf = new Heapfile(datafilename);
        Tuple dftuple = new Tuple();
        RID dfrid = new RID();
        Scan dfscan = new Scan(datafilehf);
        Page page = new Page();
        SystemDefs.JavabaseBM.pinPage(new PageId(finalpageid), page, false);
        HFPage hfpage = new HFPage(page);
        if(firstime)
        {
            riddatafile = hfpage.firstRecord();
            firstime = false;
            //page_not_full = false;
            return hfpage.getRecord(riddatafile); 
        }
        else{
            if(page_not_full)
            {
                riddatafile = hfpage.nextRecord(riddatafile);
                if(riddatafile==null)
                {
                    //page_not_full = false;
                    return null;
                }
                return hfpage.getRecord(riddatafile);
            }
        }
        return null;
    }

  /**
   * Cleaning up the index scan, does not remove either the original
   * relation or the index from the database.
   * @exception IndexException error from the lower layer
   * @exception IOException from the lower layer
   */
  public void close() throws IOException, IndexException
  {
    if (!closeFlag) {
      if (indScan instanceof BTFileScan) {
	try {
	  ((BTFileScan)indScan).DestroyBTreeFileScan();
	}
	catch(Exception e) {
	  throw new IndexException(e, "BTree error in destroying index scan.");
	}
      }
      
      closeFlag = true; 
    }
  }
  
  public FldSpec[]      perm_mat;
  private IndexFile     indFile;
  private IndexFileScan indScan;
  private AttrType[]    _types;
  private short[]       _s_sizes; 
  private CondExpr[]    _selects;
  private int           _noInFlds;
  private int           _noOutFlds;
  private Heapfile      f;
  private Tuple         tuple1;
  private Tuple         Jtuple;
  private int           t1_size;
  private int           _fldNum;       
  private boolean       index_only;    
  private String        tableName;
  private int           key;

}

