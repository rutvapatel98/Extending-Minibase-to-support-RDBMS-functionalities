package iterator;

import java.io.IOException;
import java.util.ArrayList;

import bufmgr.PageNotReadException;
import global.*;
import heap.*;
import index.*;
import skyline.*;


public class BlockNestedLoopSky extends Iterator implements GlobalConst{
    
    private AttrType[]        in_;   
    private int                len_in_;    
    private short[]           t1_str_sizes_;
    private FileScan          am1_;
    private java.lang.String  relationName_;
    private int[]             pref_list_;
    private int               pref_list_length_;
    private int               n_pages_;

    FileScan fscan_get_next = null;
    byte bufs[][];

    Heapfile f = null; // input file of records
    Heapfile skyline_Heapfile = null; // heapfile to store skyline tuples

    public BlockNestedLoopSky(
        AttrType[]        in,
        int               len_in,
        short[]           t1_str_sizes,
        FileScan          am1,
        java.lang.String  relationName,
        int[]             pref_list,
        int               pref_list_length,
        int               n_pages
        )throws Exception {

        in_ = in;
        len_in_ = len_in;
        t1_str_sizes_ = t1_str_sizes;
        pref_list_ = pref_list;
        pref_list_length_ = pref_list_length;
        am1_ = am1;
        n_pages_ = n_pages;

        // heapfile which has input data
        f = new Heapfile(relationName);

        // heapfile to store the resultant skyline tuples
        skyline_Heapfile = new Heapfile("new_skyline23.in");

        FldSpec[] projlist = new FldSpec[len_in];
        RelSpec rel = new RelSpec(RelSpec.outer);

        for (int i = 0; i < len_in; i++) {
            projlist[i] = new FldSpec(rel, i + 1);
        }

        Tuple t = new Tuple(); // outer
        try {
            t.setHdr((short) len_in, in, t1_str_sizes); // outer
        } catch (Exception e) {
            e.printStackTrace();
        }

        t = new Tuple(t.size());
        try {
            t.setHdr((short) len_in, in, t1_str_sizes); // outer
        } catch (Exception e) {
            e.printStackTrace();
        }

        // buffer for finding the skyline
        //skBuf skb = new skBuf();

        // temporary heap file if the buffer is full.
        Heapfile temp = null;
        try {
            temp = new Heapfile("temp_file");
        } catch (Exception e) {
            e.printStackTrace();
        }

        bufs = new byte[n_pages][];
        for (int k = 0; k < n_pages; k++)
            bufs[k] = new byte[MAX_SPACE];

        boolean runVar = false;
        if (runVar == false) {
            //skb.init(bufs, n_pages, (int) t.size(), temp, skyline_Heapfile);
        }
        
        ArrayList<Tuple> my_buff = new ArrayList<Tuple>();

        // enter the first tuple into the buffer by default
        RID ri = new RID();
        Scan scan = null;

        //open the scan on the input heap file 
        try {
            scan = f.openScan();
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        
        try {
            t.tupleCopy(scan.getNext(ri));
            //skb.Put(t);
            my_buff.add(t);
            try {
                //ri = skyline_Heapfile.insertRecord(t.returnTupleByteArray());
            } catch (Exception e) {
                e.printStackTrace();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        int count = 1;
        // while loop is outer loop on remaining tuples
        while (count < f.getRecCnt()) {
            try {
                count++;

                try {
                    t.setHdr((short) len_in, in, t1_str_sizes);
                } catch (Exception e) {
                }

                Tuple outer_tuple = new Tuple(); // outer
                Tuple inner_tuple;
                try {
                    outer_tuple.setHdr((short) len_in, in, t1_str_sizes); // outer
                } catch (Exception e) {
                    e.printStackTrace();
                }
                outer_tuple = new Tuple(t.size());
                try {
                    t.setHdr((short) len_in, in, t1_str_sizes);
                } catch (Exception e) {
                }
                outer_tuple.tupleCopy(scan.getNext(ri));

                java.util.Iterator <Tuple> itr = my_buff.iterator();

                boolean is_quasi_skyline = true;

                while (itr.hasNext())
                {
                   
                    inner_tuple = itr.next();
                   
                    inner_tuple.setHdr((short)len_in, in, t1_str_sizes);
                    outer_tuple.setHdr((short)len_in, in, t1_str_sizes);

                    if(outer_tuple.getFloFld(1) == 1)
                    {
                        //System.out.println("in outer tuple");
                    }

                    int flag = SK.Dominates(inner_tuple, in, outer_tuple, in, (short)len_in, t1_str_sizes, pref_list, pref_list.length);
                    int flag1 = SK.Dominates(outer_tuple, in, inner_tuple, in, (short)len_in, t1_str_sizes, pref_list, pref_list.length);
                    if(flag==1){
                    //outer is dominated by inner so go to the next iteration of the outer
                    is_quasi_skyline = false;
                    break;
                    }
                    else if(flag1==1){
                    //inner tuple is dominated by outer tuple

                    //remove that tuple from the buffer
                        itr.remove();
                        // int count_t = 0;
                        // if(!itr.hasNext())
                        //     {
                        //         System.out.println(count_t);
                        //         System.out.println(outer_tuple.getFloFld(1));
                        //         count_t++;
                        //     }
                        
                    }
                
                }
                if(outer_tuple.getFloFld(1) == 1)
                {
                    System.out.println(my_buff.size());
                }
                if(my_buff.size() < (n_pages*1024)/outer_tuple.size() && is_quasi_skyline)
                {
                   
                    my_buff.add(outer_tuple);
                    
                }
                else if (is_quasi_skyline)
                {
                    RID rid;
                    try {
                        rid =  temp.insertRecord(outer_tuple.returnTupleByteArray());
                    }
                    catch (Exception e){
                        e.printStackTrace();
                        throw e;
                    }         
                }
                
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        for(int i = 0; i < my_buff.size(); i++)
        {
            Tuple temp_tuple;
            temp_tuple = my_buff.get(i);
            temp_tuple.setHdr((short)len_in, in, t1_str_sizes);

            RID rid;
            try {
                rid =  skyline_Heapfile.insertRecord(temp_tuple.returnTupleByteArray());
            }
            catch (Exception e){
                e.printStackTrace();
                throw e;
            }         

        }

        my_buff.clear();
        //TODO: insert all the tuples of buffer to skyline heapfile
        
        // create new heap file if buffer gets full
        // two heap files are enough because when one is being used the other will
        // always be empty
        // both these files are temp("temp_file") and tempone ("temp_file_one")
        Heapfile tempone = null;
        try {
            tempone = new Heapfile("temp_file_one");
        } catch (Exception e) {
            e.printStackTrace();
        }

        runVar = true;
        // the entire logic here should be in a loop until we find all the skyline
        // objects
        //System.out.println("size before:" + skyline_Heapfile.getRecCnt());
        while (runVar == true && temp.getRecCnt() > 0 || runVar == false && tempone.getRecCnt() > 0) {
            // empty the buffer for the next run
            // if (runVar == false) {
            //     skb.set_temp_fd(temp);
            // } else if (runVar == true) {
            //     skb.set_temp_fd(tempone);
            // }
            // skb.setT_wr_to_buf(0);
            // skb.setT_wr_to_pg(0);
            // skb.setCurr_page(0);
            // skb.setT_written(0);

            // scan the heap file which has the current tuples of the outer loop

            // create an scan on the heapfile conataining the data
            Scan scanner = null;

            try {
                if (runVar == true) {
                    scanner = new Scan(temp);
                } else if (runVar == false) {
                    scanner = new Scan(tempone);
                }
            } catch (Exception e) {
                e.printStackTrace();
                Runtime.getRuntime().exit(1);
            }

            RID r = new RID();
            Tuple outerT = new Tuple();
            try {
                outerT.setHdr((short) len_in, in, t1_str_sizes);
            } catch (InvalidTypeException e1) {
                e1.printStackTrace();
            }
            outerT = new Tuple(outerT.size());
            try {
                outerT.setHdr((short) len_in, in, t1_str_sizes);
            } catch (Exception e) {
            }

            // enter the first tuple into the buffer by default
            try {
                outerT.tupleCopy(scanner.getNext(r));
                //skb.Put(outerT);
                RID ri_new = new RID();
                Scan scanner_skyline = null;
                int count_heapfile = 0;

                try {
                    scanner_skyline = new Scan(skyline_Heapfile);
                }
                catch (Exception e) {
                    e.printStackTrace();
                    Runtime.getRuntime().exit(1);
                }
                boolean is_skyline_check = true;
                while (count_heapfile < skyline_Heapfile.getRecCnt())
                {
                    count_heapfile++;
                    if(count_heapfile == 2) break;
                    Tuple skyline_tuple = new Tuple(t.size());
                    try {
                        skyline_tuple.setHdr((short) len_in, in, t1_str_sizes); // outer
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    
                    skyline_tuple.tupleCopy(scanner_skyline.getNext(ri_new));
                    
                    
                    int flag = SK.Dominates(skyline_tuple, in, outerT, in, (short)len_in, t1_str_sizes, pref_list, pref_list.length);
                    if(flag==1) 
                    {
                        is_skyline_check = false;
                        break;
                    }
                }

                scanner_skyline.closescan();

                if(is_skyline_check) my_buff.add(t);

                
                try {
                    //ri = skyline_Heapfile.insertRecord(outerT.returnTupleByteArray());
                } catch (Exception e) {
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            Heapfile nextHeapfile = null;
            if (runVar == false) {
                nextHeapfile = temp;
            } else if (runVar == true) {
                nextHeapfile = tempone;
            }
     
            int count1 = 1;
           
            //System.out.println("size before:" + skyline_Heapfile.getRecCnt());
            while (count1 < temp.getRecCnt() && runVar == true || count1 < tempone.getRecCnt() && runVar == false) {
                try {
                    count1++;
                    //outerT.tupleCopy(scanner.getNext(r));
                
                    Tuple outer_tuple = new Tuple(t.size()); // outer
                    Tuple inner_tuple;
                    try {
                        outer_tuple.setHdr((short) len_in, in, t1_str_sizes); // outer
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    //outer_tuple = new Tuple();
                    try {
                        t.setHdr((short) len_in, in, t1_str_sizes);
                    } catch (Exception e) {
                    }
                    outer_tuple.tupleCopy(scanner.getNext(ri));
    
                    java.util.Iterator <Tuple> itr = my_buff.iterator();
    
                    boolean is_quasi_skyline = true;

                    boolean is_skyline_check = true;

                    RID ri_new = new RID();
                    Scan scanner_skyline = null;
                    int count_heapfile = 0;

                    try {
                        scanner_skyline = new Scan(skyline_Heapfile);
                    }
                    catch (Exception e) {
                        e.printStackTrace();
                        Runtime.getRuntime().exit(1);
                    }

                    while (count_heapfile < skyline_Heapfile.getRecCnt())
                    {
                        count_heapfile++;
                        if(count_heapfile == 2) break;
                        Tuple skyline_tuple = new Tuple(t.size());
                        try {
                            skyline_tuple.setHdr((short) len_in, in, t1_str_sizes); // outer
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                       
                        skyline_tuple.tupleCopy(scanner_skyline.getNext(ri_new));
                        //count_heapfile++;
                        int flag = SK.Dominates(skyline_tuple, in, outer_tuple, in, (short)len_in, t1_str_sizes, pref_list, pref_list.length);
                        if(flag==1) 
                        {
                            is_skyline_check = false;
                            break;
                        }
                    }

                    scanner_skyline.closescan();

                    if(!is_skyline_check) break;
                    
                    
                    while (itr.hasNext())
                    {
                       
                        inner_tuple = itr.next();
    
                        inner_tuple.setHdr((short)len_in, in, t1_str_sizes);
                        outer_tuple.setHdr((short)len_in, in, t1_str_sizes);
                        int flag = SK.Dominates(inner_tuple, in, outer_tuple, in, (short)len_in, t1_str_sizes, pref_list, pref_list.length);
                        int flag1 = SK.Dominates(outer_tuple, in, inner_tuple, in, (short)len_in, t1_str_sizes, pref_list, pref_list.length);
                        if(flag==1){
                        //outer is dominated by inner so go to the next iteration of the outer
                        is_quasi_skyline = false;
                        break;
                        }
                        else if(flag1==1){
                        //inner tuple is dominated by outer tuple
    
                        //remove that tuple from the buffer
                            itr.remove();
                            
                            
                        }

                    
                    }
    
                    if(my_buff.size() < (n_pages*1024)/outer_tuple.size() && is_quasi_skyline)
                    {
                       
                        my_buff.add(outer_tuple);
                        //System.out.println("tuple" + outer_tuple.getFloFld(1));
                        
                    }
                    else if (is_quasi_skyline)
                    {
                        RID rid;
                        try {
                            rid =  nextHeapfile.insertRecord(outer_tuple.returnTupleByteArray());
                        }
                        catch (Exception e){
                            e.printStackTrace();
                            throw e;
                        }         
                    }
                    
                    //skb.BlockNestedDomination(outerT, in, (short) len_in, t1_str_sizes, pref_list);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

             //TODO: insert the tuples of buffer to skyline heapfile

            for(int i = 0; i < my_buff.size(); i++)
            {
                Tuple temp_tuple;
                temp_tuple = my_buff.get(i);
                temp_tuple.setHdr((short)len_in, in, t1_str_sizes);

                RID rid;
                try {
                    rid =  skyline_Heapfile.insertRecord(temp_tuple.returnTupleByteArray());
                }
                catch (Exception e){
                    e.printStackTrace();
                    throw e;
                }         

            }

            my_buff.clear();

           
            // close the heap file scanner
            scanner.closescan();

            // empty the heap file which acted as the outer loop
            if (runVar == true) {
                try {
                    temp.deleteFile();
                    temp = new Heapfile("temp_file");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else if (runVar == false) {
                try {
                    tempone.deleteFile();
                    tempone = new Heapfile("temp_file_one");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            runVar = !runVar;
        }
        scan.closescan();
        fscan_get_next = new FileScan("skyline33.in", in_, t1_str_sizes, (short) len_in_, len_in_, projlist, null);

    }

    @Override
    public Tuple get_next() throws IOException, JoinsException, IndexException, InvalidTupleSizeException,
            InvalidTypeException, PageNotReadException, TupleUtilsException, PredEvalException, SortException,
            LowMemException, UnknowAttrType, UnknownKeyTypeException, Exception {

        // create an iterator by open a file scan
        FldSpec[] projlist = new FldSpec[len_in_];
        RelSpec rel = new RelSpec(RelSpec.outer);

        for (int i = 0; i < len_in_; i++) {
            projlist[i] = new FldSpec(rel, i + 1);
        }

        return fscan_get_next.get_next();
    }

    @Override
    public void close() throws IOException, JoinsException, SortException, IndexException {
        //delHeapFile();
        fscan_get_next.close();
    }
}
