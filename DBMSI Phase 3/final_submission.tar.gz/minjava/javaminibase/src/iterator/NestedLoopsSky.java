package iterator;

import java.io.*; 

import global.*;

import bufmgr.*;

import diskmgr.*;

import heap.*;

import iterator.*;

import skyline.SK;

import index.*;

import java.util.Random;



public class NestedLoopsSky extends Iterator implements GlobalConst{



    AttrType[] in1_;

    int len_in1_;

    short[] t1_str_sizes_;

    int[] pref_list_;

    int pref_list_length_;

    FileScan fscan_get_next = null;



    Heapfile        f = null;

    Heapfile        skyline_Heapfile = null;



    public NestedLoopsSky(AttrType[] in1, int len_in1, short[] t1_str_sizes,Iterator am1, java.lang.String

    relationName, int[] pref_list, int pref_list_length,int n_pages) throws Exception



    {

        in1_ = in1;

        len_in1_ = len_in1;

        t1_str_sizes_ = t1_str_sizes;

        pref_list_ = pref_list;

        pref_list_length_ = pref_list_length;



        

      

        f = new Heapfile(relationName);

        

        skyline_Heapfile = new Heapfile("skyline_we.in");

        



        // create a tuple of appropriate size

        Tuple t = new Tuple();

        

        t.setHdr((short) in1.length, in1, t1_str_sizes);

        

        int size = t.size();



        t = new Tuple(size);

       

        t.setHdr((short) in1.length, in1, t1_str_sizes);

        

        // create an iterator by open a file scan

        FldSpec[] projlist = new FldSpec[len_in1];

        RelSpec rel = new RelSpec(RelSpec.outer);



        for(int i = 0; i < len_in1; i++)

        {

            projlist[i] = new FldSpec(rel, i+1);

        }



        FileScan fscan = null;

        

        try {

            fscan = new FileScan(relationName, in1, t1_str_sizes, (short) len_in1, len_in1, projlist, null);

        }

        catch (Exception e) {

            

            e.printStackTrace();

        }



        FileScan fscan_inner = null;

        

    

        for(int i = 0; i < f.getRecCnt(); i++)

        {

            

            

            fscan_inner = new FileScan(relationName, in1, t1_str_sizes, (short) len_in1, len_in1, projlist, null);

            

            Tuple outer_Tuple = null;

            

            outer_Tuple = fscan.get_next();



            boolean is_skyline = true;



            for(int j = 0; j < f.getRecCnt(); j++)

            {

                Tuple inner_Tuple = null;



                inner_Tuple = fscan_inner.get_next();



                int inner_dominates_outer = 1;

                

                inner_dominates_outer = SK.Dominates(inner_Tuple, in1, outer_Tuple, in1, (short)len_in1, t1_str_sizes, pref_list, pref_list.length);

                

                if(inner_dominates_outer == 1)

                {

                    is_skyline = false;

                    break;

                }

            }



            if(is_skyline)

            {

                t = new Tuple(size);

                t.setHdr((short) in1.length, in1, t1_str_sizes);

                t.tupleCopy(outer_Tuple);

                skyline_Heapfile.insertRecord(t.returnTupleByteArray());

                //System.out.println("skyline:" + t.getIntFld(1) + " " + t.getIntFld(2));

            }

            fscan_inner.close();

            fscan_get_next = new FileScan("skyline_we.in", in1_, t1_str_sizes, (short) len_in1_, len_in1_, projlist, null);

        }

        

        fscan.close();

    }



    @Override

    public Tuple get_next() throws IOException, JoinsException, IndexException, InvalidTupleSizeException,

            InvalidTypeException, PageNotReadException, TupleUtilsException, PredEvalException, SortException,

            LowMemException, UnknowAttrType, UnknownKeyTypeException, Exception {

       

        // create an iterator by open a file scan

        FldSpec[] projlist = new FldSpec[len_in1_];

        RelSpec rel = new RelSpec(RelSpec.outer);



        for(int i = 0; i < len_in1_; i++)

        {

            projlist[i] = new FldSpec(rel, i+1);

        }



        return fscan_get_next.get_next();

    }



    @Override

    public void close() throws IOException, JoinsException, SortException, IndexException {

        fscan_get_next.close();

    }

}

