package iterator;

import java.io.IOException;

import HashIndex.UnclusteredHashIndex;
import catalog.AttrCatalog;
import global.AggType;
import global.AttrType;
import global.Catalogglobal;
import global.GlobalConst;
import global.RID;
import global.TupleOrder;
import heap.Heapfile;
import heap.Scan;
import heap.Tuple;

public class GroupBywithHash extends Iterator implements GlobalConst, Catalogglobal {

    AttrType[] in1_;
    int len_in1_;
    short[] t1_str_sizes_;
    Iterator am1_;
    FldSpec group_by_attr_;
    AggType agg_type_;
    FldSpec[] agg_list_;
    int n_out_flds_;
    int n_pages_;
    FileScan fscan_get_next = null;
    byte bufs[][];
    AttrType[] avgAtt_;

    Heapfile f = null; // input file of records
    Heapfile groupby_heapfile = null; // heapfile to store resultant tuples

    public GroupBywithHash(AttrType[] in1, int len_in1, short[] t1_str_sizes, java.lang.String relationName,
            Iterator am1, FldSpec group_by_attr, AggType agg_type, FldSpec[] agg_list, FldSpec[] proj_list,
            int n_out_flds, int n_pages, UnclusteredHashIndex existing_uhi) throws Exception {

        in1_ = in1;
        len_in1_ = len_in1;
        t1_str_sizes_ = t1_str_sizes;
        am1_ = am1;
        group_by_attr_ = group_by_attr;
        agg_type_ = agg_type;
        agg_list_ = agg_list;
        n_out_flds_ = n_out_flds;
        n_pages_ = n_pages;

        short[] stringsize = new short[in1.length];
        for(int i=0;i<in1.length;i++)
        {
            stringsize[i] = (short)40;
        }

        // heapfile which has input data
        f = new Heapfile(relationName);

        // heapfile to store the resultant tuples
        groupby_heapfile = new Heapfile("groupbysorted");

        short[] str_sizes = new short[in1.length];
        for(int i=0;i<in1.length;i++)
        {
            stringsize[i] = (short)40;
        }

        // create a tuple of appropriate size
        Tuple t = new Tuple();
        try {
            t.setHdr((short) len_in1, in1, str_sizes);
        } catch (Exception e) {
            e.printStackTrace();
        }

        t = new Tuple(t.size());
        try {
            t.setHdr((short) len_in1, in1, str_sizes);
        } catch (Exception e) {
            e.printStackTrace();
        }
        // create an iterator by open a file scan
        FldSpec[] projlist = new FldSpec[len_in1];
        RelSpec rel = new RelSpec(RelSpec.outer);
        for (int i = 0; i < len_in1; i++) {
            projlist[i] = new FldSpec(rel, i + 1);
        }

        // tuple to delete: ignore
        Tuple tuple = new Tuple();
        if (existing_uhi != null) {
            System.out.println("Using existing unclustered hash index");
        }

        else {
            float targetUtilization = 80;
            UnclusteredHashIndex uhi = null;
            AttrType[] attrType2;
            attrType2 = new AttrType[2];
            attrType2[0] = in1[group_by_attr.offset - 1];
            attrType2[1] = new AttrType(AttrType.attrString);

            AttrType[] attrType_lasthf;
            attrType_lasthf = new AttrType[2];
            attrType_lasthf[0] = new AttrType(AttrType.attrInteger);
            attrType_lasthf[1] = new AttrType(AttrType.attrInteger);

            AttrType[] attrType3;
            attrType3 = new AttrType[3];
            attrType3[0] = in1[group_by_attr.offset - 1];
            attrType3[1] = new AttrType(AttrType.attrInteger);
            attrType3[2] = new AttrType(AttrType.attrInteger);

            try {
                uhi = new UnclusteredHashIndex("", tuple, group_by_attr.offset, in1, targetUtilization, am1,
                        "tableName", relationName);
            } catch (Exception e) {
                e.printStackTrace();
            }
            uhi.Insert(attrType3, attrType2, attrType_lasthf, "tableName", group_by_attr.offset, relationName);
        }

        // sorted heapfile
        Heapfile sf = null;
        try {
            sf = new Heapfile("sortedfile");
        } catch (Exception e) {
            e.printStackTrace();
        }

        int num_cols = len_in1;

        HashIndexScan hius;
        hius = new HashIndexScan(relationName, "indexfilename", in1, "tableName", group_by_attr.offset, 0, "");
        Tuple tuc = new Tuple();
        while (tuc != null) {
            try {
                tuc = hius.get_next_unclustered();
                if (tuc == null) {
                    break;
                }
                sf.insertRecord(tuc.returnTupleByteArray());

                try {
                    tuc.setHdr((short) num_cols, in1, stringsize);
                } catch (Exception e) {

                }
                // tuc.print(in1);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        // if agg func is max
        if (agg_type.aggType == AggType.max) {
            float max = Float.NEGATIVE_INFINITY;
            Scan sortedf = null;
            try {
                sortedf = sf.openScan();
            } catch (Exception e) {
                e.printStackTrace();
            }

            RID r = new RID();
            Tuple t1 = new Tuple();
            try {
                t1.setHdr((short) len_in1, in1, str_sizes);
            } catch (Exception e) {
                e.printStackTrace();
            }
            t1 = new Tuple(t1.size());
            try {
                t1.setHdr((short) len_in1, in1, str_sizes);
            } catch (Exception e) {
                e.printStackTrace();
            }

            // max tuple
            Tuple maxtuple = new Tuple();
            try {
                maxtuple.setHdr((short) len_in1, in1, str_sizes);
            } catch (Exception e) {
                e.printStackTrace();
            }
            maxtuple = new Tuple(maxtuple.size());
            try {
                maxtuple.setHdr((short) len_in1, in1, str_sizes);
            } catch (Exception e) {
                e.printStackTrace();
            }

            String grp1 = "";
            float grp2 = 0;
            int grp3 = 0;

            try {
                try {
                    t1.setHdr((short) len_in1, in1, str_sizes);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                t1 = new Tuple(t1.size());
                try {
                    t1.setHdr((short) len_in1, in1, str_sizes);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                t1.tupleCopy(sortedf.getNext(r));

                if (in1[group_by_attr.offset - 1].attrType == AttrType.attrString) {
                    grp1 = t1.getStrFld(group_by_attr.offset);
                } else if (in1[group_by_attr.offset - 1].attrType == AttrType.attrReal) {
                    grp2 = t1.getFloFld(group_by_attr.offset);
                } else if (in1[group_by_attr.offset - 1].attrType == AttrType.attrInteger) {
                    grp3 = t1.getIntFld(group_by_attr.offset);
                }

                if (in1[agg_list[0].offset - 1].attrType == AttrType.attrInteger) {
                    if (t1.getIntFld(agg_list[0].offset) > max) {
                        max = t1.getIntFld(agg_list[0].offset);
                        maxtuple.tupleCopy(t1);
                    }
                } else if (in1[agg_list[0].offset - 1].attrType == AttrType.attrReal) {
                    if (t1.getFloFld(agg_list[0].offset) > max) {
                        max = t1.getFloFld(agg_list[0].offset);
                        maxtuple.tupleCopy(t1);
                    }
                } else if (in1[agg_list[0].offset - 1].attrType == AttrType.attrString) {
                    // TODO handle for string
                    if (t1.getFloFld(agg_list[0].offset) > max) {
                        max = t1.getFloFld(agg_list[0].offset);
                        maxtuple.tupleCopy(t1);
                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
            int count = 1;

            while (count < sf.getRecCnt()) {
                try {
                    count++;
                    t1.setHdr((short) len_in1, in1, str_sizes);
                    t1 = new Tuple(t1.size());
                    t1.setHdr((short) in1.length, in1, str_sizes);
                    t1.tupleCopy(sortedf.getNext(r));

                    if (in1[group_by_attr.offset - 1].attrType == AttrType.attrString) {
                        // if new group
                        if (!grp1.equals(t1.getStrFld(group_by_attr.offset))) {

                            // insert the max tuple in the resultant file
                            groupby_heapfile.insertRecord(maxtuple.returnTupleByteArray());

                            // reinitialise max
                            if (in1[agg_list[0].offset - 1].attrType == AttrType.attrInteger) {
                                max = t1.getIntFld(agg_list[0].offset);
                            } else if (in1[agg_list[0].offset - 1].attrType == AttrType.attrReal) {
                                max = t1.getFloFld(agg_list[0].offset);
                            } else if (in1[agg_list[0].offset - 1].attrType == AttrType.attrString) {
                                // TODO handle string
                                // max = t1.getStrFld(agg_list[0].offset);
                            }
                            // max = t1.getFloFld(1);
                            maxtuple.setHdr((short) len_in1, in1, str_sizes);
                            maxtuple = new Tuple(maxtuple.size());
                            maxtuple.setHdr((short) in1.length, in1, str_sizes);
                            maxtuple.tupleCopy(t1);

                            // reinitialize the grp variable
                            grp1 = t1.getStrFld(group_by_attr.offset);
                        }
                        // old group
                        else {
                            if (in1[agg_list[0].offset - 1].attrType == AttrType.attrInteger) {
                                if (t1.getIntFld(agg_list[0].offset) > max) {
                                    max = t1.getIntFld(agg_list[0].offset);

                                    maxtuple.setHdr((short) len_in1, in1, str_sizes);
                                    maxtuple = new Tuple(maxtuple.size());
                                    maxtuple.setHdr((short) in1.length, in1, str_sizes);

                                    maxtuple.tupleCopy(t1);
                                }

                            } else if (in1[agg_list[0].offset - 1].attrType == AttrType.attrReal) {
                                if (t1.getFloFld(agg_list[0].offset) > max) {
                                    max = t1.getFloFld(agg_list[0].offset);

                                    maxtuple.setHdr((short) len_in1, in1, str_sizes);
                                    maxtuple = new Tuple(maxtuple.size());
                                    maxtuple.setHdr((short) in1.length, in1, str_sizes);

                                    maxtuple.tupleCopy(t1);
                                }
                            } else if (in1[agg_list[0].offset - 1].attrType == AttrType.attrString) {
                                // TODO handle string
                                // if (t1.getFloFld(agg_list[0].offset) > max) {
                                // max = t1.getFloFld(agg_list[0].offset);

                                // maxtuple.setHdr((short) len_in1, in1, str_sizes);
                                // maxtuple = new Tuple(maxtuple.size());
                                // maxtuple.setHdr((short) in1.length, in1, str_sizes);

                                // maxtuple.tupleCopy(t1);
                                // }
                            }
                        }
                    } else if (in1[group_by_attr.offset - 1].attrType == AttrType.attrReal) {
                        // if new group
                        if (grp2 != t1.getFloFld(group_by_attr.offset)) {

                            // insert the max tuple in the resultant file
                            groupby_heapfile.insertRecord(maxtuple.returnTupleByteArray());

                            // reinitialise max
                            if (in1[agg_list[0].offset - 1].attrType == AttrType.attrInteger) {
                                max = t1.getIntFld(agg_list[0].offset);
                            } else if (in1[agg_list[0].offset - 1].attrType == AttrType.attrReal) {
                                max = t1.getFloFld(agg_list[0].offset);
                            } else if (in1[agg_list[0].offset - 1].attrType == AttrType.attrString) {
                                // TODO handle string
                                // max = t1.getStrFld(agg_list[0].offset);
                            }
                            maxtuple.setHdr((short) len_in1, in1, str_sizes);
                            maxtuple = new Tuple(maxtuple.size());
                            maxtuple.setHdr((short) in1.length, in1, str_sizes);
                            maxtuple.tupleCopy(t1);

                            // reinitialize the grp variable
                            grp2 = t1.getFloFld(group_by_attr.offset);

                        }
                        // old group
                        else {
                            if (in1[agg_list[0].offset - 1].attrType == AttrType.attrInteger) {
                                if (t1.getIntFld(agg_list[0].offset) > max) {
                                    max = t1.getIntFld(agg_list[0].offset);

                                    maxtuple.setHdr((short) len_in1, in1, str_sizes);
                                    maxtuple = new Tuple(maxtuple.size());
                                    maxtuple.setHdr((short) in1.length, in1, str_sizes);

                                    maxtuple.tupleCopy(t1);
                                }

                            } else if (in1[agg_list[0].offset - 1].attrType == AttrType.attrReal) {
                                if (t1.getFloFld(agg_list[0].offset) > max) {
                                    max = t1.getFloFld(agg_list[0].offset);

                                    maxtuple.setHdr((short) len_in1, in1, str_sizes);
                                    maxtuple = new Tuple(maxtuple.size());
                                    maxtuple.setHdr((short) in1.length, in1, str_sizes);

                                    maxtuple.tupleCopy(t1);
                                }
                            } else if (in1[agg_list[0].offset - 1].attrType == AttrType.attrString) {
                                // TODO handle string
                                // if (t1.getFloFld(agg_list[0].offset) > max) {
                                // max = t1.getFloFld(agg_list[0].offset);

                                // maxtuple.setHdr((short) len_in1, in1, str_sizes);
                                // maxtuple = new Tuple(maxtuple.size());
                                // maxtuple.setHdr((short) in1.length, in1, str_sizes);

                                // maxtuple.tupleCopy(t1);
                                // }
                            }
                        }
                    } else if (in1[group_by_attr.offset - 1].attrType == AttrType.attrInteger) {
                        // if new group
                        if (grp3 != t1.getIntFld(group_by_attr.offset)) {

                            // insert the max tuple in the resultant file
                            groupby_heapfile.insertRecord(maxtuple.returnTupleByteArray());

                            // reinitialise max
                            if (in1[agg_list[0].offset - 1].attrType == AttrType.attrInteger) {
                                max = t1.getIntFld(agg_list[0].offset);
                            } else if (in1[agg_list[0].offset - 1].attrType == AttrType.attrReal) {
                                max = t1.getFloFld(agg_list[0].offset);
                            } else if (in1[agg_list[0].offset - 1].attrType == AttrType.attrString) {
                                // TODO handle string
                                // max = t1.getStrFld(agg_list[0].offset);
                            }
                            maxtuple.setHdr((short) len_in1, in1, str_sizes);
                            maxtuple = new Tuple(maxtuple.size());
                            maxtuple.setHdr((short) in1.length, in1, str_sizes);
                            maxtuple.tupleCopy(t1);
                            // reinitialize the grp variable
                            grp3 = t1.getIntFld(group_by_attr.offset);
                        }
                        // old group
                        else {
                            if (in1[agg_list[0].offset - 1].attrType == AttrType.attrInteger) {
                                if (t1.getIntFld(agg_list[0].offset) > max) {
                                    max = t1.getIntFld(agg_list[0].offset);

                                    maxtuple.setHdr((short) len_in1, in1, str_sizes);
                                    maxtuple = new Tuple(maxtuple.size());
                                    maxtuple.setHdr((short) in1.length, in1, str_sizes);

                                    maxtuple.tupleCopy(t1);
                                }

                            } else if (in1[agg_list[0].offset - 1].attrType == AttrType.attrReal) {
                                if (t1.getFloFld(agg_list[0].offset) > max) {
                                    max = t1.getFloFld(agg_list[0].offset);

                                    maxtuple.setHdr((short) len_in1, in1, str_sizes);
                                    maxtuple = new Tuple(maxtuple.size());
                                    maxtuple.setHdr((short) in1.length, in1, str_sizes);

                                    maxtuple.tupleCopy(t1);
                                }
                            } else if (in1[agg_list[0].offset - 1].attrType == AttrType.attrString) {
                                // TODO handle string
                                // if (t1.getFloFld(agg_list[0].offset) > max) {
                                // max = t1.getFloFld(agg_list[0].offset);

                                // maxtuple.setHdr((short) len_in1, in1, str_sizes);
                                // maxtuple = new Tuple(maxtuple.size());
                                // maxtuple.setHdr((short) in1.length, in1, str_sizes);

                                // maxtuple.tupleCopy(t1);
                                // }
                            }
                        }
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            try {
                groupby_heapfile.insertRecord(maxtuple.returnTupleByteArray());
                sortedf.closescan();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

        // if agg func is min
        if (agg_type.aggType == AggType.min) {
            float min = Float.POSITIVE_INFINITY;
            Scan sortedf = null;
            try {
                sortedf = sf.openScan();
            } catch (Exception e) {
                e.printStackTrace();
            }

            RID r = new RID();
            Tuple t1 = new Tuple();
            try {
                t1.setHdr((short) len_in1, in1, str_sizes);
            } catch (Exception e) {
                e.printStackTrace();
            }
            t1 = new Tuple(t1.size());
            try {
                t1.setHdr((short) len_in1, in1, str_sizes);
            } catch (Exception e) {
                e.printStackTrace();
            }

            // min tuple
            Tuple mintuple = new Tuple();
            try {
                mintuple.setHdr((short) len_in1, in1, str_sizes);
            } catch (Exception e) {
                e.printStackTrace();
            }
            mintuple = new Tuple(mintuple.size());
            try {
                mintuple.setHdr((short) len_in1, in1, str_sizes);
            } catch (Exception e) {
                e.printStackTrace();
            }

            String grp1 = "";
            float grp2 = 0;
            int grp3 = 0;

            try {
                try {
                    t1.setHdr((short) len_in1, in1, str_sizes);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                t1 = new Tuple(t1.size());
                try {
                    t1.setHdr((short) len_in1, in1, str_sizes);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                t1.tupleCopy(sortedf.getNext(r));

                if (in1[group_by_attr.offset - 1].attrType == AttrType.attrString) {
                    grp1 = t1.getStrFld(group_by_attr.offset);
                } else if (in1[group_by_attr.offset - 1].attrType == AttrType.attrReal) {
                    grp2 = t1.getFloFld(group_by_attr.offset);
                } else if (in1[group_by_attr.offset - 1].attrType == AttrType.attrInteger) {
                    grp3 = t1.getIntFld(group_by_attr.offset);
                }

                if (in1[agg_list[0].offset - 1].attrType == AttrType.attrInteger) {
                    if (t1.getIntFld(agg_list[0].offset) < min) {
                        min = t1.getIntFld(agg_list[0].offset);
                        mintuple.tupleCopy(t1);
                    }
                } else if (in1[agg_list[0].offset - 1].attrType == AttrType.attrReal) {
                    if (t1.getFloFld(agg_list[0].offset) < min) {
                        min = t1.getFloFld(agg_list[0].offset);
                        mintuple.tupleCopy(t1);
                    }
                } else if (in1[agg_list[0].offset - 1].attrType == AttrType.attrString) {
                    // TODO handle for string
                    if (t1.getFloFld(agg_list[0].offset) < min) {
                        min = t1.getFloFld(agg_list[0].offset);
                        mintuple.tupleCopy(t1);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            int count = 1;

            while (count < sf.getRecCnt()) {
                try {
                    count++;
                    t1.setHdr((short) len_in1, in1, str_sizes);
                    t1 = new Tuple(t1.size());
                    t1.setHdr((short) in1.length, in1, str_sizes);
                    t1.tupleCopy(sortedf.getNext(r));

                    if (in1[group_by_attr.offset - 1].attrType == AttrType.attrString) {
                        // if new group
                        if (!grp1.equals(t1.getStrFld(group_by_attr.offset))) {

                            // insert the min tuple in the resultant file
                            groupby_heapfile.insertRecord(mintuple.returnTupleByteArray());

                            // reinitialise min

                            if (in1[agg_list[0].offset - 1].attrType == AttrType.attrInteger) {
                                min = t1.getIntFld(agg_list[0].offset);
                            } else if (in1[agg_list[0].offset - 1].attrType == AttrType.attrReal) {
                                min = t1.getFloFld(agg_list[0].offset);
                            } else if (in1[agg_list[0].offset - 1].attrType == AttrType.attrString) {
                                // TODO handle string
                                // max = t1.getStrFld(agg_list[0].offset);
                            }

                            mintuple.setHdr((short) len_in1, in1, str_sizes);
                            mintuple = new Tuple(mintuple.size());
                            mintuple.setHdr((short) in1.length, in1, str_sizes);
                            mintuple.tupleCopy(t1);

                            // reinitialize the grp variable
                            grp1 = t1.getStrFld(group_by_attr.offset);
                        }
                        // old group
                        else {

                            if (in1[agg_list[0].offset - 1].attrType == AttrType.attrInteger) {
                                if (t1.getIntFld(agg_list[0].offset) < min) {
                                    min = t1.getIntFld(agg_list[0].offset);

                                    mintuple.setHdr((short) len_in1, in1, str_sizes);
                                    mintuple = new Tuple(mintuple.size());
                                    mintuple.setHdr((short) in1.length, in1, str_sizes);

                                    mintuple.tupleCopy(t1);
                                }

                            } else if (in1[agg_list[0].offset - 1].attrType == AttrType.attrReal) {
                                if (t1.getFloFld(agg_list[0].offset) < min) {
                                    min = t1.getFloFld(agg_list[0].offset);

                                    mintuple.setHdr((short) len_in1, in1, str_sizes);
                                    mintuple = new Tuple(mintuple.size());
                                    mintuple.setHdr((short) in1.length, in1, str_sizes);

                                    mintuple.tupleCopy(t1);
                                }
                            } else if (in1[agg_list[0].offset - 1].attrType == AttrType.attrString) {
                                // TODO handle string
                                // if (t1.getFloFld(agg_list[0].offset) < min) {
                                // min = t1.getFloFld(agg_list[0].offset);

                                // mintuple.setHdr((short) len_in1, in1, str_sizes);
                                // mintuple = new Tuple(mintuple.size());
                                // mintuple.setHdr((short) in1.length, in1, str_sizes);

                                // mintuple.tupleCopy(t1);
                                // }
                            }
                        }
                    } else if (in1[group_by_attr.offset - 1].attrType == AttrType.attrReal) {
                        // if new group
                        if (grp2 != t1.getFloFld(group_by_attr.offset)) {

                            // insert the min tuple in the resultant file
                            groupby_heapfile.insertRecord(mintuple.returnTupleByteArray());

                            // reinitialise min
                            if (in1[agg_list[0].offset - 1].attrType == AttrType.attrInteger) {
                                min = t1.getIntFld(agg_list[0].offset);
                            } else if (in1[agg_list[0].offset - 1].attrType == AttrType.attrReal) {
                                min = t1.getFloFld(agg_list[0].offset);
                            } else if (in1[agg_list[0].offset - 1].attrType == AttrType.attrString) {
                                // TODO handle string
                                // max = t1.getStrFld(agg_list[0].offset);
                            }

                            mintuple.setHdr((short) len_in1, in1, str_sizes);
                            mintuple = new Tuple(mintuple.size());
                            mintuple.setHdr((short) in1.length, in1, str_sizes);
                            mintuple.tupleCopy(t1);
                            // reinitialize the grp variable
                            grp2 = t1.getFloFld(group_by_attr.offset);

                        }
                        // old group
                        else {
                            if (in1[agg_list[0].offset - 1].attrType == AttrType.attrInteger) {
                                if (t1.getIntFld(agg_list[0].offset) < min) {
                                    min = t1.getIntFld(agg_list[0].offset);

                                    mintuple.setHdr((short) len_in1, in1, str_sizes);
                                    mintuple = new Tuple(mintuple.size());
                                    mintuple.setHdr((short) in1.length, in1, str_sizes);

                                    mintuple.tupleCopy(t1);
                                }

                            } else if (in1[agg_list[0].offset - 1].attrType == AttrType.attrReal) {
                                if (t1.getFloFld(agg_list[0].offset) < min) {
                                    min = t1.getFloFld(agg_list[0].offset);

                                    mintuple.setHdr((short) len_in1, in1, str_sizes);
                                    mintuple = new Tuple(mintuple.size());
                                    mintuple.setHdr((short) in1.length, in1, str_sizes);

                                    mintuple.tupleCopy(t1);
                                }
                            } else if (in1[agg_list[0].offset - 1].attrType == AttrType.attrString) {
                                // TODO handle string
                                // if (t1.getFloFld(agg_list[0].offset) < min) {
                                // min = t1.getFloFld(agg_list[0].offset);

                                // mintuple.setHdr((short) len_in1, in1, str_sizes);
                                // mintuple = new Tuple(mintuple.size());
                                // mintuple.setHdr((short) in1.length, in1, str_sizes);

                                // mintuple.tupleCopy(t1);
                                // }
                            }
                        }
                    } else if (in1[group_by_attr.offset - 1].attrType == AttrType.attrInteger) {
                        // if new group
                        if (grp3 != t1.getIntFld(group_by_attr.offset)) {

                            // insert the min tuple in the resultant file
                            groupby_heapfile.insertRecord(mintuple.returnTupleByteArray());

                            // reinitialise min
                            if (in1[agg_list[0].offset - 1].attrType == AttrType.attrInteger) {
                                min = t1.getIntFld(agg_list[0].offset);
                            } else if (in1[agg_list[0].offset - 1].attrType == AttrType.attrReal) {
                                min = t1.getFloFld(agg_list[0].offset);
                            } else if (in1[agg_list[0].offset - 1].attrType == AttrType.attrString) {
                                // TODO handle string
                                // max = t1.getStrFld(agg_list[0].offset);
                            }
                            mintuple.setHdr((short) len_in1, in1, str_sizes);
                            mintuple = new Tuple(mintuple.size());
                            mintuple.setHdr((short) in1.length, in1, str_sizes);
                            mintuple.tupleCopy(t1);

                            // reinitialize the grp variable
                            grp3 = t1.getIntFld(group_by_attr.offset);
                        }
                        // old group
                        else {
                            if (in1[agg_list[0].offset - 1].attrType == AttrType.attrInteger) {
                                if (t1.getIntFld(agg_list[0].offset) < min) {
                                    min = t1.getIntFld(agg_list[0].offset);

                                    mintuple.setHdr((short) len_in1, in1, str_sizes);
                                    mintuple = new Tuple(mintuple.size());
                                    mintuple.setHdr((short) in1.length, in1, str_sizes);

                                    mintuple.tupleCopy(t1);
                                }

                            } else if (in1[agg_list[0].offset - 1].attrType == AttrType.attrReal) {
                                if (t1.getFloFld(agg_list[0].offset) < min) {
                                    min = t1.getFloFld(agg_list[0].offset);

                                    mintuple.setHdr((short) len_in1, in1, str_sizes);
                                    mintuple = new Tuple(mintuple.size());
                                    mintuple.setHdr((short) in1.length, in1, str_sizes);

                                    mintuple.tupleCopy(t1);
                                }
                            } else if (in1[agg_list[0].offset - 1].attrType == AttrType.attrString) {
                                // TODO handle string
                                // if (t1.getFloFld(agg_list[0].offset) < min) {
                                // min = t1.getFloFld(agg_list[0].offset);

                                // mintuple.setHdr((short) len_in1, in1, str_sizes);
                                // mintuple = new Tuple(mintuple.size());
                                // mintuple.setHdr((short) in1.length, in1, str_sizes);

                                // mintuple.tupleCopy(t1);
                                // }
                            }
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            try {
                groupby_heapfile.insertRecord(mintuple.returnTupleByteArray());
                sortedf.closescan();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

        // if agg func is avg
        if (agg_type.aggType == AggType.avg) {
            float sum = 0;
            Scan sortedf = null;
            try {
                sortedf = sf.openScan();
            } catch (Exception e) {
                e.printStackTrace();
            }

            RID r = new RID();
            Tuple t1 = new Tuple();
            try {
                t1.setHdr((short) len_in1, in1, str_sizes);
            } catch (Exception e) {
                e.printStackTrace();
            }
            t1 = new Tuple(t1.size());
            try {
                t1.setHdr((short) len_in1, in1, str_sizes);
            } catch (Exception e) {
                e.printStackTrace();
            }

            // attr for avg tuple
            AttrType[] avgatt = new AttrType[2];
            if (in1[group_by_attr.offset - 1].attrType == AttrType.attrInteger) {
                avgatt[0] = new AttrType(AttrType.attrInteger);
            } else if (in1[group_by_attr.offset - 1].attrType == AttrType.attrReal) {
                avgatt[0] = new AttrType(AttrType.attrReal);
            } else if (in1[group_by_attr.offset - 1].attrType == AttrType.attrString) {
                avgatt[0] = new AttrType(AttrType.attrString);
            }
            avgatt[1] = new AttrType(AttrType.attrReal);

            avgAtt_ = avgatt;

            // avg tuple
            Tuple avgtuple = new Tuple();
            try {
                avgtuple.setHdr((short) 2, avgatt, str_sizes);
            } catch (Exception e) {
                e.printStackTrace();
            }
            avgtuple = new Tuple(avgtuple.size());
            try {
                avgtuple.setHdr((short) 2, avgatt, str_sizes);
            } catch (Exception e) {
                e.printStackTrace();
            }

            String grp1 = "";
            float grp2 = 0;
            int grp3 = 0;

            try {
                try {
                    t1.setHdr((short) len_in1, in1, str_sizes);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                t1 = new Tuple(t1.size());

                try {
                    t1.setHdr((short) len_in1, in1, str_sizes);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                t1.tupleCopy(sortedf.getNext(r));

                if (in1[group_by_attr.offset - 1].attrType == AttrType.attrString) {
                    grp1 = t1.getStrFld(group_by_attr.offset);
                    avgtuple.setStrFld(1, t1.getStrFld(group_by_attr.offset));
                } else if (in1[group_by_attr.offset - 1].attrType == AttrType.attrReal) {
                    grp2 = t1.getFloFld(group_by_attr.offset);
                    avgtuple.setFloFld(1, t1.getFloFld(group_by_attr.offset));
                } else if (in1[group_by_attr.offset - 1].attrType == AttrType.attrInteger) {
                    grp3 = t1.getIntFld(group_by_attr.offset);
                    avgtuple.setIntFld(1, t1.getIntFld(group_by_attr.offset));
                }

                if (in1[agg_list[0].offset - 1].attrType == AttrType.attrInteger) {
                    sum += t1.getIntFld(agg_list[0].offset);
                } else if (in1[agg_list[0].offset - 1].attrType == AttrType.attrReal) {
                    sum += t1.getFloFld(agg_list[0].offset);
                } else if (in1[agg_list[0].offset - 1].attrType == AttrType.attrString) {
                    // TODO handle string
                    // sum +=t1.getStrFld(agg_list[0].offset);
                }

                avgtuple.setFloFld(2, sum);

            } catch (Exception e) {
                e.printStackTrace();
            }
            int count = 1;
            int groupcount = 1;

            while (count < sf.getRecCnt()) {
                try {
                    count++;
                    t1.setHdr((short) len_in1, in1, str_sizes);
                    t1 = new Tuple(t1.size());
                    t1.setHdr((short) in1.length, in1, str_sizes);
                    t1.tupleCopy(sortedf.getNext(r));

                    if (in1[group_by_attr.offset - 1].attrType == AttrType.attrString) {
                        // if new group
                        if (!grp1.equals(t1.getStrFld(group_by_attr.offset))) {

                            // insert the avg tuple in the resultant file
                            groupby_heapfile.insertRecord(avgtuple.returnTupleByteArray());

                            // reinitialise sum
                            sum = 0;
                            if (in1[agg_list[0].offset - 1].attrType == AttrType.attrInteger) {
                                sum += t1.getIntFld(agg_list[0].offset);
                            } else if (in1[agg_list[0].offset - 1].attrType == AttrType.attrReal) {
                                sum += t1.getFloFld(agg_list[0].offset);
                            } else if (in1[agg_list[0].offset - 1].attrType == AttrType.attrString) {
                                // TODO handle string
                                // sum += t1.getStrFld(agg_list[0].offset);
                            }

                            // reinitialize the grp variable
                            grp1 = t1.getStrFld(group_by_attr.offset);

                            // reinitialize group count
                            groupcount = 1;
                        }
                        // old group
                        else {
                            groupcount++;

                            if (in1[agg_list[0].offset - 1].attrType == AttrType.attrInteger) {
                                sum += t1.getIntFld(agg_list[0].offset);
                            } else if (in1[agg_list[0].offset - 1].attrType == AttrType.attrReal) {
                                sum += t1.getFloFld(agg_list[0].offset);
                            } else if (in1[agg_list[0].offset - 1].attrType == AttrType.attrString) {
                                // TODO handle string
                                // sum += t1.getStrFld(agg_list[0].offset);
                            }

                            avgtuple.setHdr((short) (2), avgatt, str_sizes);
                            avgtuple = new Tuple(avgtuple.size());
                            avgtuple.setHdr((short) (2), avgatt, str_sizes);

                            if (in1[group_by_attr.offset - 1].attrType == AttrType.attrInteger) {
                                avgtuple.setIntFld(1, t1.getIntFld(group_by_attr.offset));
                            } else if (in1[group_by_attr.offset - 1].attrType == AttrType.attrReal) {
                                avgtuple.setFloFld(1, t1.getFloFld(group_by_attr.offset));
                            } else if (in1[group_by_attr.offset - 1].attrType == AttrType.attrString) {
                                avgtuple.setStrFld(1, t1.getStrFld(group_by_attr.offset));
                            }
                            avgtuple.setFloFld(2, sum / groupcount);

                        }
                    } else if (in1[group_by_attr.offset - 1].attrType == AttrType.attrReal) {
                        // if new group
                        if (grp2 != (t1.getFloFld(group_by_attr.offset))) {

                            // insert the avg tuple in the resultant file
                            groupby_heapfile.insertRecord(avgtuple.returnTupleByteArray());

                            // reinitialise sum
                            sum = 0;
                            if (in1[agg_list[0].offset - 1].attrType == AttrType.attrInteger) {
                                sum += t1.getIntFld(agg_list[0].offset);
                            } else if (in1[agg_list[0].offset - 1].attrType == AttrType.attrReal) {
                                sum += t1.getFloFld(agg_list[0].offset);
                            } else if (in1[agg_list[0].offset - 1].attrType == AttrType.attrString) {
                                // TODO handle string
                                // sum += t1.getStrFld(agg_list[0].offset);
                            }

                            // reinitialize the grp variable
                            grp2 = t1.getFloFld(group_by_attr.offset);

                            // reinitialize group count
                            groupcount = 1;
                        }
                        // old group
                        else {
                            groupcount++;

                            if (in1[agg_list[0].offset - 1].attrType == AttrType.attrInteger) {
                                sum += t1.getIntFld(agg_list[0].offset);
                            } else if (in1[agg_list[0].offset - 1].attrType == AttrType.attrReal) {
                                sum += t1.getFloFld(agg_list[0].offset);
                            } else if (in1[agg_list[0].offset - 1].attrType == AttrType.attrString) {
                                // TODO handle string
                                // sum += t1.getStrFld(agg_list[0].offset);
                            }

                            avgtuple.setHdr((short) (len_in1 + 1), avgatt, str_sizes);
                            avgtuple = new Tuple(avgtuple.size());
                            avgtuple.setHdr((short) (in1.length + 1), avgatt, str_sizes);

                            if (in1[group_by_attr.offset - 1].attrType == AttrType.attrInteger) {
                                avgtuple.setIntFld(1, t1.getIntFld(group_by_attr.offset));
                            } else if (in1[group_by_attr.offset - 1].attrType == AttrType.attrReal) {
                                avgtuple.setFloFld(1, t1.getFloFld(group_by_attr.offset));
                            } else if (in1[group_by_attr.offset - 1].attrType == AttrType.attrString) {
                                avgtuple.setStrFld(1, t1.getStrFld(group_by_attr.offset));
                            }
                            avgtuple.setFloFld(2, sum / groupcount);
                        }
                    } else if (in1[group_by_attr.offset - 1].attrType == AttrType.attrInteger) {
                        // if new group
                        if (grp3 != t1.getIntFld(group_by_attr.offset)) {

                            // insert the avg tuple in the resultant file
                            groupby_heapfile.insertRecord(avgtuple.returnTupleByteArray());

                            // reinitialise sum
                            sum = 0;
                            if (in1[agg_list[0].offset - 1].attrType == AttrType.attrInteger) {
                                sum += t1.getIntFld(agg_list[0].offset);
                            } else if (in1[agg_list[0].offset - 1].attrType == AttrType.attrReal) {
                                sum += t1.getFloFld(agg_list[0].offset);
                            } else if (in1[agg_list[0].offset - 1].attrType == AttrType.attrString) {
                                // TODO handle string
                                // sum += t1.getStrFld(agg_list[0].offset);
                            }

                            // reinitialize the grp variable
                            grp3 = t1.getIntFld(group_by_attr.offset);

                            // reinitialize group count
                            groupcount = 1;
                        }
                        // old group
                        else {
                            groupcount++;

                            if (in1[agg_list[0].offset - 1].attrType == AttrType.attrInteger) {
                                sum += t1.getIntFld(agg_list[0].offset);
                            } else if (in1[agg_list[0].offset - 1].attrType == AttrType.attrReal) {
                                sum += t1.getFloFld(agg_list[0].offset);
                            } else if (in1[agg_list[0].offset - 1].attrType == AttrType.attrString) {
                                // TODO handle string
                                // sum += t1.getStrFld(agg_list[0].offset);
                            }

                            avgtuple.setHdr((short) (len_in1 + 1), avgatt, str_sizes);
                            avgtuple = new Tuple(avgtuple.size());
                            avgtuple.setHdr((short) (in1.length + 1), avgatt, str_sizes);

                            if (in1[group_by_attr.offset - 1].attrType == AttrType.attrInteger) {
                                avgtuple.setIntFld(1, t1.getIntFld(group_by_attr.offset));
                            } else if (in1[group_by_attr.offset - 1].attrType == AttrType.attrReal) {
                                avgtuple.setFloFld(1, t1.getFloFld(group_by_attr.offset));
                            } else if (in1[group_by_attr.offset - 1].attrType == AttrType.attrString) {
                                avgtuple.setStrFld(1, t1.getStrFld(group_by_attr.offset));
                            }
                            avgtuple.setFloFld(2, sum / groupcount);
                        }
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            try {
                groupby_heapfile.insertRecord(avgtuple.returnTupleByteArray());
                sortedf.closescan();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

        // if agg func is skyline
        if (agg_type.aggType == AggType.skyline) {

            Scan sortedf = null;
            try {
                sortedf = sf.openScan();
            } catch (Exception e) {
                e.printStackTrace();
            }

            // Heapfile for tuples of a single group
            Heapfile grouptuples = null;
            try {
                grouptuples = new Heapfile("groupskyline");
            } catch (Exception e) {
                e.printStackTrace();
            }

            RID r = new RID();
            Tuple t1 = new Tuple();
            try {
                t1.setHdr((short) len_in1, in1, str_sizes);
            } catch (Exception e) {
                e.printStackTrace();
            }
            t1 = new Tuple(t1.size());
            try {
                t1.setHdr((short) len_in1, in1, str_sizes);
            } catch (Exception e) {
                e.printStackTrace();
            }

            String grp1 = "";
            float grp2 = 0;
            int grp3 = 0;

            try {
                try {
                    t1.setHdr((short) len_in1, in1, str_sizes);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                t1 = new Tuple(t1.size());
                try {
                    t1.setHdr((short) len_in1, in1, str_sizes);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                t1.tupleCopy(sortedf.getNext(r));

                if (in1[group_by_attr.offset - 1].attrType == AttrType.attrString) {
                    grp1 = t1.getStrFld(group_by_attr.offset);
                } else if (in1[group_by_attr.offset - 1].attrType == AttrType.attrReal) {
                    grp2 = t1.getFloFld(group_by_attr.offset);
                } else if (in1[group_by_attr.offset - 1].attrType == AttrType.attrInteger) {
                    grp3 = t1.getIntFld(group_by_attr.offset);
                }

                try {
                    grouptuples.insertRecord(t1.returnTupleByteArray());
                } catch (Exception e) {
                    e.printStackTrace();
                }

            } catch (Exception e) {
                e.printStackTrace();
            }

            int count = 1;
            Tuple sky = new Tuple();
            try {
                sky.setHdr((short) len_in1, in1, str_sizes);
            } catch (Exception ex) {
            }

            sky = new Tuple(sky.size());

            try {
                sky.setHdr((short) len_in1, in1, str_sizes);
            } catch (Exception ex) {
            }

            while (count < sf.getRecCnt()) {
                try {
                    count++;
                    t1.setHdr((short) len_in1, in1, str_sizes);
                    t1 = new Tuple(t1.size());
                    t1.setHdr((short) in1.length, in1, str_sizes);
                    t1.tupleCopy(sortedf.getNext(r));

                    if (in1[group_by_attr.offset - 1].attrType == AttrType.attrString) {
                        // if new group
                        if (!grp1.equals(t1.getStrFld(group_by_attr.offset))) {

                            // find the skyline of the previous group
                            int[] pref_list = new int[agg_list.length];
                            for (int i = 0; i < agg_list.length; i++) {
                                pref_list[i] = agg_list[i].offset;
                            }
                            BlockNestedLoopSky sfs = null;
                            try {
                                sfs = new BlockNestedLoopSky(in1, len_in1, t1_str_sizes, (FileScan) am1, "groupskyline",
                                        pref_list, pref_list.length, n_pages);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                            try {
                                sky.setHdr((short) len_in1, in1, str_sizes);
                            } catch (Exception ex) {
                            }

                            sky = new Tuple(t1.size());

                            try {
                                sky.setHdr((short) len_in1, in1, str_sizes);
                            } catch (Exception ex) {
                            }

                            try {
                                sky = sfs.get_next();
                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                            while (sky != null) {
                                try {
                                    groupby_heapfile.insertRecord(new Tuple(sky).returnTupleByteArray());
                                    // System.out.println(sky.getStrFld(1) + " " + sky.getFloFld(2) + " " +
                                    // sky.getFloFld(3));
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }

                                try {
                                    try {
                                        sky.setHdr((short) len_in1, in1, str_sizes);
                                    } catch (Exception ex) {
                                    }

                                    sky = new Tuple(sky.size());

                                    try {
                                        sky.setHdr((short) len_in1, in1, str_sizes);
                                    } catch (Exception ex) {
                                    }
                                    sky = sfs.get_next();
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }

                            // delete the heapfile which has group tuples
                            // reinitialise the heapfile
                            try {
                                grouptuples.deleteFile();
                                grouptuples = new Heapfile("groupskyline");
                            } catch (Exception ex) {
                                ex.printStackTrace();
                            }

                            // insert first tuple of new group into the file
                            try {
                                grouptuples.insertRecord(t1.returnTupleByteArray());
                            } catch (Exception ex) {
                                ex.printStackTrace();
                            }

                            // reinitialize the grp variable
                            grp1 = t1.getStrFld(group_by_attr.offset);

                        }
                        // old group
                        else {
                            try {
                                grouptuples.insertRecord(t1.returnTupleByteArray());
                            } catch (Exception ex) {
                                ex.printStackTrace();
                            }
                        }
                    } else if (in1[group_by_attr.offset - 1].attrType == AttrType.attrReal) {
                        // if new group
                        if (grp2 != t1.getFloFld(group_by_attr.offset)) {

                            // find the skyline of the previous group
                            int[] pref_list = new int[agg_list.length];
                            for (int i = 0; i < agg_list.length; i++) {
                                pref_list[i] = agg_list[i].offset;
                            }
                            BlockNestedLoopSky sfs = null;
                            try {
                                sfs = new BlockNestedLoopSky(in1, len_in1, t1_str_sizes, (FileScan) am1, "groupskyline",
                                        pref_list, pref_list.length, n_pages);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                            try {
                                sky.setHdr((short) len_in1, in1, str_sizes);
                            } catch (Exception ex) {
                            }

                            sky = new Tuple(sky.size());

                            try {
                                sky.setHdr((short) len_in1, in1, str_sizes);
                            } catch (Exception ex) {
                            }

                            try {
                                sky = sfs.get_next();
                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                            while (sky != null) {
                                try {
                                    groupby_heapfile.insertRecord(new Tuple(sky).returnTupleByteArray());
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }

                                try {
                                    try {
                                        sky.setHdr((short) len_in1, in1, str_sizes);
                                    } catch (Exception ex) {
                                    }

                                    sky = new Tuple(sky.size());

                                    try {
                                        sky.setHdr((short) len_in1, in1, str_sizes);
                                    } catch (Exception ex) {
                                    }
                                    sky = sfs.get_next();
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }

                            // delete the heapfile which has group tuples
                            try {
                                grouptuples.deleteFile();
                            } catch (Exception ex) {
                                ex.printStackTrace();
                            }

                            // reinitialise the heapfile
                            try {
                                grouptuples = new Heapfile("groupskyline");
                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                            // insert first tuple of new group into the file
                            try {
                                grouptuples.insertRecord(t1.returnTupleByteArray());
                            } catch (Exception ex) {
                                ex.printStackTrace();
                            }

                            // reinitialize the grp variable
                            grp2 = t1.getFloFld(group_by_attr.offset);

                        }
                        // old group
                        else {
                            try {
                                grouptuples.insertRecord(t1.returnTupleByteArray());
                            } catch (Exception ex) {
                                ex.printStackTrace();
                            }
                        }
                    } else if (in1[group_by_attr.offset - 1].attrType == AttrType.attrInteger) {
                        // if new group
                        if (grp3 != t1.getIntFld(group_by_attr.offset)) {

                            // find the skyline of the previous group
                            int[] pref_list = new int[agg_list.length];
                            for (int i = 0; i < agg_list.length; i++) {
                                pref_list[i] = agg_list[i].offset;
                            }
                            BlockNestedLoopSky sfs = null;
                            try {
                                sfs = new BlockNestedLoopSky(in1, len_in1, t1_str_sizes, (FileScan) am1, "groupskyline",
                                        pref_list, pref_list.length, n_pages);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                            try {
                                sky.setHdr((short) len_in1, in1, str_sizes);
                            } catch (Exception ex) {
                            }

                            sky = new Tuple(sky.size());

                            try {
                                sky.setHdr((short) len_in1, in1, str_sizes);
                            } catch (Exception ex) {
                            }

                            try {
                                sky = sfs.get_next();
                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                            while (sky != null) {
                                try {
                                    groupby_heapfile.insertRecord(new Tuple(sky).returnTupleByteArray());
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }

                                try {
                                    try {
                                        sky.setHdr((short) len_in1, in1, str_sizes);
                                    } catch (Exception ex) {
                                    }

                                    sky = new Tuple(sky.size());

                                    try {
                                        sky.setHdr((short) len_in1, in1, str_sizes);
                                    } catch (Exception ex) {
                                    }
                                    sky = sfs.get_next();
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }

                            // delete the heapfile which has group tuples
                            try {
                                grouptuples.deleteFile();
                            } catch (Exception ex) {
                                ex.printStackTrace();
                            }

                            // reinitialise the heapfile
                            try {
                                grouptuples = new Heapfile("groupskyline");
                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                            // insert first tuple of new group into the file
                            try {
                                grouptuples.insertRecord(t1.returnTupleByteArray());
                            } catch (Exception ex) {
                                ex.printStackTrace();
                            }

                            // reinitialize the grp variable
                            grp3 = t1.getIntFld(group_by_attr.offset);

                        }
                        // old group
                        else {
                            try {
                                grouptuples.insertRecord(t1.returnTupleByteArray());
                            } catch (Exception ex) {
                                ex.printStackTrace();
                            }
                        }
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            try {

                // find the skyline of the previous group
                int[] pref_list = new int[agg_list.length];
                for (int i = 0; i < agg_list.length; i++) {
                    pref_list[i] = agg_list[i].offset;
                }
                BlockNestedLoopSky sfs = null;
                try {
                    sfs = new BlockNestedLoopSky(in1, len_in1, t1_str_sizes, (FileScan) am1, "groupskyline", pref_list,
                            pref_list.length, n_pages);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                Tuple sky1 = new Tuple();
                try {
                    sky1.setHdr((short) len_in1, in1, str_sizes);
                } catch (Exception ex) {
                }

                sky1 = new Tuple(sky1.size());

                try {
                    sky1.setHdr((short) len_in1, in1, str_sizes);
                } catch (Exception ex) {
                }

                try {
                    sky1 = sfs.get_next();
                } catch (Exception e) {
                    e.printStackTrace();
                }

                while (sky1 != null) {
                    try {
                        groupby_heapfile.insertRecord(new Tuple(sky1).returnTupleByteArray());
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                    try {
                        try {
                            sky1.setHdr((short) len_in1, in1, str_sizes);
                        } catch (Exception ex) {
                        }

                        sky1 = new Tuple(sky1.size());

                        try {
                            sky1.setHdr((short) len_in1, in1, str_sizes);
                        } catch (Exception ex) {
                        }
                        sky1 = sfs.get_next();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

                // delete the heapfile which has group tuples
                try {
                    grouptuples.deleteFile();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
                sortedf.closescan();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

        if (agg_type.aggType == AggType.avg) {
            FldSpec[] projlist10 = new FldSpec[2];
            RelSpec rel10 = new RelSpec(RelSpec.outer);
            for (int i = 0; i < 2; i++) {
                projlist10[i] = new FldSpec(rel10, i + 1);
            }
            fscan_get_next = new FileScan("groupbysorted", avgAtt_, t1_str_sizes, (short) (2), 2, projlist10, null);
        } else {
            fscan_get_next = new FileScan("groupbysorted", in1_, t1_str_sizes, (short) len_in1_, len_in1_, projlist,
                    null);
        }

    }

    @Override
    public Tuple get_next() throws Exception {

        if (agg_type_.aggType == AggType.avg) {
            FldSpec[] projlist = new FldSpec[2];
            RelSpec rel = new RelSpec(RelSpec.outer);
            for (int i = 0; i < 2; i++) {
                projlist[i] = new FldSpec(rel, i + 1);
            }
        } else {
            // create an iterator by open a file scan
            FldSpec[] projlist = new FldSpec[len_in1_];
            RelSpec rel = new RelSpec(RelSpec.outer);

            for (int i = 0; i < len_in1_; i++) {
                projlist[i] = new FldSpec(rel, i + 1);
            }
        }
        return fscan_get_next.get_next();
    }

    @Override
    public void close() throws IOException, JoinsException, SortException {

        Heapfile x = null;
        try {
            x = new Heapfile("groupbysorted");
            x.deleteFile();
        } catch (Exception e) {
        }
        fscan_get_next.close();
    }

}
