package iterator;

import java.io.*;
import global.*;
import bufmgr.*;
import diskmgr.*;
import heap.*;
import iterator.*;
import index.*;
import java.util.Random;
import btree.*;

public class BTreeSortedSky extends Iterator implements GlobalConst {

    AttrType[] in1_;
    int len_in1_;
    short[] t1_str_sizes_;
    int[] pref_list_;
    int pref_list_length_;
    Iterator am1_;
    BTreeFile index_file_;
    int n_pages_;
    FileScan fscan_get_next = null;
    IndexScan iscan = null;
    byte bufs[][];

    Heapfile f = null; // input file of records
    Heapfile skyline_Heapfile = null; // heapfile to store skyline tuples

    public BTreeSortedSky(AttrType[] in1, int len_in1, short[] t1_str_sizes, Iterator am1,
            java.lang.String relationName, int[] pref_list, int pref_list_length, BTreeFile index_file, int n_pages)
            throws Exception {

        in1_ = in1;
        len_in1_ = len_in1;
        t1_str_sizes_ = t1_str_sizes;
        pref_list_ = pref_list;
        pref_list_length_ = pref_list_length;
        am1_ = am1;
        index_file_ = index_file;
        n_pages_ = n_pages;

        // heapfile which has input data
        f = new Heapfile(relationName);

        // heapfile to store the resultant skyline tuples
        skyline_Heapfile = new Heapfile("skyline5.in");

        // open the index file
        try {
            index_file = new BTreeFile("indexfile5");
        } catch (Exception e) {
            e.printStackTrace();
        }

        FldSpec[] projlist = new FldSpec[len_in1];
        RelSpec rel = new RelSpec(RelSpec.outer);

        for (int i = 0; i < len_in1; i++) {
            projlist[i] = new FldSpec(rel, i + 1);
        }

        // start the scan on the index file
        try {
            iscan = new IndexScan(new IndexType(IndexType.B_Index), relationName, "indexfile5", in1, t1_str_sizes,
                    len_in1, len_in1, projlist, null, 2, false);
        } catch (Exception e) {
            e.printStackTrace();
        }

        Tuple t = new Tuple(); // outer
        try {
            t.setHdr((short) len_in1, in1, t1_str_sizes); // outer
        } catch (Exception e) {
            e.printStackTrace();
        }

        t = new Tuple(t.size());
        try {
            t.setHdr((short) len_in1, in1, t1_str_sizes); // outer
        } catch (Exception e) {
            e.printStackTrace();
        }

        // buffer for finding the skyline
        skBuf skb = new skBuf();

        // temporary heap file if the buffer is full.
        Heapfile temp = null;
        try {
            temp = new Heapfile("temp_file");
        } catch (Exception e) {
            e.printStackTrace();
        }

        bufs = new byte[n_pages][];
        for (int k = 0; k < n_pages; k++)
            bufs[k] = new byte[MAX_SPACE];
        // get_buffe_pages sort.java

        boolean runVar = false;
        if (runVar == false) {
            skb.init(bufs, n_pages, (int) t.size(), temp, skyline_Heapfile);
        }

        // enter the first tuple into the buffer by default
        RID ri = new RID();
        try {
            t.tupleCopy(iscan.get_next());
            skb.Put(t);
            // try {
            //     ri = skyline_Heapfile.insertRecord(t.returnTupleByteArray());
            // } catch (Exception e) {
            //     e.printStackTrace();
            // }
            // System.out.printf("The skyline tuple is: %d %d \n", t.);
        } catch (Exception e) {
            e.printStackTrace();
        }

        int count = 1;
        // while loop is outer loop on remaining tuples
        while (count < f.getRecCnt()) {
            try {
                count++;

                try {
                    t.setHdr((short) len_in1, in1, t1_str_sizes);
                } catch (Exception e) {
                }

                t = new Tuple(t.size());
                try {
                    t.setHdr((short) len_in1, in1, t1_str_sizes);
                } catch (Exception e) {
                }
                t.tupleCopy(iscan.get_next());

                if (skb.BufCompareForDomination(t, in1, (short) len_in1, t1_str_sizes, pref_list)) {
                    // try {
                    //     ri = skyline_Heapfile.insertRecord(t.returnTupleByteArray());
                    // } catch (Exception e) {
                    // }
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        skb.flush();
        // close index scan
        try {
            iscan.close();
        } catch (IndexException e1) {
            e1.printStackTrace();
        }

        // create new heap file if buffer gets full
        // two heap files are enough because when one is being used the other will
        // always be empty
        // both these files are temp("temp_file") and tempone ("temp_file_one")
        Heapfile tempone = null;
        try {
            tempone = new Heapfile("temp_file_one");
        } catch (Exception e) {
            e.printStackTrace();
        }

        runVar = true;
        // the entire logic here should be in a loop until we find all the skyline
        // objects
        while (runVar == true && temp.getRecCnt() > 0 || runVar == false && tempone.getRecCnt() > 0) {
            // empty the buffer for the next run
            if (runVar == false) {
                skb.set_temp_fd(temp);
            } else if (runVar == true) {
                skb.set_temp_fd(tempone);
            }
            skb.setT_wr_to_buf(0);
            skb.setT_wr_to_pg(0);
            skb.setCurr_page(0);
            skb.setT_written(0);

            // scan the heap file which has the current tuples of the outer loop

            // create an scan on the heapfile conataining the data
            Scan scanner = null;

            try {
                if (runVar == true) {
                    scanner = new Scan(temp);
                } else if (runVar == false) {
                    scanner = new Scan(tempone);
                }
            } catch (Exception e) {
                e.printStackTrace();
                Runtime.getRuntime().exit(1);
            }

            RID r = new RID();
            Tuple outerT = new Tuple();
            try {
                outerT.setHdr((short) len_in1, in1, t1_str_sizes);
            } catch (InvalidTypeException e1) {
                e1.printStackTrace();
            }
            outerT = new Tuple(outerT.size());
            try {
                outerT.setHdr((short) len_in1, in1, t1_str_sizes);
            } catch (Exception e) {
            }

            // enter the first tuple into the buffer by default
            try {
                outerT.tupleCopy(scanner.getNext(r));
                skb.Put(outerT);
                // try {
                //     ri = skyline_Heapfile.insertRecord(outerT.returnTupleByteArray());
                // } catch (Exception e) {
                // }
                // System.out.printf("The skyline tuple is: %d %d \n", outerT.getIntFld(1),
                // outerT.getIntFld(2));
            } catch (Exception e) {
                e.printStackTrace();
            }

            // loop over the remaining heap file tuples
            int count1 = 1;
            while (count1 < temp.getRecCnt() && runVar == true || count1 < tempone.getRecCnt() && runVar == false) {
                try {
                    count1++;
                    outerT.tupleCopy(scanner.getNext(r));
                    if (skb.BufCompareForDomination(outerT, in1, (short) len_in1, t1_str_sizes, pref_list)) {
                        // try {
                        //     ri = skyline_Heapfile.insertRecord(outerT.returnTupleByteArray());
                        // } catch (Exception e) {
                        // }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            skb.flush();
            // close the heap file scanner
            scanner.closescan();

            // empty the heap file which acted as the outer loop
            if (runVar == true) {
                try {
                    temp.deleteFile();
                    temp = new Heapfile("temp_file");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else if (runVar == false) {
                try {
                    tempone.deleteFile();
                    tempone = new Heapfile("temp_file_one");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            runVar = !runVar;
        }
        fscan_get_next = new FileScan("skyline5.in", in1_, t1_str_sizes, (short) len_in1_, len_in1_, projlist, null);
    }

    @Override
    public Tuple get_next() throws IOException, JoinsException, IndexException, InvalidTupleSizeException,
            InvalidTypeException, PageNotReadException, TupleUtilsException, PredEvalException, SortException,
            LowMemException, UnknowAttrType, UnknownKeyTypeException, Exception {

        // create an iterator by open a file scan
        FldSpec[] projlist = new FldSpec[len_in1_];
        RelSpec rel = new RelSpec(RelSpec.outer);

        for (int i = 0; i < len_in1_; i++) {
            projlist[i] = new FldSpec(rel, i + 1);
        }

        return fscan_get_next.get_next();
    }

    @Override
    public void close() throws IOException, JoinsException, SortException, IndexException {
        //delHeapFile();
        Heapfile x = null;
        try{
            x = new Heapfile("skyline5.in");
            x.deleteFile();
        }catch(Exception e){}
        fscan_get_next.close();
    }
}
