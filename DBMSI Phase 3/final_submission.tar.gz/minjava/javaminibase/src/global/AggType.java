package global;

/** 
 * Enumeration class for AggType
 * 
 */

public class AggType {

  public static final int max  = 0;
  public static final int min = 1;
  public static final int avg    = 2;
  public static final int skyline  = 3;
  
  public int aggType;

  /** 
   * AggType Constructor
   * <br>
   * An attribute type of String can be defined as 
   * <ul>
   * <li>   AggType aggType = new AggType(AggType.max);
   * </ul>
   * and subsequently used as
   * <ul>
   * <li>   if (aggType.aggType == AggType.max) ....
   * </ul>
   *
   * @param _aggType The types of aggregate functions available in this class
   */

  public AggType (int _aggType) {
    aggType = _aggType;
  }

  public String toString() {

    switch (aggType) {
    case max:
      return "max";
    case min:
      return "min";
    case avg:
      return "avg";
    case skyline:
      return "skyline";
    }
    return ("Unexpected AggType " + aggType);
  }
}
