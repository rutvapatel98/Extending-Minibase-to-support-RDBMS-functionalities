package skyline;

import java.util.ArrayList;
import java.util.Scanner;

import btree.BTreeFile;
import btree.FloatKey;
import diskmgr.pcounter;
import global.AttrType;
import global.GlobalConst;
import global.RID;
import global.SystemDefs;
import heap.Heapfile;
import heap.Scan;
import heap.Tuple;
import iterator.BTreeSortedSky;
import iterator.Iterator;
import iterator.SortFirstSky;

import java.io.*;

public class task33file2or3 implements GlobalConst {
    private static String dbpath;

    static void before_creating_heapfile() {
        String nameRoot = "task6";
        dbpath = "/tmp/" + nameRoot + System.getProperty("user.name") + ".minibase-db";
        String logpath = "/tmp/" + nameRoot + System.getProperty("user.name") + ".minibase-log";
        SystemDefs sysdef = new SystemDefs(dbpath, 1000000, 1000, "Clock");

        // Kill anything that might be hanging around
        String newdbpath;
        String newlogpath;
        String remove_logcmd;
        String remove_dbcmd;
        String remove_cmd = "/bin/rm -rf ";

        newdbpath = dbpath;
        newlogpath = logpath;

        remove_logcmd = remove_cmd + logpath;
        remove_dbcmd = remove_cmd + dbpath;

        // Commands here is very machine dependent. We assume
        // user are on UNIX system here
        try {
            Runtime.getRuntime().exec(remove_logcmd);
            Runtime.getRuntime().exec(remove_dbcmd);
        } catch (IOException e) {
            System.err.println("" + e);
        }

        remove_logcmd = remove_cmd + newlogpath;
        remove_dbcmd = remove_cmd + newdbpath;

        try {
            Runtime.getRuntime().exec(remove_logcmd);
            Runtime.getRuntime().exec(remove_dbcmd);
        } catch (IOException e) {
            System.err.println("" + e);
        }
    }

    static void after_creating_heapfile() {
        String nameRoot = "task6";
        String dbpath = "/tmp/" + nameRoot + System.getProperty("user.name") + ".minibase-db";
        String logpath = "/tmp/" + nameRoot + System.getProperty("user.name") + ".minibase-log";

        String newdbpath;
        String newlogpath;
        String remove_logcmd;
        String remove_dbcmd;
        String remove_cmd = "/bin/rm -rf ";

        newdbpath = dbpath;
        newlogpath = logpath;

        remove_logcmd = remove_cmd + newlogpath;
        remove_dbcmd = remove_cmd + newdbpath;
        try {
            Runtime.getRuntime().exec(remove_logcmd);
            Runtime.getRuntime().exec(remove_dbcmd);
        } catch (IOException e) {
            System.err.println("" + e);
        }
    }

    static void create_heapfile(String input_filepath, AttrType[] attr, int num_cols, short[] str_sizes,
            String output_heapfile) {
        String nameRoot = "task6";
        String dbpath = "/tmp/" + nameRoot + System.getProperty("user.name") + ".minibase-db";
        System.out.println(dbpath);
        SystemDefs sysdef = new SystemDefs(dbpath, 10000, 1000, "Clock");

        // before_creating_heapfile();
        File file = new File(input_filepath);
        ArrayList<Tuple> outerAL = new ArrayList();

        Tuple tup_temp = new Tuple();
        try {
            tup_temp.setHdr((short) num_cols, attr, str_sizes);
        } catch (Exception e) {
            System.out.println(e);
        }
        int size = tup_temp.size();
        tup_temp = new Tuple(size);
        try {
            tup_temp.setHdr((short) num_cols, attr, str_sizes);
        } catch (Exception e) {
            System.out.println(e);
        }

        try {
            Scanner sc = new Scanner(file);
            String gb = sc.nextLine();
            int count = 0;
            while (sc.hasNextLine()) {
                count++;
                String line = sc.nextLine();
                String[] tokens = line.split("\\t");
                int k =0;
                for (int i = 0; i < tokens.length; i++) {
                    if(tokens[i].equals("")){
                        continue;
                    }
                    if (attr[k].attrType == AttrType.attrInteger) {
                        tup_temp.setIntFld(i + 1, Integer.parseInt(tokens[i]));
                    }
                    if (attr[k].attrType == AttrType.attrReal) {
                        tup_temp.setFloFld(k+ 1, Float.parseFloat(tokens[i]));
                    }
                    if (attr[k].attrType == AttrType.attrString) {
                        tup_temp.setStrFld(i + 1, tokens[i]);
                    }
                    if (attr[k].attrType == AttrType.attrSymbol) {
                        tup_temp.setStrFld(i + 1, tokens[i]);
                    }
                    if (attr[k].attrType == AttrType.attrNull) {
                        tup_temp.setStrFld(i + 1, tokens[i]);
                    }
                    k++;
                }
                outerAL.add(tup_temp);
                tup_temp = new Tuple(size);
                try {
                    tup_temp.setHdr((short) num_cols, attr, str_sizes);
                } catch (Exception e) {
                    System.out.println(e);
                }
            }
            System.out.println(count);
            sc.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        Heapfile hf = null;
        RID rid;
        try {
            hf = new Heapfile(output_heapfile);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Tuple tf;
        for (Tuple t : outerAL) {
            try {
                rid = hf.insertRecord(t.returnTupleByteArray());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    static void tests(AttrType[] attrs, int num_cols, short[] str_sizes, int[] pref_list, int n_pages,
            String heapfilename) {
        pcounter.rcounter = 0;
        pcounter.wcounter = 0;
        Iterator am1 = null;
       
        // short attrLen = (short) attrType.length;
        SortFirstSky sfs = null;
        try {
            sfs = new SortFirstSky(attrs, attrs.length, str_sizes, am1, heapfilename, pref_list, pref_list.length, n_pages);
        } catch (Exception e) {
            e.printStackTrace();
        }

        Tuple t = new Tuple();
        try {
            t.setHdr((short) num_cols, attrs, str_sizes);
        } catch (Exception e) {
        }

        t = new Tuple(t.size());
        try {
            t.setHdr((short) num_cols, attrs, str_sizes);
        } catch (Exception e) {
        }

        try {
            t = sfs.get_next();
        } catch (Exception e) {
            e.printStackTrace();
        }

        while (t != null) {
            try {
                System.out.println(t.getFloFld(1) + " " + t.getFloFld(2) + " " + t.getFloFld(3) + " " + t.getFloFld(4)
                        + " " + t.getFloFld(5));
            } catch (Exception e) {
                e.printStackTrace();
            }
            try {
                t = sfs.get_next();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        if (t == null) {

            try {
                sfs.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        System.out.printf("Number of reads: %d \n", pcounter.rcounter);
        System.out.printf("Number of writes: %d \n", pcounter.wcounter);
    }

    public static void main(String Args[]) {
        String filename1 = "../src/input_files/data3.txt";

        AttrType[] attrs;
        int num_cols = 5;

        attrs = new AttrType[5];
        for (int i = 0; i < 5; i++) {
            attrs[i] = new AttrType(AttrType.attrReal);
        }

        int sizeOfInt = 4;
        int sizeOfFloat = 4;
        int max = 10; // comes from attrData char strVal[10]
        if (sizeOfInt > max)
            max = (short) sizeOfInt;
        if (sizeOfFloat > max)
            max = (short) sizeOfFloat;

        short[] str_sizes = new short[1];
        str_sizes[0] = (short) max;

        // task 5 test
        Iterator am1 = null;
        short[] t1_str_sizes = new short[attrs.length];

        // create heapfile from input data3
        create_heapfile(filename1, attrs, num_cols, str_sizes, "task6three33hf.in");

        before_creating_heapfile();
        int[] pref_list1 = { 1 };
        int[] pref_list2 = { 1, 3 };
        int[] pref_list3 = { 1, 3, 5 };
        int[] pref_list4 = { 1, 2, 3, 4, 5 };

        int n_pages1 = 5;
        int n_pages2 = 10;
        // int n_pages3 = number of input tuples/tuple per page
        int n_pages3 = 915;

        // MINIBASE_PAGESIZE = 128;

        //create heapfile from input data2
        create_heapfile(filename1, attrs, num_cols, str_sizes, "task6three33hf.in");
        after_creating_heapfile();

        System.out.println("----------------------------------DATA FILE 2 PAGE SIZE 1024--------------------------------------- ");

        System.out.printf("n_pages = 5 and preference attributes = 1\n");
        tests(attrs, num_cols, str_sizes, pref_list1, n_pages1, "task6three33hf.in");
        Process proc;
        try {
            proc = Runtime.getRuntime().exec("rm -rf" + dbpath);
            proc.waitFor();
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
        System.out.printf("n_pages = 10 and preference attributes = 1\n");
        tests(attrs, num_cols, str_sizes, pref_list1, n_pages2, "task6three33hf.in");
        try {
            proc = Runtime.getRuntime().exec("rm -rf" + dbpath);
            proc.waitFor();
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
        System.out.printf("n_pages = 915 and preference attributes = 1\n");
        tests(attrs, num_cols, str_sizes, pref_list1, n_pages3, "task6three33hf.in");
        try {
            proc = Runtime.getRuntime().exec("rm -rf" + dbpath);
            proc.waitFor();
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }

        System.out.printf("n_pages = 5 and preference attributes = 1, 3\n");
        tests(attrs, num_cols, str_sizes, pref_list2, n_pages1, "task6three33hf.in");
        try {
            proc = Runtime.getRuntime().exec("rm -rf" + dbpath);
            proc.waitFor();
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
        System.out.printf("n_pages = 10 and preference attributes = 1, 3\n");
        tests(attrs, num_cols, str_sizes, pref_list2, n_pages2, "task6three33hf.in");
        try {
            proc = Runtime.getRuntime().exec("rm -rf" + dbpath);
            proc.waitFor();
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
        System.out.printf("n_pages = 915 and preference attributes = 1, 3\n");
        tests(attrs, num_cols, str_sizes, pref_list1, n_pages3, "task6three33hf.in");
        try {
            proc = Runtime.getRuntime().exec("rm -rf" + dbpath);
            proc.waitFor();
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }

        System.out.printf("n_pages = 5 and preference attributes = 1, 3, 5\n");
        tests(attrs, num_cols, str_sizes, pref_list3, n_pages1, "task6three33hf.in");
        try {
            proc = Runtime.getRuntime().exec("rm -rf" + dbpath);
            proc.waitFor();
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
        System.out.printf("n_pages = 10 and preference attributes = 1, 3, 5\n");
        tests(attrs, num_cols, str_sizes, pref_list3, n_pages2, "task6three33hf.in");
        try {
            proc = Runtime.getRuntime().exec("rm -rf" + dbpath);
            proc.waitFor();
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
        System.out.printf("n_pages = 915 and preference attributes = 1, 3, 5\n");
        tests(attrs, num_cols, str_sizes, pref_list1, n_pages3, "task6three33hf.in");
        try {
            proc = Runtime.getRuntime().exec("rm -rf" + dbpath);
            proc.waitFor();
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }

        System.out.printf("n_pages = 5 and preference attributes = 1, 2, 3, 4, 5\n");
        tests(attrs, num_cols, str_sizes, pref_list4, n_pages1, "task6three33hf.in");
        try {
            proc = Runtime.getRuntime().exec("rm -rf" + dbpath);
            proc.waitFor();
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
        System.out.printf("n_pages = 10 and preference attributes = 1, 2, 3, 4, 5\n");
        tests(attrs, num_cols, str_sizes, pref_list4, n_pages2, "task6three33hf.in");
        try {
            proc = Runtime.getRuntime().exec("rm -rf" + dbpath);
            proc.waitFor();
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
        System.out.printf("n_pages = 915 and preference attributes = 1, 2, 3, 4, 5\n");
        tests(attrs, num_cols, str_sizes, pref_list1, n_pages3, "task6three33hf.in");
        try {
            proc = Runtime.getRuntime().exec("rm -rf" + dbpath);
            proc.waitFor();
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }

    }

}
