package iterator;
import java.io.*; 
import global.*;
import bufmgr.*;
import diskmgr.*;
import heap.*;
import iterator.*;
import index.*;
import java.util.Random;

public class SortFirstSky extends Iterator implements GlobalConst{

    AttrType[] in1_;
    int len_in1_;
    short[] t1_str_sizes_;
    int[] pref_list_;
    int pref_list_length_;
    FileScan fscan_get_next = null;

    Heapfile        f = null;
    Heapfile        skyline_Heapfile = null;

    private static int   SORTPGNUM = 12; 
    private static byte[][] bufs;
    
    public SortFirstSky(AttrType[] in1, int len_in1, short[] t1_str_sizes,Iterator am1, java.lang.String
    relationName, int[] pref_list, int pref_list_length,int n_pages) throws Exception

    {
        in1_ = in1;
        len_in1_ = len_in1;
        t1_str_sizes_ = t1_str_sizes;
        pref_list_ = pref_list;
        pref_list_length_ = pref_list_length;

        f = new Heapfile(relationName);
        skyline_Heapfile = new Heapfile("skyline33.in");

        // create a tuple of appropriate size
        Tuple t = new Tuple();
        
        t.setHdr((short) len_in1, in1, null);
        
        t = new Tuple(t.size());
       
        t.setHdr((short) in1.length, in1, null);
        
        // create an iterator by open a file scan
        FldSpec[] projlist = new FldSpec[len_in1];
        RelSpec rel = new RelSpec(RelSpec.outer);

        for(int i = 0; i < len_in1; i++)
        {
            projlist[i] = new FldSpec(rel, i+1);
        }

        FileScan fscan = null;
        
        
        fscan = new FileScan(relationName, in1, null, (short) len_in1, len_in1, projlist, null);
       

        TupleOrder[] order = new TupleOrder[2];
        order[0] = new TupleOrder(TupleOrder.Ascending);
        order[1] = new TupleOrder(TupleOrder.Descending);
        
        SortPref sort = null;
        
        sort = new SortPref(in1, (short) len_in1, null, fscan, order[1], pref_list, pref_list_length, n_pages);


        // buffer for finding the skyline
        skBuf skb = new skBuf();
        boolean runVar = false;

        // temporary heap file if the buffer is full.
        Heapfile temp = null;
        try {
            temp = new Heapfile("temp_file");
        } catch (Exception e) {
            e.printStackTrace();
        }

        bufs = new byte[n_pages][];
        for (int k = 0; k < n_pages; k++)
            bufs[k] = new byte[MAX_SPACE];
        // get_buffe_pages sort.java

        if (runVar == false) {
            skb.init(bufs, n_pages, (int) t.size(), temp);
        }

        // enter the first tuple into the buffer by default
        t.setHdr((short)len_in1, in1, null);
        t = new Tuple(t.size());
        t.setHdr((short)len_in1, in1, null);
        t = sort.get_next();
        if(t!=null){
            t.setHdr((short)len_in1, in1, null);
            //t.tupleCopy(sort.get_next());
            skb.Put(t);
        }
       
        //System.out.printf("The skyline tuple is: %d %d \n", t.getIntFld(1), t.getIntFld(2));
        
        //System.out.println("inserting into heap: "+ t.getIntFld(1) + " " + t.getIntFld(2));
        skyline_Heapfile.insertRecord(t.returnTupleByteArray());

        int count = 1;
        // while loop is outer loop on remaining tuples
        while (count < f.getRecCnt()) {
            try {
                count++;
                // t = new Tuple();
                t.setHdr((short) len_in1, in1, null);
                t = new Tuple(t.size());
                t.setHdr((short) len_in1, in1, null);
               
                t.tupleCopy(sort.get_next());

                // System.out.println("inner loop");
                if(skb.BufCompareForDomination(t, in1, (short)len_in1, null, pref_list)) 
                {
                    //System.out.println("inserting into heap: "+ t.getIntFld(1) + " " + t.getIntFld(2));
                    skyline_Heapfile.insertRecord(t.returnTupleByteArray());
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        try{
            sort.close();
        }catch(Exception e){
        }
        

        // create new heap file if buffer gets full
        // two heap files are enough because when one is being used the other will
        // always be empty
        // both these files are temp("temp_file") and tempone ("temp_file_one")
        Heapfile tempone = null;
       
        tempone = new Heapfile("temp_file_one");

        runVar = true;

        while (runVar == true && temp.getRecCnt() > 0 || runVar == false && tempone.getRecCnt() > 0)
        {
            // empty the buffer for the next run
            if (runVar == false) {
                skb.set_temp_fd(temp);
            } else if (runVar == true) {
                skb.set_temp_fd(tempone);
            }
            skb.setT_wr_to_buf(0);
            skb.setT_wr_to_pg(0);
            skb.setCurr_page(0);
            skb.setT_written(0);

            // scan the heap file which has the current tuples of the outer loop

            // create an scan on the heapfile conataining the data
            Scan scanner = null;

            
            if (runVar == true) {
                scanner = new Scan(temp);
            } else if (runVar == false) {
                scanner = new Scan(tempone);
            }
        

            RID r = new RID();
            Tuple outerT = new Tuple();
            outerT.setHdr((short)len_in1, in1, null);
        
            outerT = new Tuple(outerT.size());
        
            outerT.setHdr((short) len_in1, in1, null);
            

            // enter the first tuple into the buffer by default
        
            outerT.tupleCopy(scanner.getNext(r));
            skb.Put(outerT);
            skyline_Heapfile.insertRecord(outerT.returnTupleByteArray());
            //System.out.printf("The skyline tuple is: %d %d \n", outerT.getIntFld(1), outerT.getIntFld(2));
        

            // loop over the remaining heap file tuples
            int count1 = 1;
            while (count1<temp.getRecCnt() && runVar==true || count1<tempone.getRecCnt() && runVar==false) {
                
                count1++;
                outerT.setHdr((short)len_in1, in1, null);
        
                outerT = new Tuple(outerT.size());
        
                outerT.setHdr((short) len_in1, in1, null);

                outerT.tupleCopy(scanner.getNext(r));
                if(skb.BufCompareForDomination(outerT, in1, (short)len_in1, null, pref_list)){
                    skyline_Heapfile.insertRecord(outerT.returnTupleByteArray());
                }
                
            }

            //close the heap file scanner
            scanner.closescan();

            

            // empty the heap file which acted as the outer loop
            if (runVar == true) {
                try {
                    temp.deleteFile();
                    temp = new Heapfile("temp_file");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else if (runVar == false) {
                try {
                    tempone.deleteFile();
                    tempone = new Heapfile("temp_file_one");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            runVar = !runVar;

        
    }
        
    fscan_get_next = new FileScan("skyline33.in", in1_, null, (short) len_in1_, len_in1_, projlist, null);
    }

    @Override
    public Tuple get_next() throws IOException, JoinsException, IndexException, InvalidTupleSizeException,
            InvalidTypeException, PageNotReadException, TupleUtilsException, PredEvalException, SortException,
            LowMemException, UnknowAttrType, UnknownKeyTypeException, Exception {
       

        // create an iterator by open a file scan
        FldSpec[] projlist = new FldSpec[len_in1_];
        RelSpec rel = new RelSpec(RelSpec.outer);

        for(int i = 0; i < len_in1_; i++)
        {
            projlist[i] = new FldSpec(rel, i+1);
        }

        return fscan_get_next.get_next();
        
    }

    @Override
    public void close() throws IOException, JoinsException, SortException, IndexException {
        fscan_get_next.close();
    }
}
