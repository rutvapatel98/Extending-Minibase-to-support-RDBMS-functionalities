package iterator;

import java.io.*; 
import global.*;
import bufmgr.*;
import diskmgr.*;
import heap.*;
import index.*;
import chainexception.*;

import skyline.*;
import java.util.*;
public class BlockNestedLoopSky extends Iterator implements GlobalConst
{
      
  private AttrType[]        _in;   
  private int                len_in;    
  private short[]           t1_str_sizes;
  private FileScan          am1;
  private java.lang.String  relationName;
  private int[]             pref_list;
  private int               pref_list_length;
  private int               n_pages;

  private int               max_skyline_size; 
  private boolean           first_time;
  private ArrayList<Tuple>   skylines;
  private Tuple             am;
  private ArrayList<RID> rid_list; 
  private Heapfile f;

  public BlockNestedLoopSky(
        AttrType[]        in,
        int                _len_in,
        short[]           _t1_str_sizes,
        FileScan          _am1,
        java.lang.String  _relationName,
        int[]             _pref_list,
        int               _pref_list_length,
        int               _n_pages
          
        )
    throws IOException
    {
      _in = new AttrType[in.length];
      System.arraycopy(in,0,_in,0,in.length);
      len_in = _len_in;
      t1_str_sizes = new short[_t1_str_sizes.length];
      System.arraycopy(_t1_str_sizes,0,t1_str_sizes,0,_t1_str_sizes.length);
      am1=_am1;
      relationName = _relationName;
      pref_list = new int[_pref_list.length];
      System.arraycopy(_pref_list,0,pref_list,0,_pref_list.length);
      pref_list_length = _pref_list_length;
      n_pages= _n_pages;  
      skylines = new ArrayList<Tuple>();
      first_time=true;
       
    }
  
    public Tuple get_next() 
    throws InvalidSlotNumberException, HFException, HFDiskMgrException, HFBufMgrException, Exception
    {
      if(first_time) {
        first_time= false;
        compute_skyline();
      }
      if(!skylines.isEmpty()){
        Tuple temp= skylines.get(0);
        skylines.remove(0);
        return temp;
      }
      return null;
    }  
  
    private void compute_skyline() throws InvalidSlotNumberException, HFException, HFDiskMgrException, HFBufMgrException, Exception
    {
      ArrayList<Tuple> skyline_data = new ArrayList<Tuple>();
      am=am1.get_next();
      
      max_skyline_size = (n_pages * 1024)/am.size() ;
      //max_skyline_size = 4 ;
      
      
      System.out.printf("\n max_skyline_size %d",max_skyline_size);
      rid_list= new ArrayList <RID>();

      while(true)
      {     
        System.out.printf("\n rid_list size %d",rid_list.size());
        ArrayList<Tuple> skylines_dominated = new ArrayList<Tuple>();
        ArrayList<RID> rid_skylines_dominated = new ArrayList<RID>();
        
        if (am==null)
          {break;
          }
        else{
          boolean result_sky= true;
          if(skyline_data.size()==0)
          {
            skyline_data.add(am);
            
          }
          else
          {
            //compare with buf
            for(int i =0; i<skyline_data.size(); i++)
            {
                if(SK.Dominates(skyline_data.get(i),_in,am,_in,(short)len_in,t1_str_sizes,pref_list,pref_list_length)==1)
                {
                result_sky=false;
                break;
                }
                if(SK.Dominates(am,_in,skyline_data.get(i),_in,(short)len_in,t1_str_sizes,pref_list,pref_list_length)==1)
                {
                
                skylines_dominated.add(skyline_data.get(i));
                }
            }

            //compare with heap
            if(rid_list.size()!=0)
            {
            for(int i =0; i<rid_list.size(); i++)
            {
              System.out.println(rid_list.get(i));
              f.getRecord(rid_list.get(i)).print(_in);
  
              if(SK.Dominates(f.getRecord(rid_list.get(i)),_in,am,_in,(short)len_in,t1_str_sizes,pref_list,pref_list_length)==1)
                {
                result_sky=false;
                break;
                }
                if(SK.Dominates(am,_in,f.getRecord(rid_list.get(i)),_in,(short)len_in,t1_str_sizes,pref_list,pref_list_length)==1)
                {
                rid_skylines_dominated.add(rid_list.get(i));
                }
            }

            //remove dominated heap file elements
            
            for(int i=0; i<rid_skylines_dominated.size();i++)
            {
              f.deleteRecord(rid_skylines_dominated.get(i));
              rid_list.remove(rid_skylines_dominated.get(i));
            }
          }
            
            skyline_data.removeAll(skylines_dominated);
            if(result_sky == true)
            {
                if(skyline_data.size()<max_skyline_size && rid_list.size()==0)
                skyline_data.add(new Tuple(am));
                else{
                //logic to use a heap file
                    if(rid_list.size()==0)
                    {
                    //create a file and write element to it
                      f=null;
                      try {
                      f = new Heapfile("bnested.in");
                      }
                      catch (Exception e) {
                        System.err.println("*** error in Heapfile constructor in blocknested***");
                        e.printStackTrace();
                      }

                      Tuple t = new Tuple(am);
                      RID rid=null;
                      try {
                        rid = f.insertRecord(new Tuple(t).returnTupleByteArray());
                            }
                            catch (Exception e) {
                        System.err.println("*** error in Heapfile.insertRecord() blocknested ***");
                        e.printStackTrace();
                            }
                      if(rid!=null)      
                        rid_list.add(rid);
                          }
                      
                    
                    else
                    {
                      //add element to file
                      Tuple t = new Tuple(am);
                      RID rid;
                      try {
                        rid = f.insertRecord(t.returnTupleByteArray());
                        
                        rid_list.add(rid);
                            }
                            catch (Exception e) {
                        System.err.println("*** error in Heapfile.insertRecord() blocknested ***");
                        e.printStackTrace();
                            }      
                          }
                    }
                      
                  }
              }
            }
            
            am=am1.get_next();
          }

      
      
    
    skylines.addAll(skyline_data);
    System.out.printf("---------------------------------------------------------------------------------");
    
    }

    

    public void close() 
    throws JoinsException
    {
      if (!closeFlag) {
	
	try {
	  am1.close();
	}catch (Exception e) {
	  throw new JoinsException(e, "SortMerge.java: error in closing iterator.");
	}
	closeFlag = true;
      }
    }
    
}