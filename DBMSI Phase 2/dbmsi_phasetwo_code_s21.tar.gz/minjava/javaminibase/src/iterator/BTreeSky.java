package iterator;


import java.io.*;
import global.*;
import bufmgr.*;
import diskmgr.*;
import heap.*;
import iterator.*;
import index.*;
import java.util.Random;
import btree.*;

public class BTreeSky extends Iterator implements GlobalConst {

    AttrType[] in1_;
    int len_in1_;
    short[] t1_str_sizes_;
    int[] pref_list_;
    int pref_list_length_;
    Iterator am1_;
    BTreeFile[] index_file_;
    int n_pages_;
    FileScan fscan_get_next = null;
    IndexScan iscan = null;
    byte bufs[][];

    Heapfile        f = null; //input file of records
    Heapfile        skyline_Heapfile = null; //heapfile to store skyline tuples
    Heapfile        skyline_candidate = null; //heapfile to store the skyline candidates tuples
    public BTreeSky(AttrType[] in1, int len_in1, short[] t1_str_sizes, Iterator am1, java.lang.String relationName, int[] pref_list, int pref_list_length, BTreeFile[] btf, int n_pages)
    throws Exception{

        // in1_ = in1;
        // len_in1_ = len_in1;
        // t1_str_sizes_ = t1_str_sizes;
        // pref_list_ = pref_list;
        // pref_list_length_ = pref_list_length;
        // am1_ = am1;
        // index_file_ = btf;
        // n_pages_ = n_pages;

        //heapfile which has input data
       // f = new Heapfile(relationName);
        //heapfile to store the heapfile that is passed in Sort First Sky
        skyline_candidate = new Heapfile("skyline_candidate");
        //heapfile to store the resultant skyline tuples
        skyline_Heapfile = new Heapfile("skyline4.in");
 for(int j=0; j<pref_list.length; j++)
 {
        try {
            btf[j] = new BTreeFile("BTIndex"+j);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        
        System.out.println("BTIndex"+j+ " opened successfully.\n"); 
        
        RID rid = new RID();
        int key1;
        Tuple temp1 = null;

        FldSpec[] projlist = new FldSpec[len_in1];
        RelSpec rel = new RelSpec(RelSpec.outer); 
        for(int k = 0; k < len_in1; k++)
        {
            projlist[k] = new FldSpec(rel, k+1);
        }

        short REC_LEN1 = 32; 
        short REC_LEN2 = 160; 
        short[] attrSize = new short[2];
        attrSize[0] = REC_LEN2;
        attrSize[1] = REC_LEN1;
        
        // start index scan
        IndexScan iscan = null;
        try {
            iscan = new IndexScan(new IndexType(IndexType.B_Index), relationName, "BTIndex"+j, in1, attrSize, len_in1, len_in1, projlist, null, pref_list[j], false);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        

        int count = 0;
        Tuple t = new Tuple();
        try {
            t.setHdr((short)len_in1, in1, null); // outer
        } catch (Exception e) {
            e.printStackTrace();
        }
        int size = t.size();
        t = new Tuple(t.size());

    // t.setHdr((short)len_in1, in1, null);
    // t = new Tuple(t.size());
    // t.setHdr((short)len_in1, in1, null);

        String outval = null;
        
        try {
            t = iscan.get_next();
        }
        catch (Exception e) {
            e.printStackTrace(); 
        }

        if (t == null) {
            System.err.println("no record retrieved");
        }
        
        try {
            t = iscan.get_next();
        }
        catch (Exception e) {
            e.printStackTrace(); 
        }
        
        // clean up
        try {
            iscan.close();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }




            //main logic

            Tuple t = new Tuple();

            Tuple temp_tuple = new Tuple();
            
            try {
                temp_tuple.setHdr((short) len_in1, in1, null);
            } catch (Exception e) {
                e.printStackTrace();
            }
            try {
                t.setHdr((short) len_in1, in1, null);
            } catch (Exception e) {
                e.printStackTrace();
            }
            int size = t.size();

            Tuple iter_tuple = new Tuple(size);
            
            try {
                iter_tuple.setHdr((short) len_in1, in1, null);
            } catch (Exception e) {
                e.printStackTrace();
            }
            // Create unsorted data file "unsortedfile"
            RID ridx;
            Heapfile skyline_candidate = null;
            try {
                skyline_candidate = new Heapfile("skyline_candidate");
            } catch (Exception e) {
                e.printStackTrace();
            }

            

            short[] attrSize = new short[2];
            short REC_LEN1 = 32; 
            short REC_LEN2 = 160; 
            attrSize[0] = REC_LEN2;
            attrSize[1] = REC_LEN1;

           // AttrType  comparison_type = new AttrType(AttrType.attrInteger);
		   //comparison_type.attrType = AttrType.attrInteger;

            
            FldSpec[] projlist = new FldSpec[2];
            RelSpec rel = new RelSpec(RelSpec.outer); 
            projlist[0] = new FldSpec(rel, 1);
            projlist[1] = new FldSpec(rel, 2); 
            for(int i=0; i<pref_list.length; i++)
            {
                if(i==0)
                {
                    //store tuple as temp_tuple to compare with other tuples
                            // start index scan
                            IndexScan iscan1 = null;
                            try {
                                iscan1 = new IndexScan(new IndexType(IndexType.B_Index), "unsortedfile", "BTIndex"+i, in1, attrSize, 2, 2, projlist, null, 2, false);
                                temp_tuple = iscan1.get_next();    
                            }
                            catch (Exception e) {
                                e.printStackTrace();
                                }
                }
                else{
                  //  IndexScan iscan = null;
                            try {
                                iscan = new IndexScan(new IndexType(IndexType.B_Index), "unsortedfile", "BTIndex"+i, in1, attrSize, 2, 2, projlist, null, 2, false);
                                iter_tuple = iscan.get_next();    

                            }
                            catch (Exception e) {
                                e.printStackTrace();
                                }
                    //else compare this to the temp_tuple and add elements in the heap that will be sent to block nested loop
                    //while get next is not null (we dont reach till the end of the btree) we keep comparing til we find temp_tuple    
                    boolean heap_empty = true;
                    while(iter_tuple!=null)
                    {
                        //compare iter_tuple and temp_tuple
                        try {
                            int comp_res = TupleUtils.CompareTupleWithTuple(in1[i], iter_tuple, i+1, temp_tuple, i+1);
                            
                           // boolean comp_res = TupleUtils.Equal(iter_tuple, temp_tuple, attrType[0], 2);

                            if(comp_res==0)
                            {
                                //iter_tuple and temp_tuple are the same
                                //Hence, we break the loop and check in the next pref attribute BTree
                                break;
                            }
                            else if(comp_res > 0)
                            {

                                //insert the iter_tuple in Heap skyline_candidate after checking if it is not there already
                                
                                // create an scan on the heapfile conataining the data
                            
                                FileScan scan_skc_hf = null;
                                projlist = new FldSpec[2];
                                rel = new RelSpec(RelSpec.outer); 
                               // projlist[0] = new FldSpec(rel, 1);
                                //projlist[1] = new FldSpec(rel, 2);


                                 projlist = new FldSpec[len_in1];
                                 rel = new RelSpec(RelSpec.outer); 
                                for(int k = 0; k < len_in1; k++)
                                {
                                    projlist[k] = new FldSpec(rel, k+1);
                                }
                                
                                try {
                                    scan_skc_hf = new FileScan("skyline_candidate", in1, null, (short) len_in1, len_in1, projlist, null);
                                }
                                catch (Exception e) {
                                e.printStackTrace();
                                }
                                RID rid = new RID();

                                rid = new RID();
                                // int key = 0;
                                Tuple temptuple = new Tuple(size);
                                try {
                                    temptuple.setHdr((short) len_in1, in1, null);
                                } catch (Exception e) {

                                    e.printStackTrace();
                                }

                                
                                if(heap_empty)
                                {   
                                    t = new Tuple(size);
                                    try {
                                    t.setHdr((short) len_in1, in1, null);
                                    }
                                    catch (Exception e) {
                                    
                                    e.printStackTrace();
                                    }
                                    t.tupleCopy(temp_tuple);
                                    try {
                                        rid = skyline_candidate.insertRecord(t.returnTupleByteArray());
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                    heap_empty = false;
                                    continue;
                                }
                                try {
                                    temptuple = scan_skc_hf.get_next();
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }

                                boolean iter_tuple_found = false;

                                //while we reach the end of the heapfile 
                                while(temptuple!=null)
                                {
                                    //int comp_tuple = TupleUtils.CompareTupleWithTuple(attrType[0], iter_tuple, 2, temptuple, 2);
                                    boolean comp_tuple = TupleUtils.Equal( iter_tuple,temptuple,in1, 2);
                                    if(comp_tuple== true)
                                    {
                                        iter_tuple_found = true;
                                    }
                                    
                                    try {
                                        temptuple = scan_skc_hf.get_next();
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                }

                                if(!iter_tuple_found)
                                {
                                    try {
                                        t = new Tuple(size);
                                        try {
                                        t.setHdr((short) len_in1, in1, null);
                                        }
                                        catch (Exception e) {
                                        
                                        e.printStackTrace();
                                        }
                                        t.tupleCopy(iter_tuple);

                                        rid = skyline_candidate.insertRecord(t.returnTupleByteArray());
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                }


                                //get next to get next tuple
                                iter_tuple = iscan.get_next();    

                            }
                              }catch (Exception e){
                           // throw new PredEvalException (e,"TupleUtilsException is caught by PredEval.java");
                              }

                    }
                }
            }

            FileScan scan_heapFile = null;
            projlist = new FldSpec[2];
            rel = new RelSpec(RelSpec.outer); 
            // projlist[0] = new FldSpec(rel, 1);
            // projlist[1] = new FldSpec(rel, 2);

            projlist = new FldSpec[len_in1];
            rel = new RelSpec(RelSpec.outer); 
           for(int k = 0; k < len_in1; k++)
           {
               projlist[k] = new FldSpec(rel, k+1);
           }
            
            try {
                scan_heapFile = new FileScan("skyline_candidate", in1, null, (short) len_in1, len_in1, projlist, null);
            }
            catch (Exception e) {
            e.printStackTrace();
            }

                    
                                try {
                                    System.out.println("rec cnt:" + skyline_candidate.getRecCnt());
                                } catch (InvalidSlotNumberException | InvalidTupleSizeException | HFDiskMgrException
                                        | HFBufMgrException | IOException e1) {
                                    // TODO Auto-generated catch block
                                    e1.printStackTrace();
                                }
                                // int key = 0;
                                Tuple tempetuple2 = new Tuple();
                                
                                try {
                                    tempetuple2.setHdr((short) len_in1, in1, null);
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                                try {
                                    tempetuple2 = scan_heapFile.get_next();

                                    
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                                SortFirstSky sfs = null;
                                try{
                                    sfs = new SortFirstSky(in1, in1.length, null, null, "skyline_candidate" , pref_list, pref_list.length,  2);
                                }catch(Exception e){
                                    e.printStackTrace();
                                }

                                try {
                                    t = sfs.get_next();
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                        
                                while(t != null)
                                {
                                    try {
                                        System.out.println(t.getFloFld(1) + " " + t.getFloFld(2));
                                    } catch (FieldNumberOutOfBoundException | IOException e) {
                                        e.printStackTrace();
                                    }
                        
                                    try {
                                        t = sfs.get_next();
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                }

    }

    @Override
    public Tuple get_next() throws IOException, JoinsException, IndexException, InvalidTupleSizeException,
            InvalidTypeException, PageNotReadException, TupleUtilsException, PredEvalException, SortException,
            LowMemException, UnknowAttrType, UnknownKeyTypeException, Exception {
       

        // create an iterator by open a file scan
        FldSpec[] projlist = new FldSpec[len_in1_];
        RelSpec rel = new RelSpec(RelSpec.outer);

        for(int i = 0; i < len_in1_; i++)
        {
            projlist[i] = new FldSpec(rel, i+1);
        }

        return fscan_get_next.get_next();
    }

    @Override
    public void close() throws IOException, JoinsException, SortException, IndexException {
        fscan_get_next.close();
    }
    
}
