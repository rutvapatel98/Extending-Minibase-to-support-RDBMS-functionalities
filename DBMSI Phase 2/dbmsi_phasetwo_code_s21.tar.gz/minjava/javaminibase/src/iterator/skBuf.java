
package iterator;
import heap.*;
import global.*;
import diskmgr.*;
import bufmgr.*;
import skyline.*;

import java.io.*;

public class skBuf implements GlobalConst{
  /**
   * Constructor - use init to initialize.
   */
  public void skBuf(){}             
  
  public Heapfile get_temp_fd() {
	return _temp_fd;
}

public void set_temp_fd(Heapfile _temp_fd) {
	this._temp_fd = _temp_fd;
}

public long getT_written() {
	return t_written;
}

public void setT_written(long t_written) {
	this.t_written = t_written;
}

public int getCurr_page() {
	return curr_page;
}

public void setCurr_page(int curr_page) {
	this.curr_page = curr_page;
}

public int getT_wr_to_pg() {
	return t_wr_to_pg;
}

public void setT_wr_to_pg(int t_wr_to_pg) {
	this.t_wr_to_pg = t_wr_to_pg;
}

public int getT_wr_to_buf() {
	return t_wr_to_buf;
}

public void setT_wr_to_buf(int t_wr_to_buf) {
	this.t_wr_to_buf = t_wr_to_buf;
}

/**
   *Initialize some necessary inormation, call Iobuf to create the
   *object, and call init to finish instantiation
   *@param bufs[][] the I/O buffer
   *@param n_pages the numbers of page of this buffer
   *@param tSize the page size
   *@param temp_fd the reference to a Heapfile
   */ 
  public void init(byte bufs[][], int n_pages, int tSize, Heapfile temp_fd)
    {
      _bufs    = bufs;
      _n_pages = n_pages;
      t_size   = tSize;
      set_temp_fd(temp_fd);
      
      dirty       = false;
      t_per_pg    = MINIBASE_PAGESIZE / t_size;
      t_in_buf    = n_pages * t_per_pg;
      setT_wr_to_pg(0);
      setT_wr_to_buf(0);
      setT_written(0L);
      setCurr_page(0);
      flushed     = false;
      mode        = WRITE_BUFFER;
      i_buf       = new SpoofIbuf();
      done        = false;

      //System.out.println("t_per_pg: " + t_per_pg);
      //System.out.println("t_in_buf: " + t_in_buf);
    }
  
  
  /**
   * Writes a tuple to the output buffer
   *@param buf the tuple written to buffer
   *@exception NoOutputBuffer the buffer is a input bufer now
   *@exception IOException  some I/O fault
   *@exception Exception  other exceptions
   */
  public Tuple Put(Tuple buf)
    throws NoOutputBuffer,
	   IOException,
	   Exception
    {
          if (mode != WRITE_BUFFER)
            throw new NoOutputBuffer("IoBuf:Trying to write to io buffer when it is acting as a input buffer");

            if (getT_wr_to_buf() == t_in_buf)                // Buffer full?
            {
              //System.out.println("buffer is full inserting to heap file");
              flush();                                // Flush it
              RID rid;
              try {
                rid =  _temp_fd.insertRecord(buf.returnTupleByteArray());
              }
              catch (Exception e){
                e.printStackTrace();
                throw e;
              }         
            }
            else if (getT_wr_to_pg() == t_per_pg)
            {
              setT_wr_to_pg(0);
              setCurr_page(getCurr_page() + 1);

              byte[] copybuf;
              copybuf = buf.getTupleByteArray();
              System.arraycopy(copybuf,0,_bufs[getCurr_page()],getT_wr_to_pg()*t_size,t_size); 
          
              setT_written(getT_written() + 1); setT_wr_to_pg(getT_wr_to_pg() + 1); setT_wr_to_buf(getT_wr_to_buf() + 1); dirty = true;
              return buf;
            }      
            else{
              byte[] copybuf;
              copybuf = buf.getTupleByteArray();
              System.arraycopy(copybuf,0,_bufs[getCurr_page()],getT_wr_to_pg()*t_size,t_size); 
              setT_written(getT_written() + 1); setT_wr_to_pg(getT_wr_to_pg() + 1); setT_wr_to_buf(getT_wr_to_buf() + 1); dirty = true;
              return buf;
            }
          return null;
    }
  
  public boolean BufCompareForDomination(Tuple outerTuple, AttrType[] aType, short len_in, short[] str_sizes, int[] pref_list) throws IOException,
  Exception
  {
      int flag = 0;
      boolean ans = false;
       for(int i = 0; i <= getCurr_page(); i++){
          for (int j = 0; j < getT_wr_to_pg(); j++)
          {
             
            //byte[] copybuf;
            //copybuf = outerTuple.getTupleByteArray();
            //System.arraycopy(copybuf,0,_bufs[curr_page],j*t_size,t_size); 
            Tuple tuple_ptr = new Tuple(_bufs[i] , j * t_size,t_size);
            tuple_ptr.setHdr(len_in, aType, str_sizes);
            outerTuple.setHdr(len_in, aType, str_sizes);
                  flag = SK.Dominates(tuple_ptr, aType, outerTuple, aType, len_in, str_sizes, pref_list, pref_list.length);
                  if(flag==1){
                    break;
                  }
          }
        }
        if(flag == 0){
          //insert outer into the buffer or heapfile if buffer is full
          outerTuple = this.Put(outerTuple);
          if(outerTuple!=null){
            //System.out.printf("The Skyline tuple is: %d %d \n", outerTuple.getIntFld(1), outerTuple.getIntFld(2));
            ans = true;
          }
          
        }

        return ans;
  }
  /**
   * returns the numbers of tuples written
   *@return the numbers of tuples written
   *@exception IOException some I/O fault
   *@exception Exception other exceptions
   */
  public void flush()throws IOException, Exception 
    {     
          flushed = true;
          if (dirty)
          {
            dirty = false;
          }
    }
  
  public static final int WRITE_BUFFER =0;
  public static final int READ_BUFFER  =1;
  private boolean done;
  private  boolean dirty;              // Does this buffer contain dirty pages?
  private  int  t_per_pg,              // # of tuples that fit in 1 page
    t_in_buf;                        // # of tuples that fit in the buffer
  private  int  t_wr_to_pg,          // # of tuples written to current page
    t_wr_to_buf;                      // # of tuples written to buffer.
  private  int  curr_page;            // Current page being written to.
  private  byte _bufs[][];            // Array of pointers to buffer pages.
  private  int  _n_pages;             // number of pages in array
  private  int  t_size;               // Size of a tuple
  private  long t_written;           // # of tuples written so far
  private  int  _TEST_temp_fd;       // fd of a temporary file
  private  Heapfile _temp_fd;
  private  boolean  flushed;        // TRUE => buffer has been flushed.
  private  int  mode;
  private  int  t_rd_from_pg;      // # of tuples read from current page
  private  SpoofIbuf i_buf;        // gets input from a temporary file
}








