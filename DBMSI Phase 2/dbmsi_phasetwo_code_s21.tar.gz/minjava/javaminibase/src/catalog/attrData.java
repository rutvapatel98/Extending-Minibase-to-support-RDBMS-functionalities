//------------------------------------
// attrData.java
//
// Ning Wang, April,24  1998
//-------------------------------------

package catalog;

// attrData class for minimum and maximum attribute values
public class attrData
{
  public String strVal; 
  public int   intVal =0;
  public float floatVal= (float)0.0;
}


